package main.java_main_logic.kontroleri_ekrana.novi_zapis;

import hr.java.covidportal.niti.NajviseZarazenihNit;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.iznimke.Upozorenje;
import main.java_main_logic.model.Zupanija;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class DodavanjeNoveZupanijeController implements Initializable, ListeZupanijaSimptomaBolestiVirusaOsoba, PovijestKretanjaPoEkranima {

    public static final Logger logger = LoggerFactory.getLogger(DodavanjeNoveZupanijeController.class);
    public static String putanjaDoTrenutnogFXMLa = "layout/novi_zapis/dodavanjeNoveZupanije.fxml";


    @FXML
    private Button naprijedGumb = new Button();


    @FXML
    private TextField dohvatNaziva = new TextField();
    @FXML
    private TextField dohvatBrojaStanovnika = new TextField();
    @FXML
    private TextField dohvatBrojaZarazenih = new TextField();



    @FXML
    public void spremiNovuZupaniju() throws IOException, SQLException {
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZupanijaIzBaze(BazaPodataka.dohvatiSveZupanije());


        try{
            provjeriPopunjenost(dohvatNaziva.getText(), (dohvatBrojaStanovnika.getText()), dohvatBrojaZarazenih.getText());

            String naziv = dohvatNaziva.getText();
            Integer brojStanovnika = Integer.parseInt(dohvatBrojaStanovnika.getText());
            Integer brojZarazenih = Integer.parseInt(dohvatBrojaZarazenih.getText());

            //SPREMI �UPANIJU
            BazaPodataka.spremiJednuZupaniju(naziv, brojStanovnika, brojZarazenih);

            isprazniSvaPolja(dohvatNaziva, dohvatBrojaStanovnika, dohvatBrojaZarazenih);

/*
            NajviseZarazenihNit najZarazenihNit = new NajviseZarazenihNit(ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije);
            ExecutorService executorService = Executors.newCachedThreadPool();
            executorService.execute(najZarazenihNit);*/





            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje nove �upanije");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novoj �upaniji");
            obavijest.showAndWait();

        }catch (NumberFormatException ex)
        {
            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setTitle("Numeri�ki podatci");
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setContentText("Broj stanovnika i broj zara�enih osoba moraju biti numeri�ki");
            upozorenje.showAndWait();

            isprazniSvaPolja(dohvatNaziva, dohvatBrojaStanovnika, dohvatBrojaZarazenih);
        }
        catch (Upozorenje ex)
        {
            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setTitle("Nepopunjena polja");
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setContentText("Polja moraju biti popunjena");
            upozorenje.showAndWait();

            isprazniSvaPolja(dohvatNaziva, dohvatBrojaStanovnika, dohvatBrojaZarazenih);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();
    }

    private void provjeriPopunjenost(String prvi, String drugi, String treci)
    {
        if(prvi.isEmpty() || drugi.isEmpty() || treci.isEmpty())
            throw new Upozorenje();
    }

    private void isprazniSvaPolja(TextField prvi, TextField drugi, TextField treci)
    {
        prvi.setText("");
        drugi.setText("");
        treci.setText("");
    }




    @FXML
    public void odiNatrag() throws IOException
    {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran dodavanja Simptomima");
    }
    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Dodavanje nove �upanije");
        logger.info("Korisnik je otvorio ekran dodavanja nove �upanije");



      dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
      vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
