package main.java_main_logic.kontroleri_ekrana;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class PocetniEkranController implements Initializable, PovijestKretanjaPoEkranima
{
    String putanjaDoFXMLa;

    @FXML
    public void prikaziEkranZaPretraguZupanija() throws IOException
    {
        putanjaDoFXMLa = "layout/pretraga/pretragaZupanija.fxml";
        Parent pretragaZupanijaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguSimptoma() throws IOException
    {
        putanjaDoFXMLa = "layout/pretraga/pretragaSimptoma.fxml";
        Parent pretragaSimptomaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene pretragaSimptomaScene = new Scene(pretragaSimptomaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaSimptomaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguBolesti() throws IOException
    {
        putanjaDoFXMLa = "layout/pretraga/pretragaBolesti.fxml";
        Parent pretragaBolestiFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene pretragaBolestiScene = new Scene(pretragaBolestiFrame, 600, 400);
        Main.getMainStage().setScene(pretragaBolestiScene);
    }

    @FXML
    public void prikaziEkranZaPretraguVirusa() throws IOException
    {
        putanjaDoFXMLa = "layout/pretraga/pretragaVirusa.fxml";
        Parent pretragaVirusaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene pretragaVirusaScene = new Scene(pretragaVirusaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaVirusaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguOsoba() throws IOException
    {
        putanjaDoFXMLa = "layout/pretraga/pretragaOsoba.fxml";
        Parent pretragaOsobaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene pretragaOsobaScene = new Scene(pretragaOsobaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaOsobaScene);
    }

    @FXML
    public void prikaziEkranZaUnosZupanije() throws IOException
    {
        putanjaDoFXMLa = "layout/novi_zapis/dodavanjeNoveZupanije.fxml";
        Parent unosZupanijaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene unosZupanijaScene = new Scene(unosZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(unosZupanijaScene);
    }

    @FXML
    public void prikaziEkranZaUnosSimptoma() throws IOException
    {
        putanjaDoFXMLa = "layout/novi_zapis/dodavanjeNovogSimptoma.fxml";
        Parent unosSimptomaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene unosSimptomaScene = new Scene(unosSimptomaFrame, 600, 400);
        Main.getMainStage().setScene(unosSimptomaScene);
    }


    @FXML
    public void prikaziEkranZaUnosBolesti() throws IOException
    {
        putanjaDoFXMLa = "layout/novi_zapis/dodavanjeNoveBolesti.fxml";
        Parent unosBolestiFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene unosBolestiScene = new Scene(unosBolestiFrame, 600, 400);
        Main.getMainStage().setScene(unosBolestiScene);
    }

    @FXML
    public void prikaziEkranZaUnosVirusa() throws IOException
    {
        putanjaDoFXMLa = "layout/novi_zapis/dodavanjeNovogVirusa.fxml";
        Parent unosVirusaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene unosVirusaScene = new Scene(unosVirusaFrame, 600, 400);
        Main.getMainStage().setScene(unosVirusaScene);
    }

    @FXML
    public void prikaziEkranZaUnosOsoba() throws IOException
    {
        putanjaDoFXMLa = "layout/novi_zapis/dodavanjeNoveOsobe.fxml";
        Parent unosOsobaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource(putanjaDoFXMLa)));
        Scene unosOsobaScene = new Scene(unosOsobaFrame, 600, 400);
        Main.getMainStage().setScene(unosOsobaScene);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().getIcons().add(new Image("icons/faviconVirus.png"));
        Main.getMainStage().setTitle("Covidportal");
    }
}

