package main.java_main_logic.model;
/**
 * Slu�i za kreiranje objekta �upanija u klasi Glavna.
 */
public class Zupanija extends ImenovaniEntitet {
    private Integer brojStanovnika;
    private Integer brojZarazenih;
    private double postotakZarazenost;

    //KONSTRUKTOR
    public Zupanija(Long id, String naziv, Integer brojStanovnika, Integer brojZarazenih) {
        super(id, naziv);
        this.brojStanovnika = brojStanovnika;
        this.brojZarazenih = brojZarazenih;
        this.postotakZarazenost = ((double)brojZarazenih / (double)brojStanovnika) * 100;
    }

    public Zupanija() { }




    //NAZIV - GETTER I SETTER SE NALAZI U IMENOVANOM ENTITETU


    //BROJSTANOVNIKA
    public Integer getBrojStanovnika() {
        return brojStanovnika;
    }
    public void setBrojStanovnika(Integer brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }


    //BROJ ZARA�ENIH
    public Integer getBrojZarazenih() {
        return brojZarazenih;
    }
    public void setBrojZarazenih(Integer brojZarazenih) {
        this.brojZarazenih = brojZarazenih;
    }


    //POSTOTAK ZARA�ENOSTI �UPANIJE
    public double getPostotakZarazenost() {
        return postotakZarazenost;
    }
    public void setPostotakZarazenost(double postotakZarazenost) {
        this.postotakZarazenost = postotakZarazenost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Zupanija zupanija = (Zupanija) o;

        return brojStanovnika != null ? brojStanovnika.equals(zupanija.brojStanovnika) : zupanija.brojStanovnika == null;
    }

    @Override
    public int hashCode() {
        return brojStanovnika != null ? brojStanovnika.hashCode() : 0;
    }


    @Override
    public String toString()
    {
        return getNaziv();
    }
}
