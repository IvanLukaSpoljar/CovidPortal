package main.java_main_logic.kontroleri_ekrana.novi_zapis;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.AppendPodataka;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.iznimke.Upozorenje;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DodavanjeNovogVirusaController implements Initializable, ListeZupanijaSimptomaBolestiVirusaOsoba, PovijestKretanjaPoEkranima, AppendPodataka {

    public static final Logger logger = LoggerFactory.getLogger(DodavanjeNovogVirusaController.class);
    public static String putanjaDoTrenutnogFXMLa = "layout/novi_zapis/dodavanjeNovogVirusa.fxml";


    @FXML
    private Button naprijedGumb = new Button();


    @FXML
    private TextField dohvatNaziva = new TextField();
    @FXML
    private TextField dohvatRbSimptoma = new TextField();
    //1.TADATAK
    @FXML
    private TextField dohvatOpisa = new TextField();


    @FXML
    private void spremiNoviVirus() throws IOException {
        Long id = (long) 1;
        if (sviVirusi.size() > 0)
        {
            id = sviVirusi.get(sviVirusi.size() - 1).getId() + 1;
        }

        try {
            provjeriValljanost(dohvatNaziva, dohvatRbSimptoma, dohvatOpisa);
            AppendPodatakaVirusa(id, dohvatNaziva.getText(), dohvatRbSimptoma.getText(), dohvatOpisa.getText());
            isprazniSvaPolja(dohvatNaziva, dohvatRbSimptoma, dohvatOpisa);

        } catch (Upozorenje ex) {

            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setTitle("Nepopunjena polja ili krivo odabrani simptomi");
            upozorenje.setContentText(ex.getMessage());
            upozorenje.showAndWait();

            isprazniSvaPolja(dohvatNaziva, dohvatRbSimptoma, dohvatOpisa);
        }
    }



    //2.ZADATAK
    private void provjeriValljanost(TextField naziv, TextField simptomi, TextField opis) {
        if((naziv.getText().isEmpty()))
        {
            zacrveniPolje(naziv, "da");
        }
        else
            zacrveniPolje(naziv, "ne");


        if(opis.getText().isEmpty())
        {
            zacrveniPolje(opis, "da");
        }
        else
            zacrveniPolje(opis, "ne");


        if(simptomi.getText().isEmpty())
        {
            zacrveniPolje(simptomi, "da");
        }





        if((naziv.getText().isEmpty()) || simptomi.getText().isEmpty() || opis.getText().isEmpty())
        {
            throw new Upozorenje("Provjerite jeste li unjeli ispravan naziv, simptom i opis");
        }





       if(simptomi.getText().isEmpty() == false)
        {
            Boolean nedozvoljenaVrijednost = false;
            String regex = "^[0-9,]*$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(simptomi.getText());

            if (matcher.matches() == false)
                nedozvoljenaVrijednost = true;
            else {
                String[] stringoviBrojeva = simptomi.getText().split(",");
                if(stringoviBrojeva.length == 0)
                {
                    nedozvoljenaVrijednost = true;
                }
                for (int i = 0; i < stringoviBrojeva.length; i++)
                    if (stringoviBrojeva[i].isEmpty() == true || stringoviBrojeva[i].isEmpty() || (long) Integer.parseInt(stringoviBrojeva[i]) < 1 || (long) Integer.parseInt(stringoviBrojeva[i]) > sviSimptomi.get(sviSimptomi.size() - 1).getId())
                        nedozvoljenaVrijednost = true;

            }

            if(nedozvoljenaVrijednost == true)
            {
                throw new Upozorenje("Unjeli ste nedozvoljenu vrijednost u polje simptoma, mo�ete odabrati simptome u intervalu od " + 1 + " do " + sviSimptomi.get(sviSimptomi.size() - 1).getId() + "\nNe zaboravite odabire simptoma odvajati zarezom.");
            }
            else
                zacrveniPolje(simptomi, "ne");
        }






    }



    private void isprazniSvaPolja(TextField naziv, TextField dohvatRbSimptoma, TextField opis) {
        naziv.setText("");
        dohvatRbSimptoma.setText("");
        dohvatOpisa.setText("");
    }



    @FXML
    public void odiNatrag() throws IOException {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran dodavanja virusa");
    }

    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Dodavanje novog simptoma");
        logger.info("Korisnik je otvorio ekran dodavanja novog virusa");

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
