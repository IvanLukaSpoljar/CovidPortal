package main.java_main_logic.extra_help;

import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.model.*;
import main.java_main_logic.GLAVNO.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface ListeZupanijaSimptomaBolestiVirusaOsoba {

    public static final Logger logger = LoggerFactory.getLogger(Main.class);

    List<Zupanija> sveZupanije = new ArrayList<>();
    List<Simptom> sviSimptomi = new ArrayList<>();
    List<Bolest> sveBolesti = new ArrayList<>();
    List<Virus> sviVirusi = new ArrayList<>();
    List<Osoba> sveOsobe = new ArrayList<>();

    List<Bolest> sveZaraze = new ArrayList<>();



    static List<Zupanija> dohvatiListuZupanijaIzBaze(List<Zupanija> listaBaze) {
        //<-------------�UPANIJE---------------->
        sveZupanije.removeAll(sveZupanije);
        for (int i = 0; i < listaBaze.size(); i++) {
            sveZupanije.add(listaBaze.get(i));
        }
        return sveZupanije;
    }





    static List<Simptom> dohvatiListuSimptomaIzBaze(List<Simptom> listaBaze) {
        //<-------------SIMPTOMI---------------->
        sviSimptomi.removeAll(sviSimptomi);
        for (int i = 0; i < listaBaze.size(); i++) {
            sviSimptomi.add(listaBaze.get(i));
        }
        return sviSimptomi;
    }





    static List<Bolest> dohvatiListuZarazaIzBaze(List<Bolest> listaBaze) {
        //<------------------SVE ZARAZE---------------------------->
        sveZaraze.removeAll(sveZaraze);
        sveBolesti.removeAll(sveBolesti);
        sviVirusi.removeAll(sviVirusi);

        for (int i = 0; i < listaBaze.size(); i++) {
            sveZaraze.add(listaBaze.get(i));
        }

        odvoji_Viruse_I_Bolesti(sveZaraze);
        return sveZaraze;
    }
    static void odvoji_Viruse_I_Bolesti(List<Bolest> listaBaze) {
        //--------------DOBIVANJE ODVOJENIH LITSA BOLESTI I VIRUSA--------------
        for (int i = 0; i < listaBaze.size(); i++) {
            if (listaBaze.get(i) instanceof Virus) {
                sviVirusi.add((Virus) listaBaze.get(i));
            } else {
                sveBolesti.add(listaBaze.get(i));
            }
        }
    }





    static List<Osoba> dohvatiListuOsobaizBaze(List<Osoba> listaBaze) {
        //<-------------OSOBE---------------->
        sveOsobe.removeAll(sveOsobe);
        for (int i = 0; i < listaBaze.size(); i++) {
            sveOsobe.add(listaBaze.get(i));
        }

        return sveOsobe;
    }


    static <T> void ocistiListu (List<T> listaBaze)
    {
        listaBaze.removeAll(listaBaze);
    }

    static void ocistiSveListe()
    {

        sveZupanije.removeAll(sveZupanije);
        sviSimptomi.removeAll(sviSimptomi);

        sveZaraze.removeAll(sveZaraze);
        sveBolesti.removeAll(sveBolesti);
        sviVirusi.removeAll(sviVirusi);

        sveOsobe.removeAll(sveOsobe);


    }





    static void ucitajSvePodatkeIzBaze() throws SQLException, IOException {

        //U�ITAVANJE SVIH �UPANIJA IZ BAZE
        sveZupanije.removeAll(sveZupanije);
        dohvatiListuZupanijaIzBaze(BazaPodataka.dohvatiSveZupanije());


        //U�ITAVANJE SVIH SIMPTOMA IZ BAZE
        sviSimptomi.removeAll(sviSimptomi);
        dohvatiListuSimptomaIzBaze(BazaPodataka.dohvatiSveSimptomeIzBaze());


        //U�ITAVANJE SVIH BOLESTI IZ BAZE
        sveZaraze.removeAll(sveZaraze);
        sveBolesti.removeAll(sveBolesti);
        sviVirusi.removeAll(sviVirusi);
        dohvatiListuZarazaIzBaze(BazaPodataka.dohvatiSveZarazeIzBaze());


        //U�ITAVANJE SVIH OSOBA IZ BAZE
        sveOsobe.removeAll(sveOsobe);
        dohvatiListuOsobaizBaze(BazaPodataka.dohvatiSveOsobe());

    }
}
