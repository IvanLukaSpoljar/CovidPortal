package hr.java.covidportal.iznimke;

/**
 * klasa za iznimku kod ponavljanja istih osoba
 */
public class DuplaOsobaException extends RuntimeException{

    public DuplaOsobaException(String message)
    {
        super(message);
    }

    public DuplaOsobaException(Throwable cause)
    {
        super(cause);
    }

    public DuplaOsobaException(String message, Throwable cause)
    {
        super(message, cause);
    }

}
