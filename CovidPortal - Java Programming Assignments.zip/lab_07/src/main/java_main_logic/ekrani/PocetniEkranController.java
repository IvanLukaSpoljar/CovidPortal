package main.java_main_logic.ekrani;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollBar;
import javafx.scene.image.Image;
import javafx.scene.shape.SVGPath;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class PocetniEkranController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba
{

    @FXML
    public void prikaziEkranZaPretraguZupanija() throws IOException
    {
        Parent pretragaZupanijaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("layout/pretragaZupanija.fxml")));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguSimptoma() throws IOException
    {
        Parent pretragaSimptomaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("layout/pretragaSimptoma.fxml")));
        Scene pretragaSimptomaScene = new Scene(pretragaSimptomaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaSimptomaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguBolesti() throws IOException
    {
        Parent pretragaBolestiFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("layout/pretragaBolesti.fxml")));
        Scene pretragaBolestiScene = new Scene(pretragaBolestiFrame, 600, 400);
        Main.getMainStage().setScene(pretragaBolestiScene);
    }

    @FXML
    public void prikaziEkranZaPretraguVirusa() throws IOException
    {
        Parent pretragaVirusaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("layout/pretragaVirusa.fxml")));
        Scene pretragaVirusaScene = new Scene(pretragaVirusaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaVirusaScene);
    }

    @FXML
    public void prikaziEkranZaPretraguOsoba() throws IOException
    {
        Parent pretragaOsobaFrame = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("layout/pretragaOsoba.fxml")));
        Scene pretragaOsobaScene = new Scene(pretragaOsobaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaOsobaScene);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().getIcons().add(new Image("icons/faviconVirus.png"));
    }
}

