package main.java_main_logic.model;


public interface Zarazno {
    public void prelazakZarazeNaOsobu(Osoba osoba);
}
