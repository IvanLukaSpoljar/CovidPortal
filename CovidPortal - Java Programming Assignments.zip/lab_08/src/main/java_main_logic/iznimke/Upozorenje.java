package main.java_main_logic.iznimke;

public class Upozorenje extends RuntimeException{
    public Upozorenje(){}

    public Upozorenje(String message)
    {
        super(message);
    }

    public Upozorenje(Throwable cause)
    {
        super(cause);
    }

    public Upozorenje(String message, Throwable cause)
    {
        super(message, cause);
    }
}
