package main.java_main_logic.GLAVNO;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import main.java_main_logic.GLAVNO.pomocno.Glavna;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;


import java.io.*;

public class Main extends Application implements liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba {

    private static Stage mainStage;
    public static Stage getMainStage()
    {
        return mainStage;
    }


    @Override
    public void start(Stage primaryStage) throws Exception{
        logger.info("Korisnik je otvorio ekran Glavnog izbornika");
        mainStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        primaryStage.setTitle("Covidportal");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        logger.info("Korisnik je zatvorio ekran Glavnog izbornika");
    }


    public static void main(String[] args) throws IOException {
        logger.info("PO�ETAK PROGRAMA");
        Glavna.main(args);
        launch(args);
        logger.info("KRAJ PROGRAMA");
    }
}
