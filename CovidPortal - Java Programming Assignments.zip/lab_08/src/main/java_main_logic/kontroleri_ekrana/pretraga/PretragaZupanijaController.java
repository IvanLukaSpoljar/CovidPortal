package main.java_main_logic.kontroleri_ekrana.pretraga;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.model.Zupanija;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import javafx.scene.control.cell.PropertyValueFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaZupanijaController implements Initializable, PovijestKretanjaPoEkranima {

    private static List<Zupanija> listaSvihZupanijeIzControllera = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaZupanija.fxml";

    public static final Logger logger = LoggerFactory.getLogger(PretragaZupanijaController.class);


    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje = new TextField();


    @FXML
    private TableView<Zupanija> tablicaZupanija;

    @FXML
    private TableColumn<Zupanija, String> stupacNaziva;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaStanovnika;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaZarazenih;




    @FXML
    public void odiNatrag() throws IOException {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o �upanijama");
    }
    @FXML
    public void odiNaprijed() throws IOException {
      slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }
    @FXML
    public void pretrazi() throws IOException
    {
        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaZupanija.setItems(FXCollections.observableList(
                    listaSvihZupanijeIzControllera.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }






    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        logger.info("Korisnik je otvorio ekran o �upanijama");
        Main.getMainStage().setTitle("�upanije");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Zupanija, String>("naziv"));
        stupacBrojaStanovnika.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojStanovnika"));
        stupacBrojaZarazenih.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojZarazenih"));

        listaSvihZupanijeIzControllera = ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije;
        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);

    }
}
