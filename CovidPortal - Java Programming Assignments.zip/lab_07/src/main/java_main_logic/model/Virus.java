package main.java_main_logic.model;

import java.util.Set;

/**
 *Slu�i za kreiranje objekta bolest u klasi Glavna.
 */
public class Virus extends Bolest implements Zarazno {

    private String opis;

    //KONSTRUKTOR
    public Virus(Long id, String naziv, Set<Simptom> simptomi, String opis) {
        super(id, naziv, simptomi);
        this.opis = opis;
    }


    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    /**
     * Prenosi virus
     * @param osoba objekt klase Osoba
     */


    @Override
    public void prelazakZarazeNaOsobu(Osoba osoba) {
        osoba.setZarazenBolescu(this);
    }

    @Override
    public String toString()
    {
        return super.getNaziv();
    }
}
