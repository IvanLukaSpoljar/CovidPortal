package main.java_main_logic.GLAVNO;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.sporedno.Glavna;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;


import java.io.*;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

public class Main extends Application implements ListeZupanijaSimptomaBolestiVirusaOsoba {

    private static Stage mainStage;
    public static Stage getMainStage()
    {
        return mainStage;
    }


    @Override
    public void start(Stage primaryStage) throws Exception{
        logger.info("Korisnik je otvorio ekran Glavnog izbornika");
        mainStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        primaryStage.setTitle("Covidportal");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        logger.info("Korisnik je zatvorio ekran Glavnog izbornika");
    }


    public static void main(String[] args) throws IOException, SQLException {
        logger.info("PO�ETAK PROGRAMA");
      // Glavna.main(args);

        System.out.println("U�LO");

        //U�ITAVANJE SVIH �UPANIJA IZ BAZE
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZupanijaIzBaze(BazaPodataka.dohvatiSveZupanije());
        for(int i = 0; i < sveZupanije.size(); i++)
        {
            System.out.println((i+1) + ". Zupanija: " + sveZupanije.get(i));
        }
        System.out.println();
        System.out.println();

        //U�ITAVANJE SVIH SIMPTOMA IZ BAZE
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuSimptomaIzBaze(BazaPodataka.dohvatiSveSimptomeIzBaze());
        for(int i = 0; i < sviSimptomi.size(); i++)
        {
            System.out.println((i+1) + ". Simptomi: " + sviSimptomi.get(i));
        }

        System.out.println();
        System.out.println();

        //U�ITAVANJE SVIH BOLESTI IZ BAZE
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZarazaIzBaze(BazaPodataka.dohvatiSveBolestiIzBaze());
        for(int i = 0; i < sveZaraze.size(); i++)
        {
            System.out.println((i+1) + ". Zaraze: " + sveZaraze.get(i).getId() + " " +  sveZaraze.get(i).getNaziv() + " " + sveZaraze.get(i).getSimptomi() );
        }

        System.out.println();
        System.out.println();



        //U�ITAVANJE SVIH OSOBA IZ BAZE
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuOsobaizBaze(BazaPodataka.dohvatiSveOsobe());
        for(int i = 0; i < sveOsobe.size(); i++)
        {
            System.out.println((i+1) + ". Osobe: " + sveOsobe.get(i).getIme() + " " + sveOsobe.get(i).getPrezime() + sveOsobe.get(i).getStarost() + " " + sveOsobe.get(i).getZupanija() + " " + sveOsobe.get(i).getKontaktiraneOsobe());
        }

        launch(args);
        logger.info("KRAJ PROGRAMA");
    }
}
