package hr.java.covidportal.model;

public class Zupanija extends ImenovaniEntitet {
    private Integer brojStanovnika;

    //KONSTRUKTOR
    public Zupanija(String naziv, Integer brojStanovnika) {
        super(naziv);
        this.brojStanovnika = brojStanovnika;
    }


    //NAZIV
    public String getNaziv() {
        return super.getNaziv();
    }

    public void setNaziv(String naziv) {
        super.setNaziv(naziv);
    }

    //BROJSTANOVNIKA
    public Integer getBrojStanovnika() {
        return brojStanovnika;
    }

    public void setBrojStanovnika(Integer brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }
}
