package main.java_main_logic.extra_help;

import main.java_main_logic.model.*;
import main.java_main_logic.GLAVNO.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public interface ListeZupanijaSimptomaBolestiVirusaOsoba {

    public static final Logger logger = LoggerFactory.getLogger(Main.class);

    List<Zupanija> sveZupanije = new ArrayList<>();
    List<Simptom> sviSimptomi = new ArrayList<>();
    List<Bolest> sveBolesti = new ArrayList<>();
    List<Virus> sviVirusi = new ArrayList<>();
    List<Osoba> sveOsobe = new ArrayList<>();





   static List<Zupanija> kreirajListuSvihZupanijaIzDatoteke(String imeDatoteke)
    {
        //<-------------�UPANIJE---------------->
        System.out.println("\n#################################################### UNOS �UPANIJA ####################################################");
        File zupanijeFileTxt = new File(imeDatoteke);
        try (
                FileReader fileReader = new FileReader(zupanijeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke zupanija je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv iz datoteke zupanija je: " + naziv);

                procitanaLinija = reader.readLine();
                Integer brStanovnika = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itani Broj Stanovnika iz datoteke zupanija je: " + brStanovnika);

                procitanaLinija = reader.readLine();
                Integer brZarazenih = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itani Broj Zara�enih Stanovnika iz datoteke zupanija je: " + brZarazenih);

                sveZupanije.add(new Zupanija(id, naziv, brStanovnika, brZarazenih));
                procitanaLinija = reader.readLine();
            }
            logger.info("Podatci o �upanijama su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();

            ex = new IOException("Neuspjelo u�itavanje podataka o �upanijama.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }
       return sveZupanije;
    }



     static List<Simptom> kreirajListuSvihSimptomaIzDatoteke(String imeDatoteke)
    {

        System.out.println("\n#################################################### UNOS SIMPTOMA ####################################################");
        File simptomiFileTxt = new File(imeDatoteke);
        try (FileReader fileReader = new FileReader(simptomiFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv simptoma iz datoteke je: " + naziv);

                String vrijednost = procitanaLinija = reader.readLine();
                System.out.println("Pro�itana vrijednost simptoma iz datoteke je: " + vrijednost);

                sviSimptomi.add(new Simptom(id, naziv, vrijednost));
                procitanaLinija = reader.readLine();
            }
            logger.info("Podatci o simptomima su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o simptomima.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }
        return sviSimptomi;
    }



     static List<Bolest> kreirajListuSvihBolestiIzDatoteke(String imeDatoteke)
    {

        System.out.println("\n#################################################### UNOS BOLESTI #####################################################");
        File zarazeFileTxt = new File(imeDatoteke);

        try (FileReader fileReader = new FileReader(zarazeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv bolesti iz datoteke je: " + naziv);

                String vrijednost = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani simptomi bolesti iz datoteke je: " + vrijednost);


                String[] replaceString = vrijednost.split(",");
                List<Simptom> dodavanjeSimptomaBolesti = new ArrayList<>();


                for (int i = 0; i < replaceString.length; i++) {
                    int id_Broj_Simptoma = Integer.parseInt(replaceString[i]);

                    for (int j = 0; j < sviSimptomi.size(); j++) {
                        if (id_Broj_Simptoma == sviSimptomi.get(j).getId()) {
                            dodavanjeSimptomaBolesti.add(sviSimptomi.get(j));
                        }
                    }
                }
                sveBolesti.add(new Bolest(id, naziv, dodavanjeSimptomaBolesti));
                procitanaLinija = reader.readLine();
            }
            logger.info("Podatci o bolestima su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o bolestima.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }

        return sveBolesti;
    }



   static List<Virus> kreirajListuSvihVirusaIzDatoteke(String imeDatoteke)
    {


        System.out.println("\n#################################################### UNOS VIRUSA #####################################################");
        File zarazeFileTxt = new File(imeDatoteke);

        try (FileReader fileReader = new FileReader(zarazeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv bolesti iz datoteke je: " + naziv);

                String vrijednost = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani simptomi bolesti iz datoteke je: " + vrijednost);


                String[] replaceString = vrijednost.split(",");
                List<Simptom> dodavanjeSimptomaBolesti = new ArrayList<>();


                for (int i = 0; i < replaceString.length; i++) {
                    int id_Broj_Simptoma = Integer.parseInt(replaceString[i]);

                    for (int j = 0; j < sviSimptomi.size(); j++) {
                        if (id_Broj_Simptoma == sviSimptomi.get(j).getId()) {
                            dodavanjeSimptomaBolesti.add(sviSimptomi.get(j));
                        }
                    }
                }
                procitanaLinija = reader.readLine();

                sviVirusi.add(new Virus(id, naziv, dodavanjeSimptomaBolesti, procitanaLinija));
                procitanaLinija = reader.readLine();
            }
            logger.info("Podatci o virusima su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o virusima.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }

        return sviVirusi;
    }


    static List<Bolest> spojBolestiSaVirusima()
    {
        List<Bolest> zaraze = new ArrayList<>(sveBolesti);
        List<Virus> pomocniVirusi = new ArrayList<>();

        for(int i = 0; i < sviVirusi.size(); i++)
            pomocniVirusi.add(new Virus(sviVirusi.get(i).getId(),  sviVirusi.get(i).getNaziv(), sviVirusi.get(i).getSimptomi(), sviVirusi.get(i).getOpis()));

        for(int i = 0; i < pomocniVirusi.size(); i++)
        {
            pomocniVirusi.get(i).setId(zaraze.size() + (long)1);
            zaraze.add(pomocniVirusi.get(i));
        }
        return zaraze;
    }


    static List<Osoba> kreirajListuSvihOsobaIzDatoteke(String imeDatoteke)
    {
        //<-------------OSOBE---------------->
        System.out.println("\n#################################################### UNOS OSOBA #######################################################");
        File osobeFileTxt = new File(imeDatoteke);
        try (FileReader fileReader = new FileReader(osobeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            String ime_datoteke = "osobe.txt";
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke " + ime_datoteke + " je: " + id);

                String imeOsobe = procitanaLinija = reader.readLine();
                System.out.println("Pro�itano ime osobe iz datoteke " + ime_datoteke + " je: " + imeOsobe);

                String prezimeOsobe = procitanaLinija = reader.readLine();
                System.out.println("Pro�itano prezime osobe iz datoteke " + ime_datoteke + " je: " + prezimeOsobe);

                procitanaLinija = reader.readLine();
                Integer starostOsobe = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itana starost osobe iz datoteke " + ime_datoteke + " je: " + starostOsobe);

                //�UPANIJA
                procitanaLinija = reader.readLine();
                Integer odabirZupanijeOsobe = Integer.parseInt(procitanaLinija);
                Zupanija zapamtiZupaniju = sveZupanije.get(odabirZupanijeOsobe - 1);
                System.out.println("Pro�itana prebivali�na �upanija osobe iz datoteke " + ime_datoteke + " je: " + odabirZupanijeOsobe + ". " + zapamtiZupaniju.getNaziv());

                //ZARA�ENOST
                procitanaLinija = reader.readLine();
                Integer odabirZarazeOsobe = Integer.parseInt(procitanaLinija);

                List<Bolest> zaraze = spojBolestiSaVirusima();
                Bolest zapamtiZarazu = zaraze.get(odabirZarazeOsobe - 1);
                System.out.println("Odabir zaraze osobe iz datoteke " + ime_datoteke + " je: " + odabirZarazeOsobe + ". " + zapamtiZarazu.getNaziv());


                List<Osoba> listaSvihKontaktiranihOsoba = new ArrayList<>();
                if (sveOsobe.size() > 0) {
                    //KOLIKO UKUPNO KONTAKTIRANIH OSOBA
                    procitanaLinija = reader.readLine();
                    Integer brojKontaktiranih = Integer.parseInt(procitanaLinija);

                    System.out.println("Broj osoba s kojima je osoba kontaktirala iz datoteke " + ime_datoteke + " je: " + brojKontaktiranih);

                    //KOJE SU TO KONTAKTIANE OSOBE
                    procitanaLinija = reader.readLine();
                    String[] replaceString = procitanaLinija.split(",");

                    for (int i = 0; i < brojKontaktiranih; i++) {
                        Integer odabirKontaktianeOsobe = Integer.parseInt(replaceString[i]);
                        Osoba zapamtiOsobu = sveOsobe.get(odabirKontaktianeOsobe - 1);
                        listaSvihKontaktiranihOsoba.add(zapamtiOsobu);
                        System.out.println("Pro�itana kontaktirana osoba iz datoteke " + ime_datoteke + " je: " + odabirKontaktianeOsobe + ". " + zapamtiOsobu.getIme() + " " + zapamtiOsobu.getPrezime());
                    }
                }else
                    listaSvihKontaktiranihOsoba = null;

                sveOsobe.add(
                        new Osoba.Builder(id)
                                .name(imeOsobe)
                                .surname(prezimeOsobe)
                                .age(starostOsobe)
                                .county(zapamtiZupaniju) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                                .personInfection(zapamtiZarazu) //UNOS BOLESTI OSOBE
                                .contactedPersons(listaSvihKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                                .makeItDone()
                );

                procitanaLinija = reader.readLine();
                System.out.println();
            }
            logger.info("Podatci o osobama su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o osobama.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }

        return sveOsobe;
    }




}
