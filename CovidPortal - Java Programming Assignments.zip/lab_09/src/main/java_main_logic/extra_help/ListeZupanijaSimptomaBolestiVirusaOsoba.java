package main.java_main_logic.extra_help;

import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.model.*;
import main.java_main_logic.GLAVNO.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public interface ListeZupanijaSimptomaBolestiVirusaOsoba {

    public static final Logger logger = LoggerFactory.getLogger(Main.class);

    List<Zupanija> sveZupanije = new ArrayList<>();
    List<Simptom> sviSimptomi = new ArrayList<>();
    List<Bolest> sveBolesti = new ArrayList<>();
    List<Virus> sviVirusi = new ArrayList<>();
    List<Osoba> sveOsobe = new ArrayList<>();

    List<Bolest> sveZaraze = new ArrayList<>();



   static List<Zupanija> dohvatiListuZupanijaIzBaze(List<Zupanija> listaBaze) {
       //<-------------�UPANIJE---------------->
      for(int i = 0; i < listaBaze.size(); i++)
      {
          sveZupanije.add(listaBaze.get(i));
      }
       return sveZupanije;
    }



    static List<Simptom> dohvatiListuSimptomaIzBaze(List<Simptom> listaBaze)
    {
        //<-------------SIMPTOMI---------------->
        for(int i = 0; i < listaBaze.size(); i++)
        {
            sviSimptomi.add(listaBaze.get(i));
        }
        return sviSimptomi;
    }




     static List<Bolest> dohvatiListuZarazaIzBaze(List<Bolest> listaBaze)
    {
        //<------------------SVE ZARAZE--------------------->
        for(int i = 0; i < listaBaze.size(); i++)
        {
            sveZaraze.add(listaBaze.get(i));
        }
        kreirajOdvojeneViruseiBolesti(sveZaraze);
        return sveZaraze;
    }
   static void kreirajOdvojeneViruseiBolesti(List<Bolest> listaBaze)
    {
        //--------------DOBIVANJE ODVOJENIH LITSA BOLESTI I VIRUSA--------------
        for(int i = 0; i < listaBaze.size(); i++)
        {
            if(listaBaze.get(i) instanceof Virus) {
                sviVirusi.add((Virus) listaBaze.get(i));
            }
            else {
                sveBolesti.add(listaBaze.get(i));
            }
        }
    }







    static List<Osoba> dohvatiListuOsobaizBaze(List<Osoba> listaBaze)
    {
        //<-------------OSOBE---------------->
        for(int i = 0; i < listaBaze.size(); i++)
        {
            sveOsobe.add(listaBaze.get(i));
        }

        return sveOsobe;
    }
}
