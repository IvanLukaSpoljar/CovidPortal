package hr.java.covidportal.main;

import hr.java.covidportal.enums.EnumeracijaSimptoma;
import hr.java.covidportal.iznimke.BolestIstihSimptoma;
import hr.java.covidportal.iznimke.DuplikatKontaktiraneOsobe;
import hr.java.covidportal.iznimke.OgranicenjeBroja;
import hr.java.covidportal.model.*;


import hr.java.covidportal.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import javax.management.ImmutableDescriptor;
import java.sql.SQLOutput;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;


/**
 * Slu�i za testiranje logginga tijekom izvo�enja programa.
 *
 */
public class Glavna {

    private static Integer brojacBolesti = 0;
    private static Integer brojacVirusa = 0;

    public static final Logger logger = LoggerFactory.getLogger(Glavna.class);

    /**
     * Slu�i za pokretanje programa koji �e od korisnika tra�iti da svojim unosom definira vrijednosti pojedinih
     * varijabli, te nakon toga da unese zara�ene osobe kod kojih �e se vidjeti jesu li u me�uvremenu zara�eni
     * nekom drugom bole��u i s kime su sve kontaktirali.
     *
     * @param args argumenti komandne linije
     */
    public static void main(String[] args) {

        logger.info("PO�ETAK PROGRAMA");

        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        Set<Zupanija> zupanije = new HashSet<>();
        Set<Simptom> simptomi = new HashSet<>();
        Set<Bolest> bolesti = new HashSet<>();
        List<Osoba> osobe = new ArrayList<>();

        //MAPA
        Map<Bolest, List<Osoba>> mapaZarazenihPoBolesti = new HashMap<>();


        //POMO�NE VARIJABLE
        List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest = new ArrayList<>();
        Boolean flagIznimka = true;


        //<-------------�UPANIJE---------------->
        System.out.println("\n#################################################### UNOS �UPANIJA ####################################################");
        Integer ukupanBrojZupanija = 0;
        do {
            try {
                System.out.print("Unesite broj �upanija koje �elite unijeti: ");
                ukupanBrojZupanija = unos.nextInt();
                Argument_Manji_Od_Jedan(ukupanBrojZupanija);

                logger.info("Broj je ispravno une�en, broj �upanija je: " + ukupanBrojZupanija);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        }while (flagIznimka);
        System.out.println("\nUnesite podatke o " + ukupanBrojZupanija + " �upanije: ");
        for (int i = 0; i < ukupanBrojZupanija; i++)
            zupanije.add(unosZupanije(unos, i));


        //<-------------SIMPTOMI---------------->
        System.out.println("\n#################################################### UNOS SIMPTOMA ####################################################");
        Integer ukupanBrojSimptoma = 0;
        do {
            try {
                System.out.print("Unesite broj simptoma koje �elite unijeti: ");
                ukupanBrojSimptoma = unos.nextInt();
                Argument_Manji_Od_Jedan(ukupanBrojSimptoma);

                logger.info("Broj je ispravno une�en, broj simptoma je: " + ukupanBrojSimptoma);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        }while (flagIznimka);
        System.out.println("\nUnesite podatke o " + ukupanBrojSimptoma + " simptoma: ");
        for (int i = 0; i < ukupanBrojSimptoma; i++)
            simptomi.add(unosSimptoma(unos, i));


        //<-------------BOLESTI---------------->
        System.out.println("\n#################################################### UNOS BOLESTI #####################################################");
        Integer ukupanBrojBolesti = -1;
        Integer ukupanBrojVirusa = -1;
        do {
            try {
                System.out.print("Unesite broj bolesti koje �elite unijeti: ");
                ukupanBrojBolesti  = unos.nextInt();
                Argument_Manji_Od_Nula(ukupanBrojBolesti);
                System.out.print("Unesite broj virusa koje �elite unijeti: ");
                ukupanBrojVirusa = unos.nextInt();
                Argument_Manji_Od_Nula(ukupanBrojVirusa);

                Argument_Manji_Od_Jedan(ukupanBrojBolesti + ukupanBrojVirusa);

                logger.info("Broj je ispravno une�en, broj bolesti je: " + (ukupanBrojBolesti + ukupanBrojVirusa));

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                iznimkaOgranicenja = new OgranicenjeBroja("Pogre�ka, broj mora biti jednak ili ve�i od 0, molimo ponovite unos za broj bolesti i broj virusa!");

                if(ukupanBrojBolesti == 0 && ukupanBrojVirusa == 0)
                    iznimkaOgranicenja = new OgranicenjeBroja("Pogre�ka, treba postojati barem jedna bolesti ili virus, molimo ponovite unos za broj bolesti i broj virusa!");

                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        }while (flagIznimka);
        System.out.println("\nUnesite podatke o " + (ukupanBrojBolesti + ukupanBrojVirusa) + " bolesti ili virusa: ");
        for (int i = 0; i < (ukupanBrojBolesti + ukupanBrojVirusa); i++)
            bolesti.add(unosBolesti(unos, simptomi, i, suma_Odabira_Simptoma_Za_Svaku_Bolest, ukupanBrojBolesti, ukupanBrojVirusa));

        //1.ZADATAK
        List<Bolest> pomocnaListaBolest = new ArrayList<Bolest>(bolesti);
        pomocnaListaBolest.stream().sorted(Comparator.comparing(Bolest::getNaziv).thenComparing(Bolest::getOpis)).forEach(System.out::println);

        //2.ZADATAK
        Bolest najmanja = bolesti.stream().min(Comparator.comparing(Bolest::getNaziv).thenComparing(Bolest::getOpis)).get();
        System.out.println("Prva bolest po redu: " + najmanja);

        Bolest najveca =  bolesti.stream().max(Comparator.comparing(Bolest::getOpis).thenComparing(Bolest::getNaziv)).get();
        System.out.println("Zadnja bolest po redu: " + najveca);


        //<-------------OSOBE---------------->
        System.out.println("\n#################################################### UNOS OSOBA #######################################################");
        Integer ukupanBrojLjudi = 0;
        do {
            try {
                System.out.print("Unesite koliko osoba �elite unjeti: ");
                ukupanBrojLjudi = unos.nextInt();
                Argument_Manji_Od_Jedan(ukupanBrojLjudi);

                logger.info("Broj je ispravno une�en, broj ljudi je: " + ukupanBrojZupanija);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        }while (flagIznimka);
        System.out.println("\nUnesite podatke o " + ukupanBrojLjudi + " osobe: ");
        for (int i = 0; i < ukupanBrojLjudi; i++)
            osobe.add(unosOsoba(unos, zupanije, bolesti, osobe, i));



        //ISPIS
        System.out.println("\n**************************************************** POPIS OSOBA ****************************************************\n");
        for(int indexOsobe = 0; indexOsobe < osobe.size(); indexOsobe++)
            ispisOsoba(osobe, indexOsobe);

        //ISPIS
        System.out.println("\n*********************************** ISPIS SVIH ZARA�ENIH OSOBA ODRE�ENOM BOLESTI ************************************\n");
        dodaj_Zarazene_Po_Bolesti_U_Mapu(bolesti, osobe, mapaZarazenihPoBolesti);
        ispis_Mape_Zarazenih_Po_Bolesti(mapaZarazenihPoBolesti);

        //ISPIS
        System.out.println("\n*********************************** �UPANIJA SA NAJVE�IM POSTOTKOM ZARA�ENOSTI **************************************\n");
        List<Zupanija> pomocnaListaZupanija = new ArrayList<Zupanija>(zupanije);
        Collections.sort(pomocnaListaZupanija, new CovidSorter());
        System.out.println("  Najvi�e zara�enih osoba ima u �upaniji " + pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getNaziv() + ": " + (int)pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getPostotakZarazenost() + "%.");
        System.out.println();
        System.out.println();


        //3.ZADATAK
        //Map<String, List<Bolest>> zadatak3 = bolesti.stream().collect(Collectors.groupingBy(Bolest::getNaziv));

        Map<String, List<Bolest>> zadatak3 = new HashMap<>();
        List<Bolest> fiksneBolesti = new ArrayList<>(bolesti);

        for(Bolest pomocna: bolesti)
        {
            List<Bolest> pomocniNizBolesti = new ArrayList<>();

            for(int i = 0; i < bolesti.size(); i++)
                if(pomocna.getNaziv().equals(fiksneBolesti.get(i).getNaziv()) == true)
                    pomocniNizBolesti.add(fiksneBolesti.get(i));

            if(pomocniNizBolesti.size() >= 1)
                zadatak3.put(pomocna.getNaziv(), pomocniNizBolesti);
        }
        System.out.println(zadatak3);


        logger.info("ZAVR�ETAK PROGRAMA");
        //KRAJ CIJELE MAIN FUNKCIJE
    }


    public static void ispis_Mape_Zarazenih_Po_Bolesti(Map<Bolest, List<Osoba>> mapa) {
        for(Bolest key : mapa.keySet())
        {
            if(key instanceof Virus)
                System.out.print("  Od virusa " + key.getNaziv() + " boluju: ");
            else
                System.out.print("  Od bolesti " + key.getNaziv() + " boluju: ");

            for(int i = 0; i < mapa.get(key).size(); i++)
            {
                if(i > 0)
                    System.out.print(", ");
                System.out.print(mapa.get(key).get(i).getIme() + " " + mapa.get(key).get(i).getPrezime());
            }
            System.out.println();
        }
    }



    public static void dodaj_Zarazene_Po_Bolesti_U_Mapu(Set<Bolest> bolesti, List<Osoba> osobe, Map<Bolest, List<Osoba>> mapa) {
        for(Bolest pomocna: bolesti)
        {
            List<Osoba> pomocniNizOsoba = new ArrayList<>();
            for(int i = 0; i < osobe.size(); i++)
                if(pomocna.getNaziv().equals(osobe.get(i).getZarazenBolescu().getNaziv()) == true)
                    pomocniNizOsoba.add(osobe.get(i));

            if(pomocniNizOsoba.size() >= 1)
                mapa.put(pomocna, pomocniNizOsoba);
        }
    }

    //METODA ZA UNOS �UPANIJA
    /**
     * Tra�i od korisnika da unese naziv �upanije, te zatim broj stanovnika te �upanije.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i broji �upanije
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unosZupanije(Scanner unos, int i) {
        String nazivZupanije;
        Integer brojStanovnika = 0;
        Integer brojZarazenihStanovnika = 0;
        Boolean flagIznimka = false;

        System.out.print((i + 1) + ". �upanija:");
        System.out.print("\n    Unesite naziv �upanije: ");
        nazivZupanije = unos.nextLine();


        //PROVJERA IZNIMKE ZA UNOS BROJA STANOVNIKA
        do {
            try {
                System.out.print("    Unesite broj stanovnika: ");
                brojStanovnika = unos.nextInt();
                Argument_Manji_Od_Jedan(brojStanovnika);

                logger.info("Broj je ispravno une�en, broj stanovnika je: " + brojStanovnika);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        //PROVJERA IZNIMKE ZA UNOS BROJA ZARA�ENIH
        do {
            try {
                System.out.print("    Unesite broj zara�enih stanovnika: ");
                brojZarazenihStanovnika = unos.nextInt();
                Argument_Manji_Od_Nula(brojZarazenihStanovnika);

                logger.info("Broj je ispravno une�en, broj zara�enih stanovnika je: " + brojZarazenihStanovnika);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        System.out.println();

        Zupanija zupanija = new Zupanija(nazivZupanije, brojStanovnika, brojZarazenihStanovnika);
        return zupanija;
    }


    /**
     * Provjerava da li je broj stanovnika negativan broj.
     *
     * @param x broj stanovnika �upanije
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void Argument_Manji_Od_Nula(Integer x) {
        if (x < 0)
            throw new OgranicenjeBroja("Pogre�ka, broj mora biti jednak ili ve�i od 0, molimo ponovite unos!");
    }

    /**
     * Provjerava da li je broj ve�i od 0.
     *
     * @param x broj
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void Argument_Manji_Od_Jedan(Integer x) {
        if (x <= 0)
            throw new OgranicenjeBroja("Pogre�ka, broj mora biti ve�i od 0, molimo ponovite unos!");
    }


    //METODA ZA UNOS SIMPTOMA
    /**
     * Tra�i od korisnika da unese naziv simptoma, te zatim u�estalost tog simptoma.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i broji simptome
     * @return vra�a simptom kao objekt
     */
    private static Simptom unosSimptoma(Scanner unos, int i) {
        String naziv;
        String vrijednost;
        Boolean ponovi;

        System.out.println((i + 1) + ". Simptom:");
        System.out.print("    Unesite naziv simptoma: ");
        naziv = unos.nextLine();

        do {
            System.out.print("    Unesite vrijednost simptoma (RIJETKO, SREDNJE ILI �ESTO): ");
            vrijednost = unos.nextLine();

            ponovi = false;

            if(vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.RIJETKO.getOpis()) == 0)
                vrijednost = EnumeracijaSimptoma.RIJETKO.getOpis();
            else if(vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.SREDNJE.getOpis()) == 0)
                vrijednost = EnumeracijaSimptoma.SREDNJE.getOpis();
            else if(vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.CESTO.getOpis()) == 0)
                vrijednost = EnumeracijaSimptoma.CESTO.getOpis();
            else
            {
                System.out.println("\n    Krivi unos, to�no unesite navedene vrijednosti: RIJETKO, SREDNJE ili �ESTO");
                ponovi = true;
            }
        }
        while (ponovi);
        System.out.println();

        Simptom simptom = new Simptom(naziv, vrijednost);
        return simptom;
    }


    //METODA ZA UNOS BOLESTI
    /**
     * Tra�i od korisnika da odabere vrstu bolesti, zatim njen naziv, broj simptoma te bolesti i da dodjeli
     * simptome bolesti.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param simptomi objekt koji se proslije�uje, slu�i za dodjeljivanje odre�enog simptoma bolesti
     * @param i broji bolesti
     * @param suma_Odabira_Simptoma_Za_Svaku_Bolest suma odabira simptoma za svaku bolest
     * @return vra�a bolest kao objekt
     */
    private static Bolest unosBolesti(Scanner unos, Set<Simptom> simptomi, int i, List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest, Integer ukupanBrojBolesti, Integer ukupanBrojVirusa) {
        String nazivBolesti;

        Integer zbrojOdabiraSimptomaPlusJedan = 0;
        Integer brojSimptoma = 0;
        Integer odabirVrsteBolesti = 0;
        Integer brojacIstihSimptomaUBolesti = 0;
        Integer odabirSimptoma = 0;

        Boolean odabranVirus = false;
        Boolean odabranaBolest = false;
        Boolean flagIznimka = false;
        Boolean ponoviOdNazivaBolesti = false;
        Boolean ponovi = false;

        Set<Simptom> simptomiBolesti = new HashSet<>();

        //UNOS BOLESTI ILI VIRUSA
        System.out.println((i + 1) + ". Vrsta zaraze:");
        System.out.println("    Unosite ili bolest ili virus?");
        System.out.println("    1) Bolest");
        System.out.println("    2) Virus");

        String opis = null;
        do {
            try {
                System.out.print("    Odaberite vrstu bolesti: ");
                odabirVrsteBolesti = unos.nextInt();
                provjeri_Valjanost_Odabira_Vrste_Bolesti(odabirVrsteBolesti, ukupanBrojBolesti, ukupanBrojVirusa);

                if (odabirVrsteBolesti == 1)
                    odabranaBolest = true;
                else if (odabirVrsteBolesti == 2)
                    odabranVirus = true;

                logger.info("Broj je ispravno une�en, vrsta bolesti je pod brojem: " + odabirVrsteBolesti);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA

                //1. ZADATAK
                System.out.print("    Unesite opis bolesti: ");
                opis = unos.nextLine();

            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        do {
            ponoviOdNazivaBolesti = false;

            //UNOS NAZIVA BOLESTI ILI VIRUSA
            System.out.print("\n    Unesite nazivBolesti bolesti ili virusa: ");
            nazivBolesti = unos.nextLine();


            //PROVJERA IZNIMKE ZA UNOS BROJA
            do {
                try {
                    System.out.print("    Unesite broj simptoma: ");
                    brojSimptoma = unos.nextInt();
                    provjera_Broja_Simptoma_Za_Bolest(brojSimptoma, simptomi.size());

                    logger.info("Broj je ispravno une�en, ukupni broj simptoma za trenutnu bolest je: " + brojSimptoma);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);


            List<Integer>provjera_Duplih_Simptoma_U_Bolesti = new ArrayList<>();

            zbrojOdabiraSimptomaPlusJedan = 0;
            for (int j = 0; j < brojSimptoma; j++) {
                //ODABERI SIMPTOM POMO�U BROJA
                do {
                    System.out.println("\n    Odaberite " + (j + 1) + ". simptom: ");

                    int x = 0;
                    for (Simptom element : simptomi)
                    {
                        System.out.println("    " + (x + 1) + ". " + element.getNaziv() + " " + element.getVrijednost());
                        x++;
                    }

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    do {
                        try {
                            System.out.print("    Odabir simptoma: ");
                            odabirSimptoma = unos.nextInt();
                            provjera_Broja_Simptoma_Za_Bolest(odabirSimptoma, simptomi.size());

                            logger.info("Broj je ispravno une�en, simptom je pod brojem: " + odabirSimptoma);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (OgranicenjeBroja iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);

                    //PONAVLJA LI SE ISTI SIMPTOM ZA ISTU BOLEST, NEMOGU�E JE DA BOLEST IMA 2 ILI VI�E ISTA SIMPTOMA
                    provjera_Duplih_Simptoma_U_Bolesti.add(odabirSimptoma);
                    brojacIstihSimptomaUBolesti = 0;
                    for (int k = 0; k < provjera_Duplih_Simptoma_U_Bolesti.size(); k++) {
                        if (odabirSimptoma.equals(provjera_Duplih_Simptoma_U_Bolesti.get(k))) {
                            brojacIstihSimptomaUBolesti++;
                            if (brojacIstihSimptomaUBolesti == 2) {
                                ponovi = true;
                                provjera_Duplih_Simptoma_U_Bolesti.remove(provjera_Duplih_Simptoma_U_Bolesti.size() - 1);
                            }
                        }
                    }

                    //UKOLIKO DO�E DO ISTIH SIMPTOMA UNUTAR ISTE BOLESTI
                    if (ponovi == true)
                    {
                        int counter = 0;
                        Simptom pomocniSimptom = new Simptom();
                        for(Simptom pomocni : simptomi)
                        {
                            if(counter == odabirSimptoma - 1)
                                pomocniSimptom = pomocni;
                            counter++;
                        }
                        System.out.println("\n    Svi simptomi trenutne zaraze moraju biti me�usobno razli�iti, simptom " + pomocniSimptom.getNaziv() + " je ve� odabran.\n    Molimo odaberite novi simptom.");
                    }
                }
                while (ponovi == true);

                zbrojOdabiraSimptomaPlusJedan = zbrojOdabiraSimptomaPlusJedan + odabirSimptoma + 1;

                int counter = 0;
                Simptom pomocniSimptom = new Simptom();
                for(Simptom pomocni : simptomi)
                {
                    if(counter == odabirSimptoma - 1)
                        pomocniSimptom = pomocni;
                    counter++;
                }
                simptomiBolesti.add(pomocniSimptom);
            }

            //System.out.println("Suma odabira + 1 simptoma za trenutnu bolest je: " + zbrojOdabiraSimptomaPlusJedan);


            //PROVJERAVA JEL POSTOJE BOLESTI SA ISTIM SIMPTOMIMA
            try {
                //USPORE�UJE SE SUMA ODABIRA SIMPTOMA TRENUTNE BOLESTI SA SUMOM ODABIRA SIMPTOMA ZA SVAKU BOLEST DO SADA UNE�ENU
                provjeriBolestiIstihSimptoma(zbrojOdabiraSimptomaPlusJedan, suma_Odabira_Simptoma_Za_Svaku_Bolest);
                suma_Odabira_Simptoma_Za_Svaku_Bolest.add(zbrojOdabiraSimptomaPlusJedan);
                ponoviOdNazivaBolesti = false;

            } catch (BolestIstihSimptoma iznimkaIstihSimptoma) {
                System.out.println("    " + iznimkaIstihSimptoma.getMessage() + "\n");
                logger.error(iznimkaIstihSimptoma.getMessage(), iznimkaIstihSimptoma);
                ponoviOdNazivaBolesti = true;
                simptomiBolesti.clear();
            }

        } while (ponoviOdNazivaBolesti == true);


        //BOLEST ILI VIRUS ?
        Bolest element = null;
        if (odabranaBolest)
            element = new Bolest(nazivBolesti, simptomiBolesti, opis);
        else if (odabranVirus)
            element = new Virus(nazivBolesti, simptomiBolesti, opis);

        System.out.println();
        return element;
    }


    /**
     * Provjerava je li korisnik odabrao ispravan simptom.
     *
     * @param odabirSimptoma broj pod kojim se simptom nalazi
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjera_Broja_Simptoma_Za_Bolest(Integer odabirSimptoma, Integer ukupniBrojSimptoma) {
        if (odabirSimptoma < 1 || odabirSimptoma > ukupniBrojSimptoma)
            throw new OgranicenjeBroja("Krivi unos, broj mora biti u intervalu od 1 do " + ukupniBrojSimptoma + ".");
    }



    /**
     * Provjerava koju vrstu bolesti je korisnik odabrao.
     *
     * @param odabirVrsteBolesti broj pod kojim se vrsta bolesti nalazi
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Vrste_Bolesti(Integer odabirVrsteBolesti, Integer ukupanBrojBolesti, Integer ukupanBrojVirusa)
    {
        if(odabirVrsteBolesti == 1)
        {
            brojacBolesti++;
            if(brojacBolesti > ukupanBrojBolesti)
                throw new OgranicenjeBroja("Ve� ste odabrali " + ukupanBrojBolesti + " bolesti, molimo odaberite virus");
        }
        else if(odabirVrsteBolesti == 2)
        {
            brojacVirusa++;
            if(brojacVirusa > ukupanBrojVirusa)
                throw new OgranicenjeBroja("Ve� ste odabrali " + ukupanBrojVirusa + " virusa, molimo odaberite bolest");
        }
        else if (odabirVrsteBolesti < 1 || odabirVrsteBolesti > 2)
            throw new OgranicenjeBroja("Krivi odabir vrste bolesti, molimo odaberite broj 1 ili 2");
    }


    //METODA ZA UNOS OSOBA
    /**
     * Tra�i unos osobe, odnosno njezinh podataka.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param zupanije niz svih �upanija koje korisnik na po�etku programa unio
     * @param bolesti niz svih bolesti koje je korisnik unio tijekom programa
     * @param osobe niz osoba koji �e pohraniti ovu osobu
     * @param i broji osobe
     * @return vra�a osobu kao objekt
     */
    private static Osoba unosOsoba(Scanner unos, Set<Zupanija> zupanije, Set<Bolest> bolesti, List<Osoba> osobe, int i) {
        String imeOsobe;
        String prezimeOsobe;
        Integer starostOsobe = 0;
        Boolean flagIznimka = true;


        System.out.println((i + 1) + ". Osoba:");
        //UNOS IMENA OSOBE
        System.out.print("    Unesite ime osobe: ");
        imeOsobe = unos.nextLine();
        //UNOS PREZIMENA OSOBE
        System.out.print("    Unesite prezime osobe: ");
        prezimeOsobe = unos.nextLine();
        //UNOS BROJA GODINA OSOBE I PROVJERA IZNIMKE
        do {
            System.out.print("    Unesite starost osobe: ");
            try {
                starostOsobe = unos.nextInt();
                provjeri_Broj_Godina_Osobe(starostOsobe);

                logger.info("Broj je ispravno une�en, starost osobe je: " + starostOsobe);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        //FINALNO INICIJALIZIRANJE TRENUTNE OSOBE SA SVIM PARAMETRIMA
        return new Osoba.Builder(imeOsobe)
                .surname(prezimeOsobe)
                .age(starostOsobe)
                .county(unos_Zupanije_Osobe(unos, zupanije)) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                .personInfection(unos_Bolesti_Osobe(unos, bolesti)) //UNOS BOLESTI OSOBE
                .contactedPersons(kontaktiranje_Sa_Zarazenim_Osobama(unos, osobe, i)) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                .makeItDone();
    }

    /**
     * Provjerava broj godina osobe.
     *
     * @param starostOsobe broj godina
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Broj_Godina_Osobe(Integer starostOsobe) {
        if (starostOsobe < 1)
            throw new OgranicenjeBroja("Pogre�ka, broj mora biti ve�i od 0, molimo ponovite unos!");
    }


    //METODA ZA UNOS PREBIVALI�NE �UPANIJE SVAKE OSOBE
    /**
     * Dodjeljivanje �upanije osobi.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param zupanije niz �upanija
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unos_Zupanije_Osobe(Scanner unos, Set<Zupanija> zupanije) {
        Integer odabirZupanije = 0;

        System.out.println("\n    Unesite �upaniju prebivali�ta osobe: ");
        Iterator<Zupanija> ponavljac = zupanije.iterator();
            for (int j = 0; j < zupanije.size(); j++)
                System.out.println("    " + (j + 1) + ". " + ponavljac.next().getNaziv());

            //PROVJERA IZNIMKE ZA UNOS BROJA
            Boolean flagIznimka = true;
            do {
                try {
                    System.out.print("    Odabir: ");
                    odabirZupanije = unos.nextInt();
                    provjeri_Odabir_Zupanije_Kod_Osobe(odabirZupanije, zupanije.size());

                    logger.info("Broj je ispravno une�en, broj odabrane �upanije je: " + odabirZupanije);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

            int counter = 0;
            Zupanija finalna = new Zupanija();
            for(Zupanija pomocna : zupanije)
            {
                if(counter == odabirZupanije - 1)
                    finalna = pomocna;
                counter++;
            }
            return finalna;
    }

    /**
     * Provjerava valjanost odabira �upanije kod osobe.
     *
     * @param odabirZupanije broj pod kojim se nalazi �upanija
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Odabir_Zupanije_Kod_Osobe(Integer odabirZupanije, Integer ukupanBrojZupanija) {
        if (odabirZupanije < 1 || odabirZupanije > ukupanBrojZupanija)
            throw new OgranicenjeBroja("Krivi unos, odabrite �upaniju osobe koja se nalazi na popisu (interval od 1 do " + ukupanBrojZupanija + ").");
    }


    //METODA ZA UNO�ENJE BOLESTI SVAKE OSOBE
    /**
     * Dodjeljivanje bolesti osobi.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param bolesti niz bolesti
     * @return vra�a bolest kao objekt (ime, niz simptoma)
     */
        private static Bolest unos_Bolesti_Osobe(Scanner unos, Set<Bolest> bolesti) {
        Integer odabirBolesti = 0;

            System.out.println("\n    Unesite bolest ili virus osobe: ");
            Iterator<Bolest> ponavljacBolesti = bolesti.iterator();
            for (int j = 0; j < bolesti.size(); j++)
                System.out.println("    " + (j + 1) + ". " + ponavljacBolesti.next().getNaziv());

            //PROVJERA IZNIMKE ZA UNOS BROJA
            Boolean flagIznimka = true;
            do {
                try {
                    System.out.print("    Odabir: ");
                    odabirBolesti = unos.nextInt();
                    provjeri_Odabir_Bolesti_Kod_Osobe(odabirBolesti, bolesti.size());

                    logger.info("Broj je ispravno une�en, odabrana bolest je pod brojem: " + odabirBolesti);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

            int counter = 0;
            Bolest finalna = new Bolest();
            for(Bolest pomocna : bolesti)
            {
                if(counter == odabirBolesti - 1)
                    finalna = pomocna;
                counter++;
            }

        return finalna;
    }


    /**
     * Provjerava valjanost odabira bolesti kod osobe.
     *
     * @param odabirBolesti broj pod kojim se nalazi bolest
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Odabir_Bolesti_Kod_Osobe(Integer odabirBolesti, Integer ukupanBrojBolesti) {
        if (odabirBolesti < 1 || odabirBolesti > ukupanBrojBolesti)
            throw new OgranicenjeBroja("Krivi unos, odabrite bolest ili virus koji se nalazi na popisu (interval od 1 do " + ukupanBrojBolesti + ").");
        else
            System.out.println();
    }


    //METODA ZA UNO�ENJE KONTAKATA SA ZARA�ENIM OSOBAMA
    /**
     * Provjerava s kime je trenutna osoba bila u kontaktu.
     *
     * @param unos  varijabla za unos preko tipkovnice
     * @param osobe niz osoba
     * @param i broja� osoba
     * @return vra�a niz kontaktiranih osoba
     */
    private static List<Osoba> kontaktiranje_Sa_Zarazenim_Osobama(Scanner unos, List<Osoba> osobe, int i) {
        Integer brojKontaktiranihOsoba = 0;
        Boolean ponovi = true;

        //OD 2. OSOBE (INDEKS 1) PA NADALJE DOPUSTI UNOS BROJA OSOBA KOJE SU BILE U KONTAKTU S TOM OSOBOM
        if (i > 0) {
            do {
                //PROVJERA IZNIMKE ZA UNOS BROJA
                Boolean flagIznimka = true;
                do {
                    System.out.print("    Unesite broj osoba koje su bile u kontaktu s tom osobom: ");
                    try {
                        brojKontaktiranihOsoba = unos.nextInt();
                        provjeri_Valjanost_Broja_Kontaktiranih_Osoba(i, brojKontaktiranihOsoba);

                        logger.info("Broj je ispravno une�en, ukupan broj kontaktiranih osoba je: " + brojKontaktiranihOsoba);

                        flagIznimka = false;
                        ponovi = false;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (InputMismatchException iznimkaBroj) {
                        iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                        System.out.println("\n    " + iznimkaBroj.getMessage());
                        logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (OgranicenjeBroja iznimkaOgranicenja) {
                        System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                        logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    }
                } while (flagIznimka == true);
            }
            while (ponovi);
            System.out.println();
        }

        //OMOGU�UJE UNOS PRETHODNIH ZARA�ENIH OSOBA, TIME �E SE STVORITI OBJEKTI U NIZU PRETHODNIH ZARA�ENIH OSOBA
        if (brojKontaktiranihOsoba > 0) {
            Integer odabirKontaktiraneOsobe = 0;
            Integer[] nizOdabranihOsoba = new Integer[0];

            System.out.println("    Unesite osobe koje su bile u kontaktu s tom osobom:");
            for (int j = 0; j < brojKontaktiranihOsoba; j++)
            {
                nizOdabranihOsoba = Arrays.copyOf(nizOdabranihOsoba, nizOdabranihOsoba.length + 1);
                do {
                    System.out.println("    Odaberite " + (j + 1) + ". osobu:");
                    for (int k = 0; k < i; k++) {
                        System.out.println("    " + (k + 1) + ". " +  osobe.get(k).getIme() + " " + osobe.get(k).getPrezime());
                    }

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    Boolean flagIznimka = true;
                    do {
                        System.out.print("    Odabir: ");
                        try {
                            odabirKontaktiraneOsobe = unos.nextInt();
                            provjeri_Valjanost_Odabira_Kontaktirane_Osobe(i, odabirKontaktiraneOsobe, j);

                            logger.info("Broj je ispravno une�en, odabir kontaktirane osobe je pod brojem: " + odabirKontaktiraneOsobe);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (OgranicenjeBroja iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage() + "\n");
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);


                    if (ponovi == false) {
                        //POSTOJE LI DUPLIKATI U KONTAKTIRANIM OSOBAMA
                        try {
                            nizOdabranihOsoba[j] = odabirKontaktiraneOsobe;
                            provjeraDuplikataKontaktiranihOsoba(nizOdabranihOsoba);
                            logger.info("Nema duplikata me�u kontaktiranim osobama");
                            ponovi = false;

                        } catch (DuplikatKontaktiraneOsobe iznimkaDupleKontaktiraneOsobe) {
                            System.out.println("    " + iznimkaDupleKontaktiraneOsobe.getMessage() + "\n");
                            logger.error(iznimkaDupleKontaktiraneOsobe.getMessage(), iznimkaDupleKontaktiraneOsobe);
                            ponovi = true;
                        }
                    }
                }
                while (ponovi);


                System.out.println();
            }

            List<Osoba> kontaktiraneZarazeneOsobe = new ArrayList<>();
            for(int k = 0; k < nizOdabranihOsoba.length; k++)
                kontaktiraneZarazeneOsobe.add(osobe.get(nizOdabranihOsoba[k] - 1));

            return kontaktiraneZarazeneOsobe;
        } else {
            return null;
        }
    }


    /**
     * Provjerava valjanost odabira kontaktirane osobe.
     *
     * @param i max broj osoba s kojima je osoba mogla biti u kontaktu
     * @param odabirKontaktiraneOsobe broj pod kojim se osoba nalazi
     * @param j index kontaktirane osobe u nizu kontaktiranih osoba
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Kontaktirane_Osobe(int i, Integer odabirKontaktiraneOsobe, int j) {
        if (odabirKontaktiraneOsobe < 1 || odabirKontaktiraneOsobe > i)
            throw new OgranicenjeBroja("Krivi unos, odabrite kontaktiranu osobu koja se nalazi na popisu (interval od 1 do " + i + "). Ponovite unos za " + (j + 1) + ". osobu!");
    }


    /**
     * Provjerava valjanost za ukupan broj s kojima je osoba mogla kontaktirati
     *
     * @param i index trenutne osobe, samo osobe koje dolaze prije trenutne osobe mogu biti kontaktirane
     * @param brojKontaktiranihOsoba broj kontaktiranih osoba
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Broja_Kontaktiranih_Osoba(int i, Integer brojKontaktiranihOsoba) {
        if (brojKontaktiranihOsoba > i || brojKontaktiranihOsoba < 0)
            throw new OgranicenjeBroja("Neispravan unos broja kontaktiranih osoba, mo�ete odabrani maksimalno " + i + ", a minimalno 0 osoba.");
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA

    /**
     * Ispisuje podatke o osobama.
     *
     * @param osobe niz osoba
     * @param i index osobe u nizu
     */
    private static void ispisOsoba(List<Osoba> osobe, Integer i)
    {

        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe.get(i).getIme() + " " +osobe.get(i).getPrezime());
        System.out.println("    Starost: " + osobe.get(i).getStarost());
        System.out.println("    �upanija prebivali�ta: " + osobe.get(i).getZupanija().getNaziv());
        System.out.println("    Zara�en bole��u: " + osobe.get(i).getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");
        //osobe[i] JE TRENUTNA OSOBA KOJA MO�E SADR�AVATI NIZ ZAR�ENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe.get(i).getKontaktiraneOsobe() != null) //PROVJERVA DA LI NIZ ZARA�ENIH OSOBA UOP�E POSTOJI
        {
            for (int j = 0; j < osobe.get(i).getKontaktiraneOsobe().size(); j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print( osobe.get(i).getKontaktiraneOsobe().get(j).getIme() + " " +  osobe.get(i).getKontaktiraneOsobe().get(j).getPrezime());
            }
        } else //AKO NIZ ZARA�ENIH OSOBA NE POSTOJI
        {
            System.out.print("Nema kontaktiranih osoba.");
        }
        System.out.println("\n");
    }

    /**
     * Provjerava ako se ponavljaju iste kontaktirane osobe
     *
     * @param niz niz odabira kontaktiranih osoba
     * @throws DuplikatKontaktiraneOsobe govori da je do�lo do duplikata
     */
    //METODA ZA PROVJERU DUPLIKATA KONTAKTIRANIH ZARA�ENIH OSOBA I BACANJE IZNIMKE
    private static void provjeraDuplikataKontaktiranihOsoba(Integer[] niz) throws DuplikatKontaktiraneOsobe {
        int counter = 0;
        for (int i = 0; i < niz.length; i++) {
            if (niz[niz.length - 1] == niz[i]) {
                counter++;
                if (counter == 2) {
                    throw new DuplikatKontaktiraneOsobe("Odabrana osoba se ve� nalazi me�u kontaktiranim osobama. Molimo Vas da odaberete neku drugu osobu.");
                }
            }
        }
    }


    //METODA ZA PROVJERAVANJE ISTIH SIMPTOMA KOD BOLESTI
    /**
     * Provjerava ponavljaju li se isti simptomi
     *
     * @param element suma odabira simptoma za jednu bolest
     * @param suma_Odabira_Simptoma_Za_Svaku_Bolest niz suma odabira simptoma za svaku bolest
     * @throws BolestIstihSimptoma ne dopu�ta unos bolesti koje imaju iste simptome
     */
    private static void provjeriBolestiIstihSimptoma(Integer element, List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest) {
        Integer ponavljanje = 0;

        for (int i = 0; i < suma_Odabira_Simptoma_Za_Svaku_Bolest.size(); i++)
            if (element == suma_Odabira_Simptoma_Za_Svaku_Bolest.get(i))
                ponavljanje++;

        if (ponavljanje >= 1)
            throw new BolestIstihSimptoma("Pogre�an unos, ve� ste unijeli bolest ili virus s istim simptomima. Molimo ponovite unos.");
    }

    //KRAJ CIJELE KLASE: GLAVNA
}
