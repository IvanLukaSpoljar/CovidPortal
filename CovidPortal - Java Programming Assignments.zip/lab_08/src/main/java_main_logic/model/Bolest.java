package main.java_main_logic.model;

import java.util.List;
import java.util.Set;

/**
 * Slu�i za kreiranje objekta bolest u klasi Glavna.
 */
public class Bolest extends ImenovaniEntitet{
    private List <Simptom> simptomi;

    //KONSTRUKTOR

    /**
     * Prima naziv i niz objekata simptoma kao parametre
     *
     * @param naziv ime bolesti
     * @param simptomi simptomi bolesti
     */
    public Bolest(Long id, String naziv, List<Simptom> simptomi)
    {
        super(id, naziv);
        this.simptomi = simptomi;
    }
    public Bolest(){}


    //NAZIV - GETTER I SETTER SE NALAZI U IMENOVANOM ENTITETU

    //SIMPTOMI
    public List<Simptom> getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(List<Simptom> simptomi) {
        this.simptomi = simptomi;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bolest bolest = (Bolest) o;

        return simptomi != null ? simptomi.equals(bolest.simptomi) : bolest.simptomi == null;
    }

    @Override
    public int hashCode() {
        return simptomi != null ? simptomi.hashCode() : 0;
    }

    @Override
    public String toString()
    {
        return getNaziv();
    }
}
