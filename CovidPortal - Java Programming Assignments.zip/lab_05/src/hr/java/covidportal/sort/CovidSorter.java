package hr.java.covidportal.sort;

import hr.java.covidportal.model.ImenovaniEntitet;
import hr.java.covidportal.model.Virus;
import hr.java.covidportal.model.Zupanija;

import java.util.Comparator;

public class CovidSorter <T extends ImenovaniEntitet> implements Comparator<T>
{
    /*@Override
    public int compare(Zupanija z1, Zupanija z2)
    {
        if(z1.getPostotakZarazenost() > z2.getPostotakZarazenost())
        {
            return 1;
        }
        else if(z1.getPostotakZarazenost() < z2.getPostotakZarazenost())
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }*/

    @Override
    public int compare(T t1, T t2)
    {
        if(t1 instanceof Zupanija && t2 instanceof Zupanija)
        {
            Zupanija z1 = (Zupanija) t1;
            Zupanija z2 = (Zupanija) t2;

            //UZLAZNO SORTIRANJE
            if(z1.getPostotakZarazenost() > z2.getPostotakZarazenost())
            {
                return 1;
            }
            else if(z1.getPostotakZarazenost() < z2.getPostotakZarazenost())
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }

        if(t1 instanceof Virus && t2 instanceof Virus)
        {
            Virus v1 = (Virus) t1;
            Virus v2 = (Virus) t2;

            //SILAZNO SORTIRANJE
            if(v1.getNaziv().compareTo(v2.getNaziv()) <= -1)
            {
                return 1;
            }
            else if(v1.getNaziv().compareTo(v2.getNaziv()) >= 1)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
        return 0;
    }
}
