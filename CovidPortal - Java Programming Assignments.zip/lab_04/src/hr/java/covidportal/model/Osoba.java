package hr.java.covidportal.model;

import java.util.List;

/**
 * Služi za kreiranje objekta osoba u klasi Glavna.
 */
public class Osoba {
    private String ime;
    private String prezime;
    private Integer starost;

    private Zupanija zupanija;
    private Bolest zarazenBolescu;
    private List<Osoba> kontaktiraneOsobe;

    //KONSTRUKTOR
    public Osoba(String ime, String prezime, Integer starost, Zupanija zupanija, Bolest zarazenBolescu, List<Osoba> kontaktiraneOsobe) {
        this.ime = ime;
        this.prezime = prezime;
        this.starost = starost;
        this.zupanija = zupanija;
        this.zarazenBolescu = zarazenBolescu;
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }

    //KONSTRUKTOR KOJI SE KORISTI U KLASI BUILDER U DIJELU MAKEITDONE
    private Osoba() {
    }


    /**
     * Kreiranje pattern buildera za klasu Osoba.
     */
    public static class Builder {
        private String ime;
        private String prezime;
        private Integer starost;

        private Zupanija zupanija;
        private Bolest zarazenBolescu;
        private List<Osoba> kontaktiraneOsobe;

        /**
         * Metoda u pattern builderu za ime osobe.
         *
         * @param ime ime osobe
         */
        public Builder(String ime) {
            this.ime = ime;
        }

        /**
         * Metoda u pattern builderu za prezime osobe.
         *
         * @param prezime prezime osobe
         */
        public Builder surname(String prezime) {
            this.prezime = prezime;
            return this;
        }

        /**
         * Metoda u pattern builderu za starost osobe.
         *
         * @param starost starost osobe
         */
        public Builder age(Integer starost) {
            this.starost = starost;
            return this;
        }

        /**
         * Metoda u pattenr builderu za županiju osobe.
         *
         * @param zupanija županija osobe
         */
        public Builder county(Zupanija zupanija) {
            this.zupanija = zupanija;
            return this;
        }

        /**
         * Metoda u pattern builderu za bolest osobe.
         *
         * @param zarazenBolescu bolest osobe
         */
        public Builder personInfection(Bolest zarazenBolescu) {
            this.zarazenBolescu = zarazenBolescu;
            return this;
        }

        /**
         * Metoda u pattern builderu za kontaktirane osobe.
         *
         * @param kontaktiraneOsobe kontaktiraneOsobe osobe
         */
        public Builder contactedPersons(List<Osoba> kontaktiraneOsobe) {
            this.kontaktiraneOsobe = kontaktiraneOsobe;
            return this;
        }

        /**
         * Metoda u patter builderu za dodjeljivanje svih podataka o osobi.
         */
        public Osoba makeItDone() {
            //PODATCI UPISANI U BILDER SE ŠALJU U OSOBU
            Osoba pomocna = new Osoba();
            pomocna.ime = this.ime;
            pomocna.prezime = this.prezime;
            pomocna.starost = this.starost;
            pomocna.zupanija = this.zupanija;
            pomocna.zarazenBolescu = this.zarazenBolescu;
            pomocna.kontaktiraneOsobe = this.kontaktiraneOsobe;

            //BOLEST INSTANCA OD VIRUSA ? JE LI RIJEČ O BOLESTI ILI VIRUSU ?
            if(this.kontaktiraneOsobe != null) {
                if (this.zarazenBolescu instanceof Virus virus) {
                    for (int i = 0; i < kontaktiraneOsobe.size(); i++) {
                        virus.prelazakZarazeNaOsobu(this.kontaktiraneOsobe.get(i));
                    }
                }
            }

            return pomocna;
        }
    }

    //GETTERI I SETTERI KLASE OSOBA
    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Integer getStarost() {
        return starost;
    }

    public void setStarost(Integer starost) {
        this.starost = starost;
    }

    public Zupanija getZupanija() {
        return zupanija;
    }

    public void setZupanija(Zupanija zupanija) {
        this.zupanija = zupanija;
    }

    public Bolest getZarazenBolescu() {
        return zarazenBolescu;
    }

    public void setZarazenBolescu(Bolest zarazenBolescu) {
        this.zarazenBolescu = zarazenBolescu;
    }

    public List<Osoba> getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }

    public void setKontaktiraneOsobe(List<Osoba> kontaktiraneOsobe) {
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Osoba osoba = (Osoba) o;

        if (ime != null ? !ime.equals(osoba.ime) : osoba.ime != null) return false;
        if (prezime != null ? !prezime.equals(osoba.prezime) : osoba.prezime != null) return false;
        if (starost != null ? !starost.equals(osoba.starost) : osoba.starost != null) return false;
        if (zupanija != null ? !zupanija.equals(osoba.zupanija) : osoba.zupanija != null) return false;
        if (zarazenBolescu != null ? !zarazenBolescu.equals(osoba.zarazenBolescu) : osoba.zarazenBolescu != null)
            return false;
        return kontaktiraneOsobe != null ? kontaktiraneOsobe.equals(osoba.kontaktiraneOsobe) : osoba.kontaktiraneOsobe == null;
    }

    @Override
    public int hashCode() {
        int result = ime != null ? ime.hashCode() : 0;
        result = 31 * result + (prezime != null ? prezime.hashCode() : 0);
        result = 31 * result + (starost != null ? starost.hashCode() : 0);
        result = 31 * result + (zupanija != null ? zupanija.hashCode() : 0);
        result = 31 * result + (zarazenBolescu != null ? zarazenBolescu.hashCode() : 0);
        result = 31 * result + (kontaktiraneOsobe != null ? kontaktiraneOsobe.hashCode() : 0);
        return result;
    }
}

