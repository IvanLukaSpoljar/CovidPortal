package hr.java.covidportal.model;

/**
 * Služi za kreiranje objekta bolest u klasi Glavna.
 */
public class Bolest extends ImenovaniEntitet {
    private Simptom[] simptomi;

    //KONSTRUKTOR

    /**
     * Prima naziv i niz objekata simptoma kao parametre
     *
     * @param naziv ime bolesti
     * @param simptomi simptomi bolesti
     */
    public Bolest(String naziv, Simptom[] simptomi) {
        super(naziv);
        this.simptomi = simptomi;
    }

    //NAZIV
    public String getNaziv() {
        return super.getNaziv();
    }

    public void setNaziv(String naziv) {
        super.setNaziv(naziv);
    }


    //SIMPTOMI
    public Simptom[] getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(Simptom[] simptomi) {
        this.simptomi = simptomi;
    }
}
