package main.java_main_logic.kontroleri_ekrana.pretraga;

import javafx.scene.control.Button;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.model.Bolest;
import main.java_main_logic.model.Simptom;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.model.Virus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaBolestiController implements Initializable, PovijestKretanjaPoEkranima {

    List<Bolest> listaSvihBolesti = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaBolesti.fxml";
    public static final Logger logger = LoggerFactory.getLogger(PretragaBolestiController.class);

    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Bolest> tablicaBolesti;
    @FXML
    private TableColumn<Bolest, String> stupacNaziva;
    @FXML
    private TableColumn<Bolest, Set<Simptom>> stupacSimptoma;



    @FXML
    public void odiNatrag() throws IOException
    {
       prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o Bolestima");
    }
    @FXML
    public void odiNaprijed() throws IOException
    {
       slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }
    @FXML
    public void pretrazi() throws IOException
    {
        tablicaBolesti.setItems(FXCollections.observableList(listaSvihBolesti));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaBolesti.setItems(FXCollections.observableList(
                    listaSvihBolesti.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Bolesti");
        logger.info("Korisnik je otvorio ekran o Bolestima");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Bolest, String>("naziv"));
        stupacSimptoma.setCellValueFactory(new PropertyValueFactory<Bolest, Set<Simptom>>("simptomi"));

        try {
            ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZarazaIzBaze(BazaPodataka.dohvatiSveZarazeIzBaze());

            for(Bolest x : ListeZupanijaSimptomaBolestiVirusaOsoba.sveBolesti)
            {
                listaSvihBolesti.add(x);
            }

        } catch (SQLException | IOException throwables) {
            throwables.printStackTrace();
        }


        tablicaBolesti.setItems(FXCollections.observableList(listaSvihBolesti));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);

        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();
    }
}

