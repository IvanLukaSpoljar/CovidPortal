package hr.java.covidportal.model;

import java.util.Set;

/**
 *Slu�i za kreiranje objekta bolest u klasi Glavna.
 */
public class Virus extends Bolest implements Zarazno {
    //KONSTRUKTOR
    public Virus(String naziv, Set<Simptom> simptomi, String opis) {
        super(naziv, simptomi, opis);
    }


    /**
     * Prenosi virus
     * @param osoba objekt klase Osoba
     */


    @Override
    public void prelazakZarazeNaOsobu(Osoba osoba) {
        osoba.setZarazenBolescu(this);
    }
}
