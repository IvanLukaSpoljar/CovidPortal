package hr.java.covidportal.model;

public abstract class ImenovaniEntitet {
    private String naziv;

    //KONSTRUKTOR
    public ImenovaniEntitet(String naziv) {
        this.naziv = naziv;
    }

    //NAZIV
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }


}
