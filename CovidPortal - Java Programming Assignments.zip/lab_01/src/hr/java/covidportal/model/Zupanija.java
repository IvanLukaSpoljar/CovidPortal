package hr.java.covidportal.model;

public class Zupanija {
    private String naziv;
    private Integer brojStanovnika;
    private String sifraZupanije;

    //KONSTRUKTOR
    public Zupanija(String naziv, Integer brojStanovnika, String sifraZupanije) {
        this.naziv = naziv;
        this.brojStanovnika = brojStanovnika;
        this.sifraZupanije = sifraZupanije;
    }


    //NAZIV
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    //BROJSTANOVNIKA
    public Integer getBrojStanovnika() {
        return brojStanovnika;
    }

    public void setBrojStanovnika(Integer brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }
}
