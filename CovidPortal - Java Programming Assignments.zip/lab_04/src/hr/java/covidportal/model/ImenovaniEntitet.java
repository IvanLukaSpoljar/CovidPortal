package hr.java.covidportal.model;

/**
 * Nadklasa
 */
public abstract class ImenovaniEntitet {
    private String naziv;

    //KONSTRUKTOR

    /**
     * Prima naziv
     * @param naziv naziv
     */
    public ImenovaniEntitet(String naziv) {
        this.naziv = naziv;
    }
    public ImenovaniEntitet(){}

    //NAZIV
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
}
