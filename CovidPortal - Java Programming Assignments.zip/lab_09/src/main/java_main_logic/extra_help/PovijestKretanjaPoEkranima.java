package main.java_main_logic.extra_help;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import main.java_main_logic.GLAVNO.Main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public interface PovijestKretanjaPoEkranima {
    List<String> svePutanje = new ArrayList<>();
    List<String> prijenosNoveGrane = new ArrayList<>();
    List<String> prosliEkran = new ArrayList<>();


    public default void dodavanjePutanjaKretanjaUListu(String putanjaTrenutnogFXMLa) {

        System.out.println("\n\n\n");

        prosliEkran.add(putanjaTrenutnogFXMLa);
        Integer indeksTrenutnogEkranaUListiPutanja = -1;

        Boolean otvaranjeIstogEkrana = false;
        Boolean korisnikOtvaraJedanTeIstiEkran = false;


        if (prijenosNoveGrane.size() < 1)
            if (svePutanje.size() > 0)
                for (int i = 0; i < svePutanje.size(); i++) {
                    if (svePutanje.get(i).equals(putanjaTrenutnogFXMLa)) {
                        otvaranjeIstogEkrana = true;
                        indeksTrenutnogEkranaUListiPutanja = i;
                        if (svePutanje.get(svePutanje.size() - 1).equals(putanjaTrenutnogFXMLa))
                            korisnikOtvaraJedanTeIstiEkran = true;
                    }
                }


        if (otvaranjeIstogEkrana == false && prijenosNoveGrane.size() < 1) {

            if (svePutanje.size() > 1 && indeksTrenutnogEkranaUListiPutanja >= 0 && svePutanje.get(indeksTrenutnogEkranaUListiPutanja).equals(putanjaTrenutnogFXMLa) == false)
                for (int i = svePutanje.size() - 1; i >= indeksTrenutnogEkranaUListiPutanja + 1; i--)
                    svePutanje.remove(i);
            else if (svePutanje.size() > 0 && svePutanje.indexOf(prosliEkran.get(prosliEkran.size() - 2)) + 1 < svePutanje.size() && prosliEkran.size() >= 2) {
                Integer idneksProslogEkranaUGlavnimPutanjama = svePutanje.indexOf(prosliEkran.get(prosliEkran.size() - 2));
                for (int i = (svePutanje.size() - 1); i >= idneksProslogEkranaUGlavnimPutanjama + 1; i--)
                    svePutanje.remove(i);
            }
            svePutanje.add(putanjaTrenutnogFXMLa);
        } else if (korisnikOtvaraJedanTeIstiEkran == false)
            prijenosNoveGrane.add(putanjaTrenutnogFXMLa);


        System.out.println("Lista svih putanja kretanja korisnika kroz program pri po�etku otvaranja ekrana: " + svePutanje);
        System.out.println("Putanja trenutno otvorenog ekrana je: " + putanjaTrenutnogFXMLa);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");


        //AKO SE DOGODI GRANANJE, PAMTI ZADNJE GRANANJE
        if (prijenosNoveGrane.size() == 2) {
            System.out.println("Pomo�na lista sa putanjama koje bi se mogle postaviti u listu kretanja  : " + prijenosNoveGrane);
            Integer izvuciIndeksNovePutanje = svePutanje.indexOf(prijenosNoveGrane.get(0)) + 1;

            System.out.println("Indeks mjesta u listi svih putanja na kojem se nalazi putanja koja �e se zamjeniti: " + izvuciIndeksNovePutanje);

            if (prijenosNoveGrane.get(0).equals(prijenosNoveGrane.get(1)) == false && prijenosNoveGrane.get(1).equals(putanjaTrenutnogFXMLa) == true && prijenosNoveGrane.get(1).equals(svePutanje.get(izvuciIndeksNovePutanje)) == false && izvuciIndeksNovePutanje >= 0) {

                System.out.println("Duljina liste svih putanja je: " + svePutanje.size());
                //PROMJENI GRANU PAM�ENJA PUTANJA
                System.out.println("---------------------------------------------------------------------------------------------");
                System.out.println("Putanja koj �e se dodati u listu svih putanja: [" + prijenosNoveGrane.get(1) + "] ");

                Boolean ubaciUPutanje = true;

                Boolean ubaci = true;
                for (int i = 0; i <= svePutanje.indexOf(prijenosNoveGrane.get(0)); i++)
                    if (svePutanje.get(i).equals(prijenosNoveGrane.get(1)) == true)
                        ubaci = false;


                if (ubaci) {
                    for (int i = svePutanje.size() - 1; i >= izvuciIndeksNovePutanje; i--) {
                        System.out.println("Putanja koj se uklanja iz: [" + svePutanje.get(i) + "] ima indeks: " + i);
                        svePutanje.remove(i);
                    }
                    System.out.println("Nakon micanje odre�enih putanja glavna lista je: " + svePutanje);
                    svePutanje.add(prijenosNoveGrane.get(1));
                }
            }

            for (int i = prijenosNoveGrane.size() - 1; i >= 0; i--)
                prijenosNoveGrane.remove(i);
        }
        System.out.println("Izmjenjenja lista putanja : " + svePutanje);
    }




    default Integer indeksPozicijaTrenutnogEkrana(String putanjaTrenutnogFXMLa) {
        Integer indeksTrenutnogEkrana = -1;
        for (int i = 0; i < svePutanje.size(); i++)
            if (svePutanje.get(i).equals(putanjaTrenutnogFXMLa))
                indeksTrenutnogEkrana = i;

        return indeksTrenutnogEkrana;
    }





    public default void prethodniEkran(String putanjaTrenutnogFXMLa) throws IOException {
        System.out.println("\n\n\n");

        Integer indeksProslogEkrana = indeksPozicijaTrenutnogEkrana(putanjaTrenutnogFXMLa) - 1;

        if (prijenosNoveGrane.size() > 0) {
            for (int i = prijenosNoveGrane.size() - 1; i >= 0; i--)
                prijenosNoveGrane.remove(i);
        }

        System.out.println("Pritisnut je gumb NATRAG");


        String putanjaProslogFXMLa = new String();
        if (indeksProslogEkrana >= 0)
            putanjaProslogFXMLa = svePutanje.get(indeksProslogEkrana);
        else {
            putanjaProslogFXMLa = "layout/pocetniEkran.fxml";

            //BRISANJE POVIJESTI KRETANJA
            for (int i = svePutanje.size() - 1; i >= 0; i--)
                svePutanje.remove(i);

            //BRISANJE POMO�NE POVIJESTI KRETANJA
            for (int i = prosliEkran.size() - 1; i >= 0; i--)
                prosliEkran.remove(i);
        }

        System.out.println("Ekran iz kojeg se izlazi: " + putanjaTrenutnogFXMLa);
        System.out.println("Ekran u koji se ulazi (trenutno je otvoren): " + putanjaProslogFXMLa);

        Parent pretragaNekogEkranaFrame = FXMLLoader.load(PovijestKretanjaPoEkranima.class.getClassLoader().getResource(putanjaProslogFXMLa));
        Scene pretragaNekogEkranaScene = new Scene(pretragaNekogEkranaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaNekogEkranaScene);
    }






    public default void slijedeciEkran(String putanjaTrenutnogFXMLa) throws IOException {

        System.out.println("\n\n\n");
        Integer indeksSlijedecegEkrana = indeksPozicijaTrenutnogEkrana(putanjaTrenutnogFXMLa) + 1;

        if (prijenosNoveGrane.size() > 0) {
            for (int i = prijenosNoveGrane.size() - 1; i >= 0; i--)
                prijenosNoveGrane.remove(i);
        }

        System.out.println("Pritisnut je gumb SLIJEDE�I");

        String putanjaSlijedecegFXMLa = new String();
        if (indeksSlijedecegEkrana < svePutanje.size())
            putanjaSlijedecegFXMLa = svePutanje.get(indeksSlijedecegEkrana);

        System.out.println("Ekran iz kojeg se izlazi: " + putanjaTrenutnogFXMLa);
        System.out.println("Ekran u koji se ulazi (trenutno je otvoren): " + putanjaSlijedecegFXMLa);

        if (putanjaSlijedecegFXMLa.isEmpty() == false) {
            Parent pretragaNekogEkranaFrame = FXMLLoader.load(PovijestKretanjaPoEkranima.class.getClassLoader().getResource(putanjaSlijedecegFXMLa));
            Scene pretragaNekogEkranaScene = new Scene(pretragaNekogEkranaFrame, 600, 400);
            Main.getMainStage().setScene(pretragaNekogEkranaScene);
        }
    }




    public default void vidljivostGumba(Button naprijedGumb, String putanjaDoTrenutnogFXMLa)
    {
        //VIDLJIVOST NAPRIJED GUMBA
        if(indeksPozicijaTrenutnogEkrana(putanjaDoTrenutnogFXMLa) + 1 > svePutanje.size() - 1)
            naprijedGumb.setStyle("-fx-pref-height: 0");
        else
            naprijedGumb.setStyle("-fx-pref-height: 25");
    }
}
