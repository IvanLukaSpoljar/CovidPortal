package hr.java.covidportal.niti;

import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.model.Virus;
import main.java_main_logic.model.Zupanija;
import main.java_main_logic.sort.CovidSorter;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class NajviseZarazenihNit implements Runnable {

    public static boolean nitPostoji = false;


    List<Zupanija> trenutnaListaZupanija = new ArrayList<>();
    Boolean pokreni;
    public static Zupanija najifektivnijaZupanija = null;


    public NajviseZarazenihNit(List<Zupanija> orgListaZupanija) {
        trenutnaListaZupanija = new ArrayList<>(orgListaZupanija);
        pokreni = true;
    }

    public NajviseZarazenihNit() {
    }


    public void setPokreni(Boolean pokreni) {
        this.pokreni = pokreni;
    }

    public String vratiNajinfektivnijuZupaniju() {
        return najifektivnijaZupanija.getNaziv();
    }


    @Override
    public void run() {

        while (true) {
            try {
                najifektivnijaZupanija = BazaPodataka.dohvatiSveZupanije().stream()
                        .max(Comparator.comparingDouble(z1 -> z1.getPostotakZarazenost()))
                        .get();

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException exception) {
                exception.printStackTrace();
            }


            String nazivZupanije = najifektivnijaZupanija.getNaziv();
            Double najveciPostotakZarazenosti = najifektivnijaZupanija.getPostotakZarazenost();


            System.out.println("  �upanija '" + nazivZupanije + "' ima najve�i postotak zara�enosti koji iznosi: " + najveciPostotakZarazenosti + "%.");


           try {
               Thread.sleep(2000);
           } catch (InterruptedException e) {
               e.printStackTrace();
           }


        }
    }


}