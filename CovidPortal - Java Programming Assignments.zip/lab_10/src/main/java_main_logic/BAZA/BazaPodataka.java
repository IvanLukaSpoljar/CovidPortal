package main.java_main_logic.BAZA;

import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.model.*;

import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class BazaPodataka {

    private static final String DATABASE_CONFIGURATION_FILE = "src/main/resources/database.properties";
    private static boolean aktivnaVezaSBazomPodataka = false;



    //OTVARANJE BAZE PODATAKA
    private synchronized Connection spajanjeNaBazu() throws SQLException, IOException, InterruptedException {

       /* while (aktivnaVezaSBazomPodataka)
        {
            wait();
        }*/
        aktivnaVezaSBazomPodataka = true;




        Properties svojstva = new Properties();
        svojstva.load(new FileReader(DATABASE_CONFIGURATION_FILE));

        String urlBazePodataka = svojstva.getProperty("bazaPodatakaUrl");
        String korisnickoIme = svojstva.getProperty("korisnickoIme");
        String lozinka = svojstva.getProperty("lozinka");


        Connection veza = DriverManager.getConnection(urlBazePodataka, korisnickoIme, lozinka);


        return veza;
    }

    //ZATVARANJE BAZE PODATAKA
    private void zatvoriBazu(Connection veza) throws SQLException {

        veza.close();
        aktivnaVezaSBazomPodataka = false;

        //notifyAll();

    }


    //--------------------------------------------SIMPTOMI-------------------------------------------------
    //DOHVATI SVE SIMPTOME IZ BAZE
    public static List<Simptom> dohvatiSveSimptomeIzBaze() throws SQLException, IOException {
        List<Simptom> listaSimptomaIzBaze = new ArrayList<>();


        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM SIMPTOM");

        while (rs.next()) {
            long idSimptomaIzBaze = rs.getLong("ID");
            String nazivSimptomaIzBaze = rs.getString("NAZIV");
            String vrijednostSimptomaIzBaze = rs.getString("VRIJEDNOST");

            listaSimptomaIzBaze.add(new Simptom(idSimptomaIzBaze, nazivSimptomaIzBaze, vrijednostSimptomaIzBaze));
        }

        new BazaPodataka().zatvoriBazu(veza);

        return listaSimptomaIzBaze;
    }

    //DOHVATI SAMO JEDAN SIMPTOM IZ BAZE
    public static Simptom dohvatiJedanSimptomIzBaze(Long idSimptoma) throws SQLException, IOException {

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM SIMPTOM WHERE ID = " + idSimptoma);

        rs.next();
        long idSimptomaIzBaze = rs.getLong("ID");
        String nazivSimptomaIzBaze = rs.getString("NAZIV");
        String vrijednostSimptomaIzBaze = rs.getString("VRIJEDNOST");

        new BazaPodataka().zatvoriBazu(veza);

        return new Simptom(idSimptomaIzBaze, nazivSimptomaIzBaze, vrijednostSimptomaIzBaze);
    }

    //SPREMANJE JEDNOG NOVOG SIMPTOMA
    public static void spremiJedanSimptom(String nazivSimptoma, String ucestalostSimptoma) throws SQLException, IOException {
        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long IdNovogSimptoma = ListeZupanijaSimptomaBolestiVirusaOsoba.sviSimptomi.get(ListeZupanijaSimptomaBolestiVirusaOsoba.sviSimptomi.size() - 1).getId() + 1;

        PreparedStatement spremiSimptom = veza.prepareStatement("INSERT INTO SIMPTOM(ID, NAZIV, VRIJEDNOST) VALUES (?, ?, ?)");

        spremiSimptom.setLong(1, IdNovogSimptoma);
        spremiSimptom.setString(2, nazivSimptoma);
        spremiSimptom.setString(3, ucestalostSimptoma);
        spremiSimptom.executeUpdate();

        new BazaPodataka().zatvoriBazu(veza);


    }















    //------------------------------------------------------ZARAZE---------------------------------------------------

    public static List<Long> dohvatiListuIdSimptoma(Long idBolesti, List<Simptom> simptoiIzBaze) throws SQLException, IOException {
      //  List<Long> listaIdSimptoma = new ArrayList<>();

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<Long> listaIdSimptoma = new ArrayList<>();

        String query = "SELECT * FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + idBolesti;
        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()) {
            long idSimptoma = rs.getLong("SIMPTOM_ID");
            listaIdSimptoma.add(idSimptoma);
        }
        new BazaPodataka().zatvoriBazu(veza);

        /*

        for(int i = 0; i < simptoiIzBaze.size(); i++)
        {
            if(simptoiIzBaze.get(i).getId() == idBolesti)
            {
                listaIdSimptoma.add(simptoiIzBaze.get(i).getId());
            }
        }*/

        return listaIdSimptoma;

    }

    //DOHVATI SVE BOLESTI IZ BAZE
    public static List<Bolest> dohvatiSveZarazeIzBaze() throws SQLException, IOException {

        List<Simptom> simptomiIzBaze = dohvatiSveSimptomeIzBaze();

        List<Bolest> listaBolestiIzBaze = new ArrayList<>();

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM BOLEST");



        while (rs.next()) {
            long idBolestiIzBaze = rs.getLong("ID");
            String nazivBolestiIzBaze = rs.getString("NAZIV");
            Boolean istinosniTipZaraze = rs.getBoolean("VIRUS");

            List<Long> listaIdSimptoma = new ArrayList<>();
            listaIdSimptoma = dohvatiListuIdSimptoma(idBolestiIzBaze, simptomiIzBaze);
            List<Simptom> simptomiBolesti = new ArrayList<>();

            for (Long l : listaIdSimptoma) {
                Simptom noviSimptom = dohvatiJedanSimptomIzBaze(l);
                simptomiBolesti.add(noviSimptom);
            }

            if (istinosniTipZaraze == true) {
                Virus virus = new Virus(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBolesti);
                listaBolestiIzBaze.add(virus);
            } else {
                Bolest bolest = new Bolest(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBolesti);
                listaBolestiIzBaze.add(bolest);
            }
        }

        if (!veza.isClosed()) {
            new BazaPodataka().zatvoriBazu(veza);
        }

        return listaBolestiIzBaze;
    }
    //DOHVAT JEDNE BOLESTI
    private static Bolest dohvatJedneZaraze(long idZaraze) throws SQLException, IOException {
        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM BOLEST WHERE ID = " + idZaraze);

        rs.next();
        List<Simptom> simptomiBaze = new ArrayList<>();

        long idBolestiIzBaze = rs.getLong("ID");
        String nazivBolestiIzBaze = rs.getString("NAZIV");
        Boolean istinosniTipZaraze = rs.getBoolean("VIRUS");


        ResultSet rs1 = stmt.executeQuery("SELECT SIMPTOM_ID FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + idBolestiIzBaze);


        while (rs1.next()) {
            long indexSimptoma = rs1.getLong("SIMPTOM_ID");
            simptomiBaze.add(dohvatiJedanSimptomIzBaze(indexSimptoma));
        }

        new BazaPodataka().zatvoriBazu(veza);
        if (istinosniTipZaraze == true) {
            return new Virus(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBaze);
        } else {
            return new Bolest(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBaze);
        }
    }

    //SPREMANJE JEDNE ZARAZE
    public static void spremiJednuZarazu(String nazivBolesti, List<Simptom> listaSimptomaBolesti, Boolean istinitost) throws SQLException, IOException {


        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        long IdNoveZaraze = ListeZupanijaSimptomaBolestiVirusaOsoba.sveZaraze.get(ListeZupanijaSimptomaBolestiVirusaOsoba.sveZaraze.size() - 1).getId() + 1;


        PreparedStatement spremiBolest = veza.prepareStatement("INSERT INTO BOLEST(ID, NAZIV, VIRUS) VALUES (?, ?, ?)");

        //SPREMANJE U TBLICU BOLEST
        spremiBolest.setLong(1, IdNoveZaraze);
        spremiBolest.setString(2, nazivBolesti);
        spremiBolest.setBoolean(3, istinitost);
        spremiBolest.executeUpdate();


        PreparedStatement spremiInfo = veza.prepareStatement("INSERT INTO BOLEST_SIMPTOM(BOLEST_ID, SIMPTOM_ID) VALUES (?, ?)");
        //SPREMANJE U TABLICU BOLEST_SIMPTOM
        for (Simptom x : listaSimptomaBolesti) {
            long trenutniIndexSimptoma = x.getId();

            spremiInfo.setLong(1, IdNoveZaraze);
            spremiInfo.setLong(2, trenutniIndexSimptoma);
            spremiInfo.executeUpdate();
        }


        new BazaPodataka().zatvoriBazu(veza);

    }










    //----------------------------------------�UPANIJE -----------------------------------------------
    //DOHVATI SVE BOLESTI IZ BAZE
    public static List<Zupanija> dohvatiSveZupanije() throws SQLException, IOException {
        List<Zupanija> listaZupanijeIzBaze = new ArrayList<>();

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM ZUPANIJA");


        while (rs.next()) {
            long idZupanijeIzBaze = rs.getLong("ID");
            String nazivZupanijeIzBaze = rs.getString("NAZIV");
            Integer brojStanovnikaizBaze = rs.getInt("BROJ_STANOVNIKA");
            Integer brojZarazenihizBaze = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");

            listaZupanijeIzBaze.add(new Zupanija(idZupanijeIzBaze, nazivZupanijeIzBaze, brojStanovnikaizBaze, brojZarazenihizBaze));
        }


        new BazaPodataka().zatvoriBazu(veza);
        return listaZupanijeIzBaze;
    }

    //DOHVAT JEDNE �UPANIJE
    public static Zupanija dohvatiJednuZupaniju(Long idZupanije) throws SQLException, IOException {

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM ZUPANIJA WHERE ID = " + idZupanije);
        rs.next();
        long idZupanijeIzBaze = rs.getLong("ID");
        String nazivZupanijeIzBaze = rs.getString("NAZIV");
        Integer brojStanovnikaizBaze = rs.getInt("BROJ_STANOVNIKA");
        Integer brojZarazenihizBaze = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");

        new BazaPodataka().zatvoriBazu(veza);

        return new Zupanija(idZupanijeIzBaze, nazivZupanijeIzBaze, brojStanovnikaizBaze, brojZarazenihizBaze);
    }

    //SPREMANJE JEDNE �UPANIJE
    public static void spremiJednuZupaniju(String nazivZupanije, Integer brojStanovnikaZupanije, Integer brojZarazenihUZupaniji) throws SQLException, IOException {
        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long IdNoveZupanije = ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije.get(ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije.size() - 1).getId() + 1;


        PreparedStatement spremiZupaniju = veza.prepareStatement("INSERT INTO ZUPANIJA(ID, NAZIV, BROJ_STANOVNIKA, BROJ_ZARAZENIH_STANOVNIKA) VALUES (?, ?, ?, ?)");

        spremiZupaniju.setLong(1, IdNoveZupanije);
        spremiZupaniju.setString(2, nazivZupanije);
        spremiZupaniju.setInt(3, brojStanovnikaZupanije);
        spremiZupaniju.setInt(4, brojZarazenihUZupaniji);
        spremiZupaniju.executeUpdate();

        new BazaPodataka().zatvoriBazu(veza);


    }










    //---------------------------------------------------OSOBE------------------------------------------------------




    //DOHVATI SVIH OSOBA IZ BAZE
    public static List<Osoba> dohvatiSveOsobe() throws SQLException, IOException {
        List<Osoba> listaOsobaIzBaze = new ArrayList<>();


        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM OSOBA");



        while (rs.next()) {


            List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();

            long idOsobeIzBaze = rs.getLong("ID");
            String imeOsobe = rs.getString("IME");
            String prezime = rs.getString("PREZIME");
            Date datum = (Date) rs.getDate("DATUM_RODJENJA");


            long zupanijaId = rs.getLong("ZUPANIJA_ID");
            long bolestiId = rs.getLong("BOLEST_ID");

            //�UPANJIJA
            Zupanija jednaKonacnaZupanija = dohvatiJednuZupaniju(zupanijaId);

            //BOLESTI
            Bolest jednaKonacnaZaraza = dohvatJedneZaraze(bolestiId);

            List<Long> indexiKontaktiranihOsoba = new ArrayList<>();


            //KONTAKTIRANE OSOBE
            List<Long> listaIdKontOsoba = new ArrayList<>();
            listaIdKontOsoba = dohvatiKontaktiraneOsobeId(idOsobeIzBaze);

            for (Long l : listaIdKontOsoba) {
                Osoba novaKonOsoba = dohvatiJednuOsobu(l);
                listaKontaktiranihOsoba.add(novaKonOsoba);


            }


            Osoba tmp = new Osoba.Builder(idOsobeIzBaze)
                    .name(imeOsobe)
                    .surname(prezime)
                    .age(datum)
                    .county(jednaKonacnaZupanija) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                    .personInfection(jednaKonacnaZaraza) //UNOS BOLESTI OSOBE
                    .contactedPersons(listaKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                    .makeItDone();


            listaOsobaIzBaze.add(tmp);


        }


        new BazaPodataka().zatvoriBazu(veza);
        return listaOsobaIzBaze;
    }

    public static List<Long> dohvatiKontaktiraneOsobeId(Long idOsobeIzBaze) throws SQLException, IOException {
        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<Long> listaIdKontaktiranih = new ArrayList<>();

        Statement stmt2 = veza.createStatement();
        ResultSet rs = stmt2.executeQuery("SELECT KONTAKTIRANA_OSOBA_ID  FROM KONTAKTIRANE_OSOBE WHERE OSOBA_ID = " + idOsobeIzBaze);

        while (rs.next()) {
            long idKontaktOsobe = rs.getLong("KONTAKTIRANA_OSOBA_ID");
            listaIdKontaktiranih.add(idKontaktOsobe);


        }
        new BazaPodataka().zatvoriBazu(veza);
        return listaIdKontaktiranih;
    }


    //DOHVATI JEDNU OSOBU
    private static Osoba dohvatiJednuOsobu(Long idOsobe) throws SQLException, IOException {

        List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();
        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM OSOBA WHERE ID = " + idOsobe);
        rs.next();

        long idOsobeIzBaze = rs.getLong("ID");
        String imeOsobe = rs.getString("IME");
        String prezime = rs.getString("PREZIME");
        Date datum = (Date) rs.getDate("DATUM_RODJENJA");


        long zupanijaId = rs.getLong("ZUPANIJA_ID");
        long bolestiId = rs.getLong("BOLEST_ID");

        //�UPANJIJA
        Zupanija jednaKonacnaZupanija = dohvatiJednuZupaniju(zupanijaId);

        //BOLESTI
        Bolest jednaKonacnaZaraza = dohvatJedneZaraze(bolestiId);

        List<Long> indexiKontaktiranihOsoba = new ArrayList<>();


        //KONTAKTIRANE OSOBE
        List<Long> listaIdKontOsoba = new ArrayList<>();
        listaIdKontOsoba = dohvatiKontaktiraneOsobeId(idOsobeIzBaze);


        Osoba pom = (
                new Osoba.Builder(idOsobeIzBaze)
                        .name(imeOsobe)
                        .surname(prezime)
                        .age(datum)
                        .county(jednaKonacnaZupanija) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                        .personInfection(jednaKonacnaZaraza) //UNOS BOLESTI OSOBE
                        .contactedPersons(listaKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                        .makeItDone()
        );

        return pom;
    }


    //SPREMI NOVU OSOBU U BAZU
    public static void spremiJednuOosbu(String imeOsobe, String prezimeOsobe, Date datum, Zupanija privremenaZupanija, Bolest privremenaBolest, List<Osoba> odabraneOsobe) throws SQLException, IOException {

        Connection veza = null;
        try {
            veza = new BazaPodataka().spajanjeNaBazu();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }



        long IdNoveOsobe = ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.get(ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.size() - 1).getId() + 1;

        PreparedStatement spremiOsobu = veza.prepareStatement("INSERT INTO OSOBA(ID, IME, PREZIME, DATUM_RODJENJA, ZUPANIJA_ID, BOLEST_ID) VALUES (?, ?, ?, ?, ?, ?)");
        //SPREMANJE OSOBE U TABLICU
        spremiOsobu.setLong(1, IdNoveOsobe);
        spremiOsobu.setString(2, imeOsobe);
        spremiOsobu.setString(3, prezimeOsobe);
        spremiOsobu.setDate(4, datum);
        spremiOsobu.setLong(5, privremenaZupanija.getId());
        spremiOsobu.setLong(6, privremenaBolest.getId());
        spremiOsobu.executeUpdate();


        //SPREMANJE U KONTAKTIRANE OSOBE TABLICU
        PreparedStatement spremiKontaktiranuOsobu = veza.prepareStatement("INSERT INTO KONTAKTIRANE_OSOBE(OSOBA_ID,  KONTAKTIRANA_OSOBA_ID) VALUES (?, ?)");
        //SPREMANJE U TABLICU BOLEST_SIMPTOM
        for (Osoba x : odabraneOsobe) {
            long trenutniIndexKontOsobe = x.getId();

            spremiKontaktiranuOsobu.setLong(1, IdNoveOsobe);
            spremiKontaktiranuOsobu.setLong(2, trenutniIndexKontOsobe);
            spremiKontaktiranuOsobu.executeUpdate();
        }


        new BazaPodataka().zatvoriBazu(veza);
        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();
    }


}
