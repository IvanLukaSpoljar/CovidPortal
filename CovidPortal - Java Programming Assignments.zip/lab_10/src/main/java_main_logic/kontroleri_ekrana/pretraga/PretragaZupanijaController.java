package main.java_main_logic.kontroleri_ekrana.pretraga;

import com.sun.glass.ui.Application;
import hr.java.covidportal.niti.NajviseZarazenihNit;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.model.Zupanija;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import javafx.scene.control.cell.PropertyValueFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class PretragaZupanijaController implements Initializable, PovijestKretanjaPoEkranima {

    List<Zupanija> listaSvihZupanijeIzControllera = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaZupanija.fxml";

    public static final Logger logger = LoggerFactory.getLogger(PretragaZupanijaController.class);


    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje = new TextField();


    @FXML
    private TableView<Zupanija> tablicaZupanija;

    @FXML
    private TableColumn<Zupanija, String> stupacNaziva;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaStanovnika;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaZarazenih;




    @FXML
    public void odiNatrag() throws IOException {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o �upanijama");
    }
    @FXML
    public void odiNaprijed() throws IOException {
      slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }
    @FXML
    public void pretrazi() throws IOException {

        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaZupanija.setItems(FXCollections.observableList(
                    listaSvihZupanijeIzControllera.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();

        logger.info("Korisnik je otvorio ekran o �upanijama");
        Main.getMainStage().setTitle("�upanije");



        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Zupanija, String>("naziv"));
        stupacBrojaStanovnika.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojStanovnika"));
        stupacBrojaZarazenih.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojZarazenih"));





        try {
            ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZupanijaIzBaze(BazaPodataka.dohvatiSveZupanije());
            for(Zupanija x : ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije)
            {
                listaSvihZupanijeIzControllera.add(x);
            }
        } catch (SQLException | IOException throwables) {
            throwables.printStackTrace();
        }



        if (NajviseZarazenihNit.nitPostoji == false)
        {


            //PROMJENA �UPANIJA
            NajviseZarazenihNit najZarazenihNit = new NajviseZarazenihNit(listaSvihZupanijeIzControllera);

            ExecutorService executorService = Executors.newCachedThreadPool();
            executorService.execute(najZarazenihNit);



            NajviseZarazenihNit.nitPostoji = true;
        }


        /*
            try {
                executorService.awaitTermination(5, TimeUnit.SECONDS);
                najZarazenihNit.setPokreni(false);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }*/




        //NASLOV
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e ->
        {
            /*Zupanija najifektivnijaZupanija = null;
            try {
                najifektivnijaZupanija = BazaPodataka.dohvatiSveZupanije().stream()
                        .max(Comparator.comparingDouble(z1 -> z1.getPostotakZarazenost()))
                        .get();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException exception) {
                exception.printStackTrace();
            }*/


            if (NajviseZarazenihNit.najifektivnijaZupanija != null)
            {
                String nazivZupanije = NajviseZarazenihNit.najifektivnijaZupanija.getNaziv();
                Double najveciPostotakZarazenosti = NajviseZarazenihNit.najifektivnijaZupanija.getPostotakZarazenost();

                Main.getMainStage().setTitle("Najzara�enija �upanija je: " + nazivZupanije);
            }
        }
        ), new KeyFrame(Duration.seconds(3)));
        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();



        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);


        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();

    }


}
