package main.java_main_logic.kontroleri_ekrana.pretraga;

        import javafx.scene.control.Button;
        import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
        import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
        import main.java_main_logic.model.Simptom;
        import javafx.collections.FXCollections;
        import javafx.fxml.FXML;
        import javafx.fxml.Initializable;
        import javafx.scene.control.TableColumn;
        import javafx.scene.control.TableView;
        import javafx.scene.control.TextField;
        import javafx.scene.control.cell.PropertyValueFactory;
        import main.java_main_logic.GLAVNO.Main;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;


        import java.io.IOException;
        import java.net.URL;
        import java.util.ArrayList;
        import java.util.List;
        import java.util.ResourceBundle;
        import java.util.stream.Collectors;

public class PretragaSimptomaController implements Initializable, PovijestKretanjaPoEkranima {

    List<Simptom> listaSvihSimptoma = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaSimptoma.fxml";

    public static final Logger logger = LoggerFactory.getLogger(PretragaSimptomaController.class);

    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Simptom> tablicaSimptoma;
    @FXML
    private TableColumn<Simptom, String> stupacNaziva;
    @FXML
    private TableColumn<Simptom, String> stupacVrijednosti;




    @FXML
    public void odiNatrag() throws IOException
    {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o Simptomima");
    }
    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }
    @FXML
    public void pretrazi() throws IOException
    {
        tablicaSimptoma.setItems(FXCollections.observableList(listaSvihSimptoma));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaSimptoma.setItems(FXCollections.observableList(
                    listaSvihSimptoma.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Main.getMainStage().setTitle("Simptomi");
        logger.info("Korisnik je otvorio ekran o Simptomima");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Simptom, String>("naziv"));
        stupacVrijednosti.setCellValueFactory(new PropertyValueFactory<Simptom, String>("vrijednost"));

        listaSvihSimptoma = ListeZupanijaSimptomaBolestiVirusaOsoba.sviSimptomi;
        tablicaSimptoma.setItems(FXCollections.observableList(listaSvihSimptoma));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
