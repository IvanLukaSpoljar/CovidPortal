package main.java_main_logic.GLAVNO.sporedno;

import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.genericsi.KlinikaZaInfektivneBolesti;
import main.java_main_logic.model.*;


import main.java_main_logic.extra_help.PomocneVarijableZaraza;
import main.java_main_logic.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.nio.file.Files;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Slu�i za testiranje logginga tijekom izvo�enja programa.
 */
public class Glavna implements ListeZupanijaSimptomaBolestiVirusaOsoba {

    public static final Logger logger = LoggerFactory.getLogger(Glavna.class);

    /**
     * Slu�i za pokretanje programa koji �e od korisnika tra�iti da svojim unosom definira vrijednosti pojedinih
     * varijabli, te nakon toga da unese zara�ene osobe kod kojih �e se vidjeti jesu li u me�uvremenu zara�eni
     * nekom drugom bole��u i s kime su sve kontaktirali.
     *
     * @param args argumenti komandne linije
     */
    public static void main(String[] args) throws IOException {
        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        List<Zupanija> zupanije = new ArrayList<>();
        List<Simptom> simptomi = new ArrayList<>();
        List<Bolest> zaraze = new ArrayList<>();
        List<Osoba> osobe = new ArrayList<>();

        //MAPA
        Map<Bolest, List<Osoba>> mapaZarazenihPoBolesti = new HashMap<>();


        //POMO�NE VARIJABLE
        PomocneVarijableZaraza dohvatVarijabli = new PomocneVarijableZaraza();
        Boolean flagIznimka = true;




        //<-------------�UPANIJE---------------->
        zupanije = ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihZupanijaIzDatoteke("dat/zupanije.txt");
        //SERIJALIZACIJA -> STAVLJANJE PODATAKA U BINARNU DATOTEKU
        try (ObjectOutputStream serijalizator = new ObjectOutputStream(new FileOutputStream("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat"))) {

            List<String> listaRecenica = zupanije.stream()
                    .filter(z -> z.getPostotakZarazenost() > 2)
                    .map(recenica -> new String(recenica.getNaziv() + " �upanija ima " + recenica.getPostotakZarazenost() + "% zara�enih."))
                    .collect(Collectors.toList());

                serijalizator.writeObject(listaRecenica);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        //KOPIRANJE BINARNE DATOTEKE U DRUGU BINARNU DATOTEKU (moja vje�ba)
        /*File infile = new File("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat");
        File outfile = new File("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti_KOPIJA.dat");

        try(FileInputStream fin = new FileInputStream(infile); FileOutputStream fout = new FileOutputStream(outfile))
        {
            byte[] buffer = new byte[1024];
            int bytesRead = fin.read(buffer);

            while(bytesRead != -1)
            {
                fout.write(buffer, 0 ,bytesRead);
                bytesRead = fin.read(buffer);
            }

        }catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }*/
        //KOPIRANJE BINARNE DATOTEKE U DRUGU BINARNU DATOTEKU (moja vje�ba)
        //copyFile(infile, new File("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti_KOPIJA_2.dat"));

        /*//KOLIKO LINIJA IMA BINARNA DATOTEKA(moja vje�ba)
        Integer brojLinijaBinarneDatoteke = 0;
        try {
            InputStream in = new FileInputStream("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat");

            int broj = in.read();

            while (broj != -1)
            {
                if((char) broj == '.')
                {
                    brojLinijaBinarneDatoteke++;
                }
                broj = in.read();
            }
            in.close();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        brojLinijaBinarneDatoteke /= 2;*/
        //DOHVA�ANJE PODATAKA IZ BINARNE DATOTEKE (moja vje�ba)
        List<String> procitani = null;
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("src/moji_outputi/binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat"));

            procitani = (List<String>) in.readObject();
            in.close();
        } catch (IOException ex) {
            System.err.println(ex);

        } catch (ClassNotFoundException ex) {
            System.err.println(ex);
        }
        //STAVLJANJE DOHVA�ENIH PODATAKA U NOVI TEKSTUALNI FILE (moja vje�ba)
        try(PrintWriter out = new PrintWriter(new FileWriter(new File("src/moji_outputi/tekstualni_outputi/tekstualni_rezultati.txt"))))
        {
            for(int i = 0; i < procitani.size(); i++)
            {
                String noviTmp = procitani.get(i).replace(", ", "");
                out.println(noviTmp);
            }
        }catch(IOException ex)
        {
            ex.printStackTrace();
        }




        //<-------------SIMPTOMI---------------->
        simptomi = ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihSimptomaIzDatoteke( "dat/simptomi.txt");




        //<-------------ZARAZE---------------->

        ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihBolestiIzDatoteke("dat/bolesti.txt");
        ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihVirusaIzDatoteke("dat/virusi.txt");
        zaraze = ListeZupanijaSimptomaBolestiVirusaOsoba.spojBolestiSaVirusima();



        for (Bolest element : zaraze)
            if (element instanceof Virus)
                dohvatVarijabli.getPomocni_Niz_Svih_Virusa().add((Virus) element);




        //<-------------OSOBE---------------->
        osobe = ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihOsobaIzDatoteke("dat/osobe.txt");


        KlinikaZaInfektivneBolesti podatciKlinikeInfektivnihBolesti = new KlinikaZaInfektivneBolesti(osobe, dohvatVarijabli.getPomocni_Niz_Svih_Virusa());





        //ISPIS
        System.out.println("\n**************************************************** POPIS OSOBA ****************************************************\n");
        for (int indexOsobe = 0; indexOsobe < osobe.size(); indexOsobe++)
            ispisOsoba(osobe, indexOsobe);

        //ISPIS
        System.out.println("\n*********************************** ISPIS SVIH ZARA�ENIH OSOBA ODRE�ENOM BOLESTI ************************************\n");
        dodaj_Zarazene_Po_Bolesti_U_Mapu(zaraze, osobe, mapaZarazenihPoBolesti);
        ispis_Mape_Zarazenih_Po_Bolesti(mapaZarazenihPoBolesti);

        //ISPIS
        System.out.println("\n*********************************** �UPANIJA SA NAJVE�IM POSTOTKOM ZARA�ENOSTI **************************************\n");
        List<Zupanija> pomocnaListaZupanija = new ArrayList<Zupanija>(zupanije);
        Collections.sort(pomocnaListaZupanija, new CovidSorter<Zupanija>());
        System.out.println("  Najvi�e zara�enih osoba ima u �upaniji " + pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getNaziv() + ": " + (int) pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getPostotakZarazenost() + "%.");

        //ISPIS
        System.out.println("\n******************************** IMENA VIRUSA SORTIRANIH SILAZNIM ABECEDNIM REDOM ***********************************\n");
        /*List<Virus> paralelnistream = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startparallelLambda = Instant.now();
        paralelnistream = paralelnistream.parallelStream()
                .sorted((v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv()))
                .collect(Collectors.toList());
        Instant endParallelLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom preko ParallelStream-a po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < paralelnistream.size(); i++)
            System.out.println("  " + (i + 1) + ". " + paralelnistream.get(i).getNaziv());

        System.out.println();
        System.out.println();*/

        List<Virus> sortiranjeVirusaLambdom = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startLambda = Instant.now();
        sortiranjeVirusaLambdom = sortiranjeVirusaLambdom.stream()
                .sorted(new CovidSorter<Virus>()) /*(v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv())*/
                .collect(Collectors.toList());
        Instant endLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusaLambdom.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusaLambdom.get(i).getNaziv());

        // System.out.println();
        //  System.out.println();

        List<Virus> sortiranjeVirusa = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant start = Instant.now();
        //mojaMetodaSortiranjaVirusa(sortiranjeVirusa);
        //Collections.sort(sortiranjeVirusa, new CovidSorter<Virus>());
        sortiranjeVirusa.sort(new CovidSorter<Virus>());
        Instant end = Instant.now();
        /*System.out.println("  Virusi sortirani pomo�u moje funkcije za sortiranje po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusa.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusa.get(i).getNaziv());*/


        //System.out.printf("\n\n  Sotiranje objekata paralenim streamom traje: %d milisekundi.", Duration.between(startparallelLambda, endParallelLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata kori�tenjem lambdi traje: %d milisekundi.", Duration.between(startLambda, endLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata bez kori�tenja lambde traje: %d milisekundi.\n", Duration.between(start, end).toMillis());


        //ISPIS
        /*Boolean ponovi;
        System.out.println("\n******************************************* PRETRAGA PO DIJELU STRINGA **********************************************\n");
        do {
            System.out.print("  Unesite string za pretragu po prezimenu: ");
            vrijednostPretrazivanja = unos.nextLine();

            String regex = "^[- 0-9A-Za-z]*$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(vrijednostPretrazivanja);

            if (matcher.matches() == true)
            {
                ponovi = false;
            } else {
                ponovi = true;
                System.out.println();
                System.out.println("  Krivo unesena vrijednost, probajte opet.");
            }
        }while(ponovi);*/

        /*
        //U GRAFI�KOM DIJELU SE PRETRA�UJE PA NEMA POTREBE OVDJE TRA�ITI PRETRA�IVANJE
        System.out.println("\n******************************************* PRETRAGA PO DIJELU STRINGA **********************************************\n");
        System.out.print("  Unesite string za pretragu po prezimenu: ");
        String vrijednostPretrazivanja = unos.nextLine();
        Optional<List<Osoba>> rezultatiPretrazivanjaPoPrezimenu = Optional.ofNullable(
                osobe.stream()
                        .filter(osoba -> osoba.getPrezime().toLowerCase().contains(vrijednostPretrazivanja.toLowerCase()))
                        .sorted((osoba1, osoba2) -> osoba1.getPrezime().compareTo(osoba2.getPrezime()))
                        .collect(Collectors.toList())
        );
        if (vrijednostPretrazivanja.isEmpty()) {
            System.out.println("\n  Nema pretrage.");
        } else {
            if (rezultatiPretrazivanjaPoPrezimenu.get().isEmpty()) {
                System.out.println("\n  Nema takve osobe koja u prezimenu sadr�i une�ena slova.");
            } else {
                System.out.println("\n  Osobe �ije prezime sadr�i �" + vrijednostPretrazivanja + "� su sljede�e:  ");
                for (int i = 0; i < rezultatiPretrazivanjaPoPrezimenu.get().size(); i++) {
                    System.out.println("  " + (i + 1) + ". " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getIme() + " " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getPrezime());
                }
            }
        }
        */


        //ISPIS
        System.out.println("\n*********************************** ISPIS BROJA SIMPTOMA ZA SVAKU VRSTU ZARAZE **************************************\n");
        List<String> ispisBrojaSimptomaZaBolest = zaraze.stream()
                .map(recenica -> new String(recenica.getNaziv() + " ima " + recenica.getSimptomi().size() + " simptoma."))
                .collect(Collectors.toList());
        for (int i = 0; i < ispisBrojaSimptomaZaBolest.size(); i++)
            System.out.println("  " + (i + 1) + ". " + ispisBrojaSimptomaZaBolest.get(i));

        //KRAJ CIJELE MAIN FUNKCIJE
    }


    //FUNKCIJA ZA KOPIRANJE DATOTEKA
    public static void copyFile(File from, File to) throws IOException {
        Files.copy(from.toPath(), to.toPath());
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA

    /**
     * Ispisuje podatke o osobama.
     *
     * @param osobe niz osoba
     * @param i     index osobe u nizu
     */
    private static void ispisOsoba(List<Osoba> osobe, Integer i) {

        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe.get(i).getIme() + " " + osobe.get(i).getPrezime());
        System.out.println("    Starost: " + osobe.get(i).getStarost());
        System.out.println("    �upanija prebivali�ta: " + osobe.get(i).getZupanija().getNaziv());
        System.out.println("    Zara�en bole��u: " + osobe.get(i).getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");

        //osobe[i] JE TRENUTNA OSOBA KOJA MO�E SADR�AVATI NIZ ZAR�ENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe.get(i).getKontaktiraneOsobe() == null) //AKO JE NIZ ZARA�ENIH OSOBA PRAZAN
        {
            System.out.print("Nema kontaktiranih osoba.");
        } else //AKO NIZ ZARA�ENIH OSOBA NIJE PRAZAN
        {
            for (int j = 0; j < osobe.get(i).getKontaktiraneOsobe().size(); j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe.get(i).getKontaktiraneOsobe().get(j).getIme() + " " + osobe.get(i).getKontaktiraneOsobe().get(j).getPrezime());
            }
        }

        System.out.println("\n");
    }


    public static <T extends ImenovaniEntitet> Boolean provjeri_Ista_Imena(Set<T> fiskniNiz, String primjerak) {
        Boolean ponovi = false;

        whilePetlja:
        {
            Iterator<T> iter1 = fiskniNiz.iterator();
            while (iter1.hasNext()) {
                String naziv = iter1.next().getNaziv();
                if (primjerak.compareToIgnoreCase(naziv) == 0) {
                    System.out.println("    Unesite drugi naziv, isti naziv ve� postoji\n");
                    ponovi = true;
                    break whilePetlja;
                }
            }
        }

        return ponovi;
    }


    public static void dodaj_Zarazene_Po_Bolesti_U_Mapu(List<Bolest> bolesti, List<Osoba> osobe, Map<Bolest, List<Osoba>> mapa) {
        for (Bolest pomocna : bolesti) {
            List<Osoba> pomocniNizOsoba = new ArrayList<>();
            for (int i = 0; i < osobe.size(); i++)
                if (pomocna.getNaziv().equals(osobe.get(i).getZarazenBolescu().getNaziv()) == true)
                    pomocniNizOsoba.add(osobe.get(i));

            if (pomocniNizOsoba.size() >= 1)
                mapa.put(pomocna, pomocniNizOsoba);
        }
    }


    public static void ispis_Mape_Zarazenih_Po_Bolesti(Map<Bolest, List<Osoba>> mapa) {
        for (Bolest key : mapa.keySet()) {
            if (key instanceof Virus)
                System.out.print("  Od virusa " + key.getNaziv() + " boluju: ");
            else
                System.out.print("  Od bolesti " + key.getNaziv() + " boluju: ");

            for (int i = 0; i < mapa.get(key).size(); i++) {
                if (i > 0)
                    System.out.print(", ");
                System.out.print(mapa.get(key).get(i).getIme() + " " + mapa.get(key).get(i).getPrezime());
            }
            System.out.println();
        }
    }


    public static void mojaMetodaSortiranjaVirusa(List<Virus> sortiranjeVirusa) {
        for (int i = 0; i < sortiranjeVirusa.size(); i++) {
            String naziv1 = sortiranjeVirusa.get(i).getNaziv();
            for (int j = 0; j < sortiranjeVirusa.size(); j++) {
                String naziv2 = sortiranjeVirusa.get(j).getNaziv();

                if (naziv2.compareToIgnoreCase(naziv1) <= -1) {
                    Virus tmp = sortiranjeVirusa.get(i);

                    sortiranjeVirusa.set(i, sortiranjeVirusa.get(j));
                    sortiranjeVirusa.set(j, tmp);
                }
            }
        }
    }


    //KRAJ CIJELE KLASE: GLAVNA
}
