package hr.java.covidportal.iznimke;

/**
 *klasa za iznimku kod nesipravnog imena
 */
public class NeispravanoImeException extends RuntimeException{
    public NeispravanoImeException(String message)
    {
        super(message);
    }

    public NeispravanoImeException(Throwable cause)
    {
        super(cause);
    }

    public NeispravanoImeException(String message, Throwable cause)
    {
        super(message, cause);
    }

}
