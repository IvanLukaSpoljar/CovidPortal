package hr.java.covidportal.model;

/**
 *Služi za kreiranje objekta bolest u klasi Glavna.
 */
public class Virus extends Bolest implements Zarazno {
    //KONSTRUKTOR
    public Virus(String naziv, Simptom[] simptomi) {
        super(naziv, simptomi);
    }


    /**
     * Prenosi virus
     * @param osoba objekt klase Osoba
     */
    @Override
    public void prelazakZarazeNaOsobu(Osoba osoba) {
        osoba.setZarazenBolescu(this);
    }
}
