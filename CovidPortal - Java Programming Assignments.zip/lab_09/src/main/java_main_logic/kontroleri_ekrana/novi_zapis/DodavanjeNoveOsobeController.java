package main.java_main_logic.kontroleri_ekrana.novi_zapis;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.GLAVNO.Main;

import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.iznimke.Upozorenje;
import main.java_main_logic.model.Bolest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DodavanjeNoveOsobeController implements Initializable, ListeZupanijaSimptomaBolestiVirusaOsoba, PovijestKretanjaPoEkranima {

    public static final Logger logger = LoggerFactory.getLogger(DodavanjeNoveOsobeController.class);
    public static String putanjaDoTrenutnogFXMLa = "layout/novi_zapis/dodavanjeNoveOsobe.fxml";


    @FXML
    private Button naprijedGumb = new Button();


    @FXML
    private TextField imeOsobe = new TextField();
    @FXML
    private TextField prezimeOsobe = new TextField();
    @FXML
    private TextField brojGodina = new TextField();
    @FXML
    private TextField brojZupanije = new TextField();
    @FXML
    private TextField brojBolesti = new TextField();
    @FXML
    private TextField brojKontaktiranih = new TextField();
    @FXML
    private TextField odabirOsoba = new TextField();


    private void provjeriPopunjenostOsnovnihPolja(TextField imeOsobe, TextField prezimeOsobe, TextField brojGodina, TextField brojZupanije, TextField brojBolesti) {
        if (imeOsobe.getText().isEmpty() == true || prezimeOsobe.getText().isEmpty() == true || brojGodina.getText().isEmpty() == true || brojZupanije.getText().isEmpty() == true || brojBolesti.getText().isEmpty() == true)
            throw new Upozorenje("X");
    }

    private void provjeriPopunjenostExtraPolja(TextField brojKontaktiranih, TextField odabirOsoba) {
        if (brojKontaktiranih.getText().isEmpty() == true || odabirOsoba.getText().isEmpty() == true)
            throw new Upozorenje("Popunite polja");
    }

    @FXML
    public void spremiNovuOsobu() throws IOException {
        Long id = (long) 1;
        if (sveOsobe.size() > 0)
            id = sveOsobe.get(sveOsobe.size() - 1).getId() + 1;


        try {
            provjeriPopunjenostOsnovnihPolja(imeOsobe, prezimeOsobe, brojGodina, brojZupanije, brojBolesti);
            if(sveOsobe.size() > 1)
                provjeriPopunjenostExtraPolja(brojKontaktiranih, odabirOsoba);

            provjeraValjanostiParametaraZaOsobu();

          //  AppendPodatakaOsoba(id, imeOsobe.getText(), prezimeOsobe.getText(), brojGodina.getText(), brojZupanije.getText(), brojBolesti.getText(), brojKontaktiranih.getText(), odabirOsoba.getText());



            isprazniSvaPolja(imeOsobe, prezimeOsobe, brojGodina, brojZupanije, brojBolesti, brojKontaktiranih, odabirOsoba);

        } catch (Upozorenje ex) {

            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setTitle("Nepopunjena polja ili krivo une�eni podatci");
            upozorenje.setContentText(ex.getMessage());
            upozorenje.showAndWait();

            isprazniSvaPolja(imeOsobe, prezimeOsobe, brojGodina, brojZupanije, brojBolesti, brojKontaktiranih, odabirOsoba);
        }
    }



    private void provjeraValjanostiParametaraZaOsobu() {
        //BROJ GODINA
        String regex = "^[0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(brojGodina.getText());
        if (brojGodina.getText().isEmpty() == true || matcher.matches() == false)
           throw new Upozorenje("Unesite numeri�ki podatak za broj godina");

        //BROJ �UPANIJE
        matcher = pattern.matcher(brojZupanije.getText());
        if (brojZupanije.getText().isEmpty() == true || matcher.matches() == false)
            throw new Upozorenje("Unesite numeri�ki podatak za broj �upanije");
        else
            {
                Integer brojZup = Integer.parseInt(brojZupanije.getText());
                if(brojZup < 1 || brojZup > sveZupanije.size())
                    throw new Upozorenje("Broj �upanije mora bit u intervalu od " + 1 + " do " + sveZupanije.size());
            }

        //BROJ BOLESTI
        matcher = pattern.matcher(brojBolesti.getText());
        if (brojZupanije.getText().isEmpty() == true || matcher.matches() == false)
            throw new Upozorenje("Unesite numeri�ki podatak za broj �upanije");
        else
        {
            Integer brojZar = Integer.parseInt(brojBolesti.getText());
            if(brojZar < 1 || brojZar > sveZaraze.size())
                throw new Upozorenje("Broj zaraze mora bit u intervalu od " + 1 + " do " + sveZaraze.size());
        }


        if(sveOsobe.size() > 1)
        {
            //BROJ KONTAKTIRANIH OSOBA
            Integer brojKont = 0;
            matcher = pattern.matcher(brojKontaktiranih.getText());
            if (brojKontaktiranih.getText().isEmpty() == true || matcher.matches() == false)
                throw new Upozorenje("Unesite numeri�ki podatak za broj �upanije");
            else
            {
                brojKont = Integer.parseInt(brojKontaktiranih.getText());
                if(brojKont < 0 || brojKont > sveZaraze.size() -1)
                    throw new Upozorenje("Broj kontaktiranih osoba mora bit u intervalu od " + 1 + " do " + (sveOsobe.size() -1));
            }

            //BROJEVI ODABIRA OSOBA
            if(brojKont == 0)
                odabirOsoba.setText("0");
            else
            {
                Boolean nedozvoljenaVrijednost = false;
                String regex2 = "^[0-9,]*$";
                Pattern pattern2 = Pattern.compile(regex);
                Matcher matcher2 = pattern.matcher(odabirOsoba.getText());

                if (matcher.matches() == false)
                    nedozvoljenaVrijednost = true;
                else {
                    String[] stringoviBrojeva = odabirOsoba.getText().split(",");
                    for (int i = 0; i < stringoviBrojeva.length; i++)
                        if(stringoviBrojeva[i].isEmpty() == true || (long) Integer.parseInt(stringoviBrojeva[i]) < 1 || (long) Integer.parseInt(stringoviBrojeva[i]) > sveOsobe.get(sveOsobe.size() - 2).getId())
                            nedozvoljenaVrijednost = true;
                }
                if(nedozvoljenaVrijednost == true)
                    throw new Upozorenje("Broj odabranih osoba mora biti u intervalu od " + 1 + " do " + (sveOsobe.size() - 2));
            }

        }
    }



    private void isprazniSvaPolja(TextField imeOsobe, TextField prezimeOsobe, TextField brojGodina, TextField brojZupanije, TextField brojBolesti, TextField brojKontaktiranih, TextField odabirOsoba) {
        imeOsobe.setText("");
        prezimeOsobe.setText("");
        brojGodina.setText("");
        brojZupanije.setText("");
        brojBolesti.setText("");
        brojKontaktiranih.setText("");
        odabirOsoba.setText("");
    }



    @FXML
    public void odiNatrag() throws IOException {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran dodavanja virusa");
    }

    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Dodavanje nove osobe");
        logger.info("Korisnik je otvorio ekran dodavanja nove osobe");

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
