package main.java_main_logic.iznimke;
/**
 *Služi za kreiranje označene iznimke u klasi Glavna.
 */
public class DuplikatKontaktiraneOsobe extends Exception
{

    public DuplikatKontaktiraneOsobe(String message)
    {
        super(message);
    }

    public DuplikatKontaktiraneOsobe(Throwable cause)
    {
        super(cause);
    }

    public DuplikatKontaktiraneOsobe(String message, Throwable cause)
    {
        super(message, cause);
    }
}
