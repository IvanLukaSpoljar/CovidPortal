/*package main.java_main_logic.extra_help;

import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.kontroleri_ekrana.novi_zapis.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;

public interface AppendPodataka {

    public default void AppendPodatakaZupanija(Long id, String naziv, Integer brojStanovnika, Integer brojZarazenih) {
        final Logger logger = LoggerFactory.getLogger(DodavanjeNoveZupanijeController.class);
        String imePostojeceDatoteke = "dat/zupanije.txt";
        try
        {
            FileWriter pisacPoDatoteci = new FileWriter(imePostojeceDatoteke,true);

            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(id));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(naziv);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(brojStanovnika));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(brojZarazenih));

            pisacPoDatoteci.close();
            logger.info("Nova �upanija je uspje�no spremljena u datoteku.");

            //BRISANJE STARE LISTE �UPANIJA
            for(int i = ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije.size() - 1; i >= 0; i--)
                ListeZupanijaSimptomaBolestiVirusaOsoba.sveZupanije.remove(i);

            //U�ITAVANJE NOVE LISTE �UPANIJA
            ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihZupanijaIzDatoteke(imePostojeceDatoteke);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje nove �upanije");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novoj �upaniji");
            obavijest.showAndWait();

        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo spremanje nove �upanije u datoteku.");
            System.out.println(ex.getMessage());
            logger.error(ex.getMessage(), ex);

            Alert obavijest = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            obavijest.setTitle("Spremanje nove �upanije");
            obavijest.setHeaderText("Gre�ka");
            obavijest.setContentText("Neuspje�no spremanje podataka o novoj �upaniji");
            obavijest.showAndWait();
        }
    }



    public default void AppendPodatakaSimptoma(Long id, String naziv, String ucestalost)
    {
       final Logger logger = LoggerFactory.getLogger(DodavanjeNovogSimptomaController.class);
       String imePostojeceDatoteke = "dat/simptomi.txt";

        try
        {
            FileWriter pisacPoDatoteci = new FileWriter(imePostojeceDatoteke,true);

            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(id));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(naziv);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(ucestalost);


            pisacPoDatoteci.close();
            logger.info("Novi simptom je uspje�no spremljen u datoteku.");

            //BRISANJE STARE LISTE SIMPTOMA
            for(int i = ListeZupanijaSimptomaBolestiVirusaOsoba.sviSimptomi.size() - 1; i >= 0; i--)
                ListeZupanijaSimptomaBolestiVirusaOsoba.sviSimptomi.remove(i);

            //U�ITAVANJE NOVE LISTE SIMPTOMA
            ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihSimptomaIzDatoteke(imePostojeceDatoteke);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje novog simptoma");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novom simptomu");
            obavijest.showAndWait();

        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo spremanje novog simptoma u datoteku.");
            System.out.println(ex.getMessage());
            logger.error(ex.getMessage(), ex);

            Alert obavijest = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            obavijest.setTitle("Spremanje novog simptoma");
            obavijest.setHeaderText("Gre�ka");
            obavijest.setContentText("Neuspje�no spremanje podataka o novom simptomu");
            obavijest.showAndWait();
        }
    }




    public default void AppendPodatakaBolesti(Long id, String naziv, String simptomi)
    {
        final Logger logger = LoggerFactory.getLogger(DodavanjeNoveBolestiController.class);
        String imePostojeceDatoteke = "dat/bolesti.txt";

        try
        {
            FileWriter pisacPoDatoteci = new FileWriter(imePostojeceDatoteke,true);

            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(id));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(naziv);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(simptomi);


            pisacPoDatoteci.close();
            logger.info("Nova bolest je uspje�no spremljen u datoteku.");

            //BRISANJE STARE LISTE BOLESTI
            for(int i = ListeZupanijaSimptomaBolestiVirusaOsoba.sveBolesti.size() - 1; i >= 0; i--)
                ListeZupanijaSimptomaBolestiVirusaOsoba.sveBolesti.remove(i);

            //U�ITAVANJE NOVE LISTE BOLESTI
            ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihBolestiIzDatoteke(imePostojeceDatoteke);
            System.out.println("Nova refreshana lista bolesti je: " + ListeZupanijaSimptomaBolestiVirusaOsoba.sveBolesti);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje nove bolesti");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novoj bolesti");
            obavijest.showAndWait();

        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo spremanje nove bolesti u datoteku.");
            System.out.println(ex.getMessage());
            logger.error(ex.getMessage(), ex);

            Alert obavijest = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            obavijest.setTitle("Spremanje nove bolesti");
            obavijest.setHeaderText("Gre�ka");
            obavijest.setContentText("Neuspje�no spremanje podataka o novoj bolesti");
            obavijest.showAndWait();
        }
    }




    public default void AppendPodatakaVirusa(Long id, String naziv, String simptomi)
    {
        final Logger logger = LoggerFactory.getLogger(DodavanjeNovogVirusaController.class);
        String imePostojeceDatoteke = "dat/virusi.txt";

        try
        {
            FileWriter pisacPoDatoteci = new FileWriter(imePostojeceDatoteke,true);

            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(id));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(naziv);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(simptomi);


            pisacPoDatoteci.close();
            logger.info("Novi virus je uspje�no spremljen u datoteku.");

            //BRISANJE STARE LISTE VIRUSA
            for(int i = ListeZupanijaSimptomaBolestiVirusaOsoba.sviVirusi.size() - 1; i >= 0; i--)
                ListeZupanijaSimptomaBolestiVirusaOsoba.sviVirusi.remove(i);

            //U�ITAVANJE NOVE LISTE VIRUSA
            ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihVirusaIzDatoteke(imePostojeceDatoteke);
            System.out.println("Nova refreshana lista virusa je: " + ListeZupanijaSimptomaBolestiVirusaOsoba.sviVirusi);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje novog virusa");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novom virusu");
            obavijest.showAndWait();

        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo spremanje novog virusa u datoteku.");
            System.out.println(ex.getMessage());
            logger.error(ex.getMessage(), ex);

            Alert obavijest = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            obavijest.setTitle("Spremanje novog virusa");
            obavijest.setHeaderText("Gre�ka");
            obavijest.setContentText("Neuspje�no spremanje podataka o novom virusu");
            obavijest.showAndWait();
        }
    }






    public default void AppendPodatakaOsoba(Long id, String imeOsobe, String prezimeOsobe, String starost, String zupanija, String bolest, String brojKontaktiranih, String odabirOsoba)
    {
        final Logger logger = LoggerFactory.getLogger(DodavanjeNoveOsobeController.class);
        String imePostojeceDatoteke = "dat/osobe.txt";

        try
        {
            FileWriter pisacPoDatoteci = new FileWriter(imePostojeceDatoteke,true);

            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(String.valueOf(id));
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(imeOsobe);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(prezimeOsobe);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(starost);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(zupanija);
            pisacPoDatoteci.write("\n");
            pisacPoDatoteci.write(bolest);

            if(ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.size() > 1)
            {
                pisacPoDatoteci.write("\n");
                pisacPoDatoteci.write(brojKontaktiranih);
                pisacPoDatoteci.write("\n");
                pisacPoDatoteci.write(odabirOsoba);
            }
            pisacPoDatoteci.close();
            logger.info("Nova osoba je uspje�no spremljena u datoteku.");

            //BRISANJE STARE LISTE OSOBA
            for(int i = ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.size() - 1; i >= 0; i--)
                ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.remove(i);

            //U�ITAVANJE NOVE LISTE OSOBA
            ListeZupanijaSimptomaBolestiVirusaOsoba.kreirajListuSvihOsobaIzDatoteke(imePostojeceDatoteke);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje nove osobe");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novoj osobi");
            obavijest.showAndWait();

        }
        catch(IOException ex)
        {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo spremanje nove osobe u datoteku.");
            System.out.println(ex.getMessage());
            logger.error(ex.getMessage(), ex);

            Alert obavijest = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            obavijest.setTitle("Spremanje nove osobe");
            obavijest.setHeaderText("Gre�ka");
            obavijest.setContentText("Neuspje�no spremanje podataka o novoj osobi");
            obavijest.showAndWait();
        }
    }
}

*/