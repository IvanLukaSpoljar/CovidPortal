package hr.java.covidportal.model;
/**
 * Slu�i za kreiranje objekta simptom u klasi Glavna.
 */
public class Simptom extends ImenovaniEntitet {
    private String vrijednost;

    //KOSNTRUKTOR

    /**
     * Prima naziv i vrijednost
     * @param naziv naziv simptoma
     * @param vrijednost u�estalost simptoma
     */
    public Simptom(String naziv, String vrijednost) {
        super(naziv);
        this.vrijednost = vrijednost;
    }

    public Simptom(){}


    //NAZIV - GETTER I SETTER SE NALAZI U IMENOVANOM ENTITETU


    //VRIJEDNOST
    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Simptom simptom = (Simptom) o;

        return vrijednost != null ? vrijednost.equals(simptom.vrijednost) : simptom.vrijednost == null;
    }

    @Override
    public int hashCode() {
        return super.getNaziv() != null ? super.getNaziv().hashCode() : 0;
    }

    @Override
    public String toString()
    {
        return super.getNaziv();
    }
}
