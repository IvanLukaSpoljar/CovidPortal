package hr.java.covidportal.main;

import hr.java.covidportal.enums.EnumeracijaSimptoma;
import hr.java.covidportal.genericsi.KlinikaZaInfektivneBolesti;
import hr.java.covidportal.genericsi.nova;
import hr.java.covidportal.iznimke.BolestIstihSimptoma;
import hr.java.covidportal.iznimke.DuplikatKontaktiraneOsobe;
import hr.java.covidportal.iznimke.LimitiraniBroj;
import hr.java.covidportal.model.*;


import hr.java.covidportal.pomocno.Varijable_Simptoma_i_Bolesti;
import hr.java.covidportal.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.SQLOutput;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Slu�i za testiranje logginga tijekom izvo�enja programa.
 */
public class Glavna {

    public static final Logger logger = LoggerFactory.getLogger(Glavna.class);

    /**
     * Slu�i za pokretanje programa koji �e od korisnika tra�iti da svojim unosom definira vrijednosti pojedinih
     * varijabli, te nakon toga da unese zara�ene osobe kod kojih �e se vidjeti jesu li u me�uvremenu zara�eni
     * nekom drugom bole��u i s kime su sve kontaktirali.
     *
     * @param args argumenti komandne linije
     */
    public static void main(String[] args) {

        logger.info("PO�ETAK PROGRAMA");

        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        Set<Zupanija> zupanije = new HashSet<>();
        Set<Simptom> simptomi = new HashSet<>();
        Set<Bolest> bolesti = new HashSet<>();
        List<Osoba> osobe = new ArrayList<>();

        //MAPA
        Map<Bolest, List<Osoba>> mapaZarazenihPoBolesti = new HashMap<>();


        //POMO�NE VARIJABLE
        Varijable_Simptoma_i_Bolesti dohvatVarijabli = new Varijable_Simptoma_i_Bolesti();
        Boolean flagIznimka = true;


        //<-------------�UPANIJE---------------->
        System.out.println("\n#################################################### UNOS �UPANIJA ####################################################");
        Integer ukupanBrojZupanija = 0;
        do {
            try {
                System.out.print("Unesite broj �upanija koje �elite unijeti: ");
                ukupanBrojZupanija = unos.nextInt();
                manji_Od_1(ukupanBrojZupanija);

                logger.info("Broj je ispravno une�en, broj �upanija je: " + ukupanBrojZupanija);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka);
        System.out.println("\nUnesite podatke o " + ukupanBrojZupanija + " �upanije: ");
        for (int i = 0; i < ukupanBrojZupanija; i++)
            zupanije.add(unosZupanije(unos, i));


        //<-------------SIMPTOMI---------------->
        System.out.println("\n#################################################### UNOS SIMPTOMA ####################################################");
        do {
            try {
                System.out.print("Unesite broj simptoma koje �elite unijeti: ");
                dohvatVarijabli.setUkupanBrojSimptoma(unos.nextInt());
                manji_Od_1(dohvatVarijabli.getUkupanBrojSimptoma());

                logger.info("Broj je ispravno une�en, broj simptoma je: " + dohvatVarijabli.getUkupanBrojSimptoma());

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka);
        System.out.println("\nUnesite podatke o " + dohvatVarijabli.getUkupanBrojSimptoma() + " simptoma: ");
        for (int i = 0; i < dohvatVarijabli.getUkupanBrojSimptoma(); i++) {
            simptomi.add(unosSimptoma(unos, i, simptomi));
        }

        //1.ZADATAK
        List<Simptom> pomocniSimptomi = new ArrayList<>(simptomi);
        pomocniSimptomi.stream()
                .filter(simptom ->simptom.getNaziv().toLowerCase().startsWith("g") && simptom.getNaziv().toLowerCase().contains("bolja"))
                .sorted((s1, s2) -> s1.getVrijednost().toLowerCase().compareTo(s2.getVrijednost().toLowerCase()))
                .forEach(System.out::println);

        //2.ZADATAK
        Integer zbrojduljina = simptomi.stream()
                .map(a -> a.getNaziv().length())
                .reduce(0, (a, b) -> a + b);
        System.out.println("Suma duljia je: " + zbrojduljina);

        Long brojrijeci = simptomi.stream()
                .map(a -> a.getNaziv().length())
                .count();
        System.out.println("Prosijek je: " + (double)zbrojduljina / (double)brojrijeci);

        List<Simptom> opetPomocniNizSimptoma = new ArrayList<>(simptomi);
        opetPomocniNizSimptoma = simptomi.stream()
                .sorted((a, b) ->
                        {
                            if(a.getNaziv().length() > b.getNaziv().length())
                                return 1;
                            else if(a.getNaziv().length() < b.getNaziv().length())
                                return -1;
                            else
                                return 0;
                        })
                .collect(Collectors.toList());

        System.out.println("Najkra�e ime je: " + opetPomocniNizSimptoma.get(0));
        System.out.println("Najdulje ime je: " + opetPomocniNizSimptoma.get(opetPomocniNizSimptoma.size() -1));


        //3.ZADATAK
        System.out.println();
        List<Simptom> l = new ArrayList<>(simptomi);
        nova a = new nova(l);
        a.get().stream()
                .forEach(System.out::println);

        /*System.out.println("Vrijdenost stringa je : " +  a.toString());*/


        //<-------------BOLESTI---------------->
        System.out.println("\n#################################################### UNOS BOLESTI #####################################################");
        do {
            try {
                System.out.print("Unesite broj bolesti koje �elite unijeti: ");
                dohvatVarijabli.setUkupanBrojBolesti(unos.nextInt());
                manji_Od_0(dohvatVarijabli.getUkupanBrojBolesti());
                System.out.print("Unesite broj virusa koje �elite unijeti: ");
                dohvatVarijabli.setUkupanBrojVirusa(unos.nextInt());
                manji_Od_0(dohvatVarijabli.getUkupanBrojVirusa());

                manji_Od_1(dohvatVarijabli.getUkupanBrojZaraza());
                logger.info("Broj je ispravno une�en, broj bolesti je: " + dohvatVarijabli.getUkupanBrojZaraza());

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                iznimkaOgranicenja = new LimitiraniBroj("Pogre�ka, broj mora biti jednak ili ve�i od 0, molimo ponovite unos za broj bolesti i broj virusa!");

                if (dohvatVarijabli.getUkupanBrojZaraza() == 0)
                    iznimkaOgranicenja = new LimitiraniBroj("Pogre�ka, treba postojati barem jedna bolesti ili virus, molimo ponovite unos za broj bolesti i broj virusa!");

                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka);
        System.out.println("\nUnesite podatke o " + dohvatVarijabli.getUkupanBrojZaraza() + " bolesti ili virusa: ");
        for (int i = 0; i < dohvatVarijabli.getUkupanBrojZaraza(); i++) {
            dohvatVarijabli.getSuma_Odabira_Simptoma_Za_Svaku_Bolest().add(0);
            bolesti.add(unosBolesti(unos, simptomi, i, dohvatVarijabli, bolesti));
        }

        for(Bolest element : bolesti)
            if(element instanceof Virus)
                dohvatVarijabli.getPomocni_Niz_Svih_Virusa().add((Virus)element);

        //<-------------OSOBE---------------->
        System.out.println("\n#################################################### UNOS OSOBA #######################################################");
        Integer ukupanBrojLjudi = 0;
        do {
            try {
                System.out.print("Unesite koliko osoba �elite unjeti: ");
                ukupanBrojLjudi = unos.nextInt();
                manji_Od_1(ukupanBrojLjudi);

                logger.info("Broj je ispravno une�en, broj ljudi je: " + ukupanBrojZupanija);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n" + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n" + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka);
        System.out.println("\nUnesite podatke o " + ukupanBrojLjudi + " osobe: ");
        for (int i = 0; i < ukupanBrojLjudi; i++)
            osobe.add(unosOsoba(unos, zupanije, bolesti, osobe, i));


        KlinikaZaInfektivneBolesti podatciKlinikeInfektivnihBolesti = new KlinikaZaInfektivneBolesti(osobe, dohvatVarijabli.getPomocni_Niz_Svih_Virusa());


        //ISPIS
        System.out.println("\n**************************************************** POPIS OSOBA ****************************************************\n");
        for (int indexOsobe = 0; indexOsobe < osobe.size(); indexOsobe++)
            ispisOsoba(osobe, indexOsobe);

        //ISPIS
        System.out.println("\n*********************************** ISPIS SVIH ZARA�ENIH OSOBA ODRE�ENOM BOLESTI ************************************\n");
        dodaj_Zarazene_Po_Bolesti_U_Mapu(bolesti, osobe, mapaZarazenihPoBolesti);
        ispis_Mape_Zarazenih_Po_Bolesti(mapaZarazenihPoBolesti);

        //ISPIS
        System.out.println("\n*********************************** �UPANIJA SA NAJVE�IM POSTOTKOM ZARA�ENOSTI **************************************\n");
        List<Zupanija> pomocnaListaZupanija = new ArrayList<Zupanija>(zupanije);
        Collections.sort(pomocnaListaZupanija, new CovidSorter<Zupanija>());
        System.out.println("  Najvi�e zara�enih osoba ima u �upaniji " + pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getNaziv() + ": " + (int) pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getPostotakZarazenost() + "%.");

        //ISPIS
        System.out.println("\n******************************** IMENA VIRUSA SORTIRANIH SILAZNIM ABECEDNIM REDOM ***********************************\n");

        /*List<Virus> paralelnistream = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startparallelLambda = Instant.now();
        paralelnistream = paralelnistream.parallelStream()
                .sorted((v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv()))
                .collect(Collectors.toList());
        Instant endParallelLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom preko ParallelStream-a po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < paralelnistream.size(); i++)
            System.out.println("  " + (i + 1) + ". " + paralelnistream.get(i).getNaziv());

        System.out.println();
        System.out.println();*/

        List<Virus> sortiranjeVirusaLambdom = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startLambda = Instant.now();
        sortiranjeVirusaLambdom = sortiranjeVirusaLambdom.stream()
                .sorted(new CovidSorter<Virus>()) /*(v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv())*/
                .collect(Collectors.toList());
        Instant endLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusaLambdom.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusaLambdom.get(i).getNaziv());

        // System.out.println();
        //  System.out.println();

        List<Virus> sortiranjeVirusa = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant start = Instant.now();
        //mojaMetodaSortiranjaVirusa(sortiranjeVirusa);
        //Collections.sort(sortiranjeVirusa, new CovidSorter<Virus>());
        sortiranjeVirusa.sort(new CovidSorter<Virus>());
        Instant end = Instant.now();
        /*System.out.println("  Virusi sortirani pomo�u moje funkcije za sortiranje po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusa.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusa.get(i).getNaziv());*/


        //System.out.printf("\n\n  Sotiranje objekata paralenim streamom traje: %d milisekundi.", Duration.between(startparallelLambda, endParallelLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata kori�tenjem lambdi traje: %d milisekundi.", Duration.between(startLambda, endLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata bez kori�tenja lambde traje: %d milisekundi.\n", Duration.between(start, end).toMillis());


        //ISPIS
        System.out.println("\n******************************************* PRETRAGA PO DIJELU STRINGA **********************************************\n");
        /*Boolean ponovi;
        do {
            System.out.print("  Unesite string za pretragu po prezimenu: ");
            vrijednostPretrazivanja = unos.nextLine();

            String regex = "^[- 0-9A-Za-z]*$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(vrijednostPretrazivanja);

            if (matcher.matches() == true)
            {
                ponovi = false;
            } else {
                ponovi = true;
                System.out.println();
                System.out.println("  Krivo unesena vrijednost, probajte opet.");
            }
        }while(ponovi);*/

        System.out.print("  Unesite string za pretragu po prezimenu: ");
        String vrijednostPretrazivanja = unos.nextLine();
        Optional<List<Osoba>> rezultatiPretrazivanjaPoPrezimenu = Optional.ofNullable(
                osobe.stream()
                        .filter(osoba -> osoba.getPrezime().toLowerCase().contains(vrijednostPretrazivanja.toLowerCase()))
                        .sorted((osoba1, osoba2) -> osoba1.getPrezime().compareTo(osoba2.getPrezime()))
                        .collect(Collectors.toList())
        );


        if (vrijednostPretrazivanja.isEmpty()) {
            System.out.println("\n  Nema pretrage.");
        } else {
            if (rezultatiPretrazivanjaPoPrezimenu.get().isEmpty()) {
                System.out.println("\n  Nema takve osobe koja u prezimenu sadr�i une�ena slova.");
            } else {
                System.out.println("\n  Osobe �ije prezime sadr�i �" + vrijednostPretrazivanja + "� su sljede�e:  ");
                for (int i = 0; i < rezultatiPretrazivanjaPoPrezimenu.get().size(); i++) {
                    System.out.println("  " + (i + 1) + ". " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getIme() + " " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getPrezime());
                }
            }
        }

        //ISPIS
        System.out.println("\n*********************************** ISPIS BROJA SIMPTOMA ZA SVAKU VRSTU ZARAZE **************************************\n");
        List<String> ispisBrojaSimptomaZaBolest = bolesti.stream()
                .map(recenica -> new String(recenica.getNaziv() + " ima " + recenica.getSimptomi().size() + " simptoma."))
                .collect(Collectors.toList());
        for (int i = 0; i < ispisBrojaSimptomaZaBolest.size(); i++)
            System.out.println("  " + (i + 1) + ". " + ispisBrojaSimptomaZaBolest.get(i));





        logger.info("ZAVR�ETAK PROGRAMA");
        //KRAJ CIJELE MAIN FUNKCIJE
    }


    //METODA ZA UNOS �UPANIJA

    /**
     * Tra�i od korisnika da unese naziv �upanije, te zatim broj stanovnika te �upanije.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i    broji �upanije
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unosZupanije(Scanner unos, int i) {
        String nazivZupanije;
        Integer brojStanovnika = 0;
        Integer brojZarazenihStanovnika = 0;
        Boolean flagIznimka = false;

        System.out.print((i + 1) + ". �upanija:");
        System.out.print("\n    Unesite naziv �upanije: ");
        nazivZupanije = unos.nextLine();


        //PROVJERA IZNIMKE ZA UNOS BROJA STANOVNIKA
        do {
            try {
                System.out.print("    Unesite broj stanovnika: ");
                brojStanovnika = unos.nextInt();
                manji_Od_1(brojStanovnika);

                logger.info("Broj je ispravno une�en, broj stanovnika je: " + brojStanovnika);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        //PROVJERA IZNIMKE ZA UNOS BROJA ZARA�ENIH
        do {
            try {
                System.out.print("    Unesite broj zara�enih stanovnika: ");
                brojZarazenihStanovnika = unos.nextInt();
                manji_Od_0(brojZarazenihStanovnika);

                logger.info("Broj je ispravno une�en, broj zara�enih stanovnika je: " + brojZarazenihStanovnika);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        System.out.println();

        Zupanija zupanija = new Zupanija(nazivZupanije, brojStanovnika, brojZarazenihStanovnika);
        return zupanija;
    }


    //METODA ZA UNOS SIMPTOMA

    /**
     * Tra�i od korisnika da unese naziv simptoma, te zatim u�estalost tog simptoma.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i    broji simptome
     * @return vra�a simptom kao objekt
     */
    private static Simptom unosSimptoma(Scanner unos, int i, Set<Simptom> simptomi) {
        String naziv;
        String vrijednost;
        Boolean ponovi;

        do {
            System.out.println((i + 1) + ". Simptom:");
            System.out.print("    Unesite naziv simptoma: ");
            naziv = unos.nextLine();

            do {
                System.out.print("    Unesite vrijednost simptoma (RIJETKO, SREDNJE ILI �ESTO): ");
                vrijednost = unos.nextLine();

                ponovi = false;

                if (vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.RIJETKO.getOpis()) == 0)
                    vrijednost = EnumeracijaSimptoma.RIJETKO.getOpis();
                else if (vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.SREDNJE.getOpis()) == 0)
                    vrijednost = EnumeracijaSimptoma.SREDNJE.getOpis();
                else if (vrijednost.compareToIgnoreCase(EnumeracijaSimptoma.CESTO.getOpis()) == 0)
                    vrijednost = EnumeracijaSimptoma.CESTO.getOpis();
                else {
                    System.out.println("\n    Krivi unos, to�no unesite navedene vrijednosti: RIJETKO, SREDNJE ili �ESTO");
                    ponovi = true;
                }
            }
            while (ponovi);
            System.out.println();

        } while (provjeri_Ista_Imena(simptomi, naziv));

        Simptom simptom = new Simptom(naziv, vrijednost);
        return simptom;
    }


    //METODA ZA UNOS BOLESTI

    /**
     * Tra�i od korisnika da odabere vrstu bolesti, zatim njen naziv, broj simptoma te bolesti i da dodjeli
     * simptome bolesti.
     *
     * @param unos     varijabla za unos preko tipkovnice
     * @param simptomi objekt koji se proslije�uje, slu�i za dodjeljivanje odre�enog simptoma bolesti
     * @param i        broji bolesti
     * @param y        dohvat pomo�nih varijabla
     * @return vra�a bolest kao objekt
     */
    private static Bolest unosBolesti(Scanner unos, Set<Simptom> simptomi, int i, Varijable_Simptoma_i_Bolesti y, Set<Bolest> bolesti) {
        String nazivBolesti;

        Integer zbrojOdabiraSimptomaPlusN = 0;
        Integer brojSimptoma = 0;
        Integer odabirVrsteBolesti = 0;
        Integer brojacIstihSimptomaUBolesti = 0;
        Integer odabirSimptoma = 0;

        Boolean odabranVirus = false;
        Boolean odabranaBolest = false;
        Boolean flagIznimka = false;
        Boolean ponoviOdNazivaBolesti = false;
        Boolean ponovi = false;

        Set<Simptom> simptomiBolesti = new HashSet<>();


        //UNOS BOLESTI ILI VIRUSA
        System.out.println((i + 1) + ". Vrsta zaraze:");
        System.out.println("    Unosite ili bolest ili virus?");
        System.out.println("    1) Bolest");
        System.out.println("    2) Virus");

        do {
            try {
                System.out.print("    Odaberite vrstu bolesti: ");
                odabirVrsteBolesti = unos.nextInt();
                provjeri_Valjanost_Odabira_Vrste_Bolesti(odabirVrsteBolesti, y);

                if (odabirVrsteBolesti == 1)
                    odabranaBolest = true;
                else if (odabirVrsteBolesti == 2)
                    odabranVirus = true;

                logger.info("Broj je ispravno une�en, vrsta bolesti je pod brojem: " + odabirVrsteBolesti);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        do {
            ponoviOdNazivaBolesti = false;
            zbrojOdabiraSimptomaPlusN = 0;

            //UNOS NAZIVA BOLESTI ILI VIRUSA

            do {
                System.out.print("\n    Unesite naziv bolesti ili virusa: ");
                nazivBolesti = unos.nextLine();
            } while (provjeri_Ista_Imena(bolesti, nazivBolesti));


            //PROVJERA IZNIMKE ZA UNOS BROJA
            do {
                try {
                    System.out.print("    Unesite broj simptoma: ");
                    brojSimptoma = unos.nextInt();
                    manje_Od_1_Ili_Vece_Od_Limita(brojSimptoma, simptomi.size());

                    logger.info("Broj je ispravno une�en, ukupni broj simptoma za trenutnu bolest je: " + brojSimptoma);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (LimitiraniBroj iznimkaOgranicenja) {
                    iznimkaOgranicenja = new LimitiraniBroj("Krivi unos, broj mora biti u intervalu od 1 do " + simptomi.size() + ".");
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

            List<Integer> provjera_Duplih_Simptoma_U_Bolesti = new ArrayList<>();

            zbrojOdabiraSimptomaPlusN = 0;
            for (int j = 0; j < brojSimptoma; j++) {
                //ODABERI SIMPTOM POMO�U BROJA
                do {
                    System.out.println("\n    Odaberite " + (j + 1) + ". simptom: ");

                    int x = 0;
                    for (Simptom element : simptomi) {
                        System.out.println("    " + (x + 1) + ". " + element.getNaziv() + " " + element.getVrijednost());
                        x++;
                    }

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    do {
                        try {
                            System.out.print("    Odabir simptoma: ");
                            odabirSimptoma = unos.nextInt();
                            manje_Od_1_Ili_Vece_Od_Limita(odabirSimptoma, simptomi.size());

                            logger.info("Broj je ispravno une�en, simptom je pod brojem: " + odabirSimptoma);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (LimitiraniBroj iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);

                    //PONAVLJA LI SE ISTI SIMPTOM ZA ISTU BOLEST, NEMOGU�E JE DA BOLEST IMA 2 ILI VI�E ISTA SIMPTOMA
                    provjera_Duplih_Simptoma_U_Bolesti.add(odabirSimptoma);
                    brojacIstihSimptomaUBolesti = 0;
                    for (int k = 0; k < provjera_Duplih_Simptoma_U_Bolesti.size(); k++) {
                        if (odabirSimptoma.equals(provjera_Duplih_Simptoma_U_Bolesti.get(k))) {
                            brojacIstihSimptomaUBolesti++;
                            if (brojacIstihSimptomaUBolesti == 2) {
                                ponovi = true;
                                provjera_Duplih_Simptoma_U_Bolesti.remove(provjera_Duplih_Simptoma_U_Bolesti.size() - 1);
                            }
                        }
                    }

                    //UKOLIKO DO�E DO ISTIH SIMPTOMA UNUTAR ISTE BOLESTI
                    if (ponovi == true) {
                        int counter = 0;
                        Simptom pomocniSimptom = new Simptom();
                        for (Simptom pomocni : simptomi) {
                            if (counter == odabirSimptoma - 1)
                                pomocniSimptom = pomocni;
                            counter++;
                        }
                        System.out.println("\n    Svi simptomi trenutne zaraze moraju biti me�usobno razli�iti, simptom " + pomocniSimptom.getNaziv() + " je ve� odabran.\n    Molimo odaberite novi simptom.");
                    }
                }
                while (ponovi == true);

                zbrojOdabiraSimptomaPlusN = zbrojOdabiraSimptomaPlusN + odabirSimptoma + (y.getUkupanBrojSimptoma() * y.getUkupanBrojSimptoma());

                int counter = 0;
                Simptom pomocniSimptom = new Simptom();
                for (Simptom pomocni : simptomi) {
                    if (counter == odabirSimptoma - 1)
                        pomocniSimptom = pomocni;
                    counter++;
                }
                simptomiBolesti.add(pomocniSimptom);
            }

            //System.out.println("Suma odabira + 1 simptoma za trenutnu bolest je: " + zbrojOdabiraSimptomaPlusN);

            //PROVJERAVA JEL POSTOJE BOLESTI SA ISTIM SIMPTOMIMA
            try {
                //USPORE�UJE SE SUMA ODABIRA SIMPTOMA TRENUTNE BOLESTI SA SUMOM ODABIRA SIMPTOMA ZA SVAKU BOLEST DO SADA UNE�ENU
                provjeriBolestiIstihSimptoma(zbrojOdabiraSimptomaPlusN, y.getSuma_Odabira_Simptoma_Za_Svaku_Bolest());
                y.getSuma_Odabira_Simptoma_Za_Svaku_Bolest().set(i, zbrojOdabiraSimptomaPlusN);
                ponoviOdNazivaBolesti = false;

            } catch (BolestIstihSimptoma iznimkaIstihSimptoma) {
                System.out.println("    " + iznimkaIstihSimptoma.getMessage() + "\n");
                logger.error(iznimkaIstihSimptoma.getMessage(), iznimkaIstihSimptoma);
                ponoviOdNazivaBolesti = true;
                simptomiBolesti.clear();
            }

        } while (ponoviOdNazivaBolesti == true);


        //BOLEST ILI VIRUS ?
        Bolest element = null;
        if (odabranaBolest)
            element = new Bolest(nazivBolesti, simptomiBolesti);
        else if (odabranVirus)
            element = new Virus(nazivBolesti, simptomiBolesti);

        System.out.println();
        return element;
    }


    //METODA ZA UNOS OSOBA

    /**
     * Tra�i unos osobe, odnosno njezinh podataka.
     *
     * @param unos     varijabla za unos preko tipkovnice
     * @param zupanije niz svih �upanija koje korisnik na po�etku programa unio
     * @param bolesti  niz svih bolesti koje je korisnik unio tijekom programa
     * @param osobe    niz osoba koji �e pohraniti ovu osobu
     * @param i        broji osobe
     * @return vra�a osobu kao objekt
     */
    private static Osoba unosOsoba(Scanner unos, Set<Zupanija> zupanije, Set<Bolest> bolesti, List<Osoba> osobe, int i) {
        String imeOsobe;
        String prezimeOsobe;
        Integer starostOsobe = 0;
        Boolean flagIznimka = true;


        System.out.println((i + 1) + ". Osoba:");
        //UNOS IMENA OSOBE
        System.out.print("    Unesite ime osobe: ");
        imeOsobe = unos.nextLine();
        //UNOS PREZIMENA OSOBE
        System.out.print("    Unesite prezime osobe: ");
        prezimeOsobe = unos.nextLine();
        //UNOS BROJA GODINA OSOBE I PROVJERA IZNIMKE
        do {
            System.out.print("    Unesite starost osobe: ");
            try {
                starostOsobe = unos.nextInt();
                manji_Od_1(starostOsobe);

                logger.info("Broj je ispravno une�en, starost osobe je: " + starostOsobe);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                iznimkaOgranicenja = new LimitiraniBroj("Pogre�ka, broj mora biti ve�i od 0, molimo ponovite unos!");
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        //FINALNO INICIJALIZIRANJE TRENUTNE OSOBE SA SVIM PARAMETRIMA
        return new Osoba.Builder(imeOsobe)
                .surname(prezimeOsobe)
                .age(starostOsobe)
                .county(unos_Zupanije_Osobe(unos, zupanije)) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                .personInfection(unos_Bolesti_Osobe(unos, bolesti)) //UNOS BOLESTI OSOBE
                .contactedPersons(kontaktiranje_Sa_Zarazenim_Osobama(unos, osobe, i)) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                .makeItDone();
    }


    //METODA ZA UNOS PREBIVALI�NE �UPANIJE SVAKE OSOBE

    /**
     * Dodjeljivanje �upanije osobi.
     *
     * @param unos     varijabla za unos preko tipkovnice
     * @param zupanije niz �upanija
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unos_Zupanije_Osobe(Scanner unos, Set<Zupanija> zupanije) {
        Integer odabirZupanije = 0;

        System.out.println("\n    Unesite �upaniju prebivali�ta osobe: ");
        Iterator<Zupanija> ponavljac = zupanije.iterator();
        for (int j = 0; j < zupanije.size(); j++)
            System.out.println("    " + (j + 1) + ". " + ponavljac.next().getNaziv());

        //PROVJERA IZNIMKE ZA UNOS BROJA
        Boolean flagIznimka = true;
        do {
            try {
                System.out.print("    Odabir: ");
                odabirZupanije = unos.nextInt();
                manje_Od_1_Ili_Vece_Od_Limita(odabirZupanije, zupanije.size());

                logger.info("Broj je ispravno une�en, broj odabrane �upanije je: " + odabirZupanije);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                iznimkaOgranicenja = new LimitiraniBroj("Krivi unos, odabrite �upaniju osobe koja se nalazi na popisu (interval od 1 do " + zupanije.size() + ").");
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        int counter = 0;
        Zupanija finalna = new Zupanija();
        for (Zupanija pomocna : zupanije) {
            if (counter == odabirZupanije - 1)
                finalna = pomocna;
            counter++;
        }
        return finalna;
    }


    //METODA ZA UNO�ENJE BOLESTI SVAKE OSOBE

    /**
     * Dodjeljivanje bolesti osobi.
     *
     * @param unos    varijabla za unos preko tipkovnice
     * @param bolesti niz bolesti
     * @return vra�a bolest kao objekt (ime, niz simptoma)
     */
    private static Bolest unos_Bolesti_Osobe(Scanner unos, Set<Bolest> bolesti) {
        Integer odabirBolesti = 0;

        System.out.println("\n    Unesite bolest ili virus osobe: ");
        Iterator<Bolest> ponavljacBolesti = bolesti.iterator();
        for (int j = 0; j < bolesti.size(); j++)
            System.out.println("    " + (j + 1) + ". " + ponavljacBolesti.next().getNaziv());

        //PROVJERA IZNIMKE ZA UNOS BROJA
        Boolean flagIznimka = true;
        do {
            try {
                System.out.print("    Odabir: ");
                odabirBolesti = unos.nextInt();
                manje_Od_1_Ili_Vece_Od_Limita(odabirBolesti, bolesti.size());

                logger.info("Broj je ispravno une�en, odabrana bolest je pod brojem: " + odabirBolesti);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
                System.out.println();
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (LimitiraniBroj iznimkaOgranicenja) {
                iznimkaOgranicenja = new LimitiraniBroj("Krivi unos, odabrite bolest ili virus koji se nalazi na popisu (interval od 1 do " + bolesti.size() + ").");
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);

        int counter = 0;
        Bolest finalna = new Bolest();
        for (Bolest pomocna : bolesti) {
            if (counter == odabirBolesti - 1)
                finalna = pomocna;
            counter++;
        }

        return finalna;
    }


    //METODA ZA UNO�ENJE KONTAKATA SA ZARA�ENIM OSOBAMA

    /**
     * Provjerava s kime je trenutna osoba bila u kontaktu.
     *
     * @param unos  varijabla za unos preko tipkovnice
     * @param osobe niz osoba
     * @param i     broja� osoba
     * @return vra�a niz kontaktiranih osoba
     */
    private static List<Osoba> kontaktiranje_Sa_Zarazenim_Osobama(Scanner unos, List<Osoba> osobe, int i) {
        Integer brojKontaktiranihOsoba = 0;
        Boolean ponovi = true;

        //OD 2. OSOBE (INDEKS 1) PA NADALJE DOPUSTI UNOS BROJA OSOBA KOJE SU BILE U KONTAKTU S TOM OSOBOM
        if (i > 0) {
            do {
                //PROVJERA IZNIMKE ZA UNOS BROJA
                Boolean flagIznimka = true;
                do {
                    System.out.print("    Unesite broj osoba koje su bile u kontaktu s tom osobom: ");
                    try {
                        brojKontaktiranihOsoba = unos.nextInt();
                        provjeri_Valjanost_Broja_Kontaktiranih_Osoba(i, brojKontaktiranihOsoba);

                        logger.info("Broj je ispravno une�en, ukupan broj kontaktiranih osoba je: " + brojKontaktiranihOsoba);

                        flagIznimka = false;
                        ponovi = false;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (InputMismatchException iznimkaBroj) {
                        iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                        System.out.println("\n    " + iznimkaBroj.getMessage());
                        logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (LimitiraniBroj iznimkaOgranicenja) {
                        System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                        logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    }
                } while (flagIznimka == true);
            }
            while (ponovi);
            System.out.println();
        }

        //OMOGU�UJE UNOS PRETHODNIH ZARA�ENIH OSOBA, TIME �E SE STVORITI OBJEKTI U NIZU PRETHODNIH ZARA�ENIH OSOBA
        if (brojKontaktiranihOsoba > 0) {
            Integer odabirKontaktiraneOsobe = 0;
            Integer[] nizOdabranihOsoba = new Integer[0];

            System.out.println("    Unesite osobe koje su bile u kontaktu s tom osobom:");
            for (int j = 0; j < brojKontaktiranihOsoba; j++) {
                nizOdabranihOsoba = Arrays.copyOf(nizOdabranihOsoba, nizOdabranihOsoba.length + 1);
                do {
                    System.out.println("    Odaberite " + (j + 1) + ". osobu:");
                    for (int k = 0; k < i; k++) {
                        System.out.println("    " + (k + 1) + ". " + osobe.get(k).getIme() + " " + osobe.get(k).getPrezime());
                    }

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    Boolean flagIznimka = true;
                    do {
                        System.out.print("    Odabir: ");
                        try {
                            odabirKontaktiraneOsobe = unos.nextInt();
                            provjeri_Valjanost_Odabira_Kontaktirane_Osobe(i, odabirKontaktiraneOsobe, j);

                            logger.info("Broj je ispravno une�en, odabir kontaktirane osobe je pod brojem: " + odabirKontaktiraneOsobe);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (LimitiraniBroj iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage() + "\n");
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);


                    if (ponovi == false) {
                        //POSTOJE LI DUPLIKATI U KONTAKTIRANIM OSOBAMA
                        try {
                            nizOdabranihOsoba[j] = odabirKontaktiraneOsobe;
                            provjeraDuplikataKontaktiranihOsoba(nizOdabranihOsoba);
                            logger.info("Nema duplikata me�u kontaktiranim osobama");
                            ponovi = false;

                        } catch (DuplikatKontaktiraneOsobe iznimkaDupleKontaktiraneOsobe) {
                            System.out.println("    " + iznimkaDupleKontaktiraneOsobe.getMessage() + "\n");
                            logger.error(iznimkaDupleKontaktiraneOsobe.getMessage(), iznimkaDupleKontaktiraneOsobe);
                            ponovi = true;
                        }
                    }
                }
                while (ponovi);
                System.out.println();
            }

            List<Osoba> kontaktiraneZarazeneOsobe = new ArrayList<>();
            for (int k = 0; k < nizOdabranihOsoba.length; k++)
                kontaktiraneZarazeneOsobe.add(osobe.get(nizOdabranihOsoba[k] - 1));

            return kontaktiraneZarazeneOsobe;
        } else {
            return null;
        }
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA

    /**
     * Ispisuje podatke o osobama.
     *
     * @param osobe niz osoba
     * @param i     index osobe u nizu
     */
    private static void ispisOsoba(List<Osoba> osobe, Integer i) {

        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe.get(i).getIme() + " " + osobe.get(i).getPrezime());
        System.out.println("    Starost: " + osobe.get(i).getStarost());
        System.out.println("    �upanija prebivali�ta: " + osobe.get(i).getZupanija().getNaziv());
        System.out.println("    Zara�en bole��u: " + osobe.get(i).getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");
        //osobe[i] JE TRENUTNA OSOBA KOJA MO�E SADR�AVATI NIZ ZAR�ENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe.get(i).getKontaktiraneOsobe() != null) //PROVJERVA DA LI NIZ ZARA�ENIH OSOBA UOP�E POSTOJI
        {
            for (int j = 0; j < osobe.get(i).getKontaktiraneOsobe().size(); j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe.get(i).getKontaktiraneOsobe().get(j).getIme() + " " + osobe.get(i).getKontaktiraneOsobe().get(j).getPrezime());
            }
        } else //AKO NIZ ZARA�ENIH OSOBA NE POSTOJI
        {
            System.out.print("Nema kontaktiranih osoba.");
        }
        System.out.println("\n");
    }


    /**
     * Provjerava da li je broj stanovnika negativan broj.
     *
     * @param x broj stanovnika �upanije
     * @throws LimitiraniBroj neispravan unos
     */
    private static void manji_Od_0(Integer x) {
        if (x < 0)
            throw new LimitiraniBroj("Pogre�ka, broj mora biti jednak ili ve�i od 0, molimo ponovite unos!");
    }


    /**
     * Provjerava da li je broj ve�i od 0.
     *
     * @param x broj
     * @throws LimitiraniBroj neispravan unos
     */
    private static void manji_Od_1(Integer x) {
        if (x < 1)
            throw new LimitiraniBroj("Pogre�ka, broj mora biti ve�i od 0, molimo ponovite unos!");
    }


    /**
     * Provjerava valjanost odabira �upanije kod osobe.
     *
     * @param odabir broj pod kojim se nalazi stavka
     * @throws LimitiraniBroj neispravan unos
     */
    private static void manje_Od_1_Ili_Vece_Od_Limita(Integer odabir, Integer limit) {
        if (odabir < 1 || odabir > limit)
            throw new LimitiraniBroj();
    }


    /**
     * Provjerava valjanost za ukupan broj s kojima je osoba mogla kontaktirati
     *
     * @param i                      index trenutne osobe, samo osobe koje dolaze prije trenutne osobe mogu biti kontaktirane
     * @param brojKontaktiranihOsoba broj kontaktiranih osoba
     * @throws LimitiraniBroj neispravan unos
     */
    private static void provjeri_Valjanost_Broja_Kontaktiranih_Osoba(int i, Integer brojKontaktiranihOsoba) {
        if (brojKontaktiranihOsoba > i || brojKontaktiranihOsoba < 0)
            throw new LimitiraniBroj("Neispravan unos broja kontaktiranih osoba, mo�ete odabrani maksimalno " + i + ", a minimalno 0 osoba.");
    }


    /**
     * Provjerava valjanost odabira kontaktirane osobe.
     *
     * @param i                       max broj osoba s kojima je osoba mogla biti u kontaktu
     * @param odabirKontaktiraneOsobe broj pod kojim se osoba nalazi
     * @param j                       index kontaktirane osobe u nizu kontaktiranih osoba
     * @throws LimitiraniBroj neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Kontaktirane_Osobe(int i, Integer odabirKontaktiraneOsobe, int j) {
        if (odabirKontaktiraneOsobe < 1 || odabirKontaktiraneOsobe > i)
            throw new LimitiraniBroj("Krivi unos, odabrite kontaktiranu osobu koja se nalazi na popisu (interval od 1 do " + i + "). Ponovite unos za " + (j + 1) + ". osobu!");
    }


    /**
     * Provjerava ako se ponavljaju iste kontaktirane osobe
     *
     * @param niz niz odabira kontaktiranih osoba
     * @throws DuplikatKontaktiraneOsobe govori da je do�lo do duplikata
     */
    //METODA ZA PROVJERU DUPLIKATA KONTAKTIRANIH ZARA�ENIH OSOBA I BACANJE IZNIMKE
    private static void provjeraDuplikataKontaktiranihOsoba(Integer[] niz) throws DuplikatKontaktiraneOsobe {
        int counter = 0;
        for (int i = 0; i < niz.length; i++) {
            if (niz[niz.length - 1] == niz[i]) {
                counter++;
                if (counter == 2) {
                    throw new DuplikatKontaktiraneOsobe("Odabrana osoba se ve� nalazi me�u kontaktiranim osobama. Molimo Vas da odaberete neku drugu osobu.");
                }
            }
        }
    }


    /**
     * Provjerava koju vrstu bolesti je korisnik odabrao.
     *
     * @param odabirVrsteBolesti broj pod kojim se vrsta bolesti nalazi
     * @throws LimitiraniBroj neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Vrste_Bolesti(Integer odabirVrsteBolesti, Varijable_Simptoma_i_Bolesti y) {
        if (odabirVrsteBolesti == 1) {
            y.setBrojacBolesti(y.getBrojacBolesti() + 1);

            if (y.getBrojacBolesti() > y.getUkupanBrojBolesti())
                throw new LimitiraniBroj("Ve� ste odabrali " + y.getUkupanBrojBolesti() + " bolesti, molimo odaberite virus");
        } else if (odabirVrsteBolesti == 2) {
            y.setBrojacVirusa(y.getBrojacVirusa() + 1);
            if (y.getBrojacVirusa() > y.getUkupanBrojVirusa())
                throw new LimitiraniBroj("Ve� ste odabrali " + y.getUkupanBrojVirusa() + " virusa, molimo odaberite bolest");
        } else if (odabirVrsteBolesti < 1 || odabirVrsteBolesti > 2)
            throw new LimitiraniBroj("Krivi odabir vrste bolesti, molimo odaberite broj 1 ili 2");
    }


    //METODA ZA PROVJERAVANJE ISTIH SIMPTOMA KOD BOLESTI

    /**
     * Provjerava ponavljaju li se isti simptomi
     *
     * @param element                               suma odabira simptoma za jednu bolest
     * @param suma_Odabira_Simptoma_Za_Svaku_Bolest niz suma odabira simptoma za svaku bolest
     * @throws BolestIstihSimptoma ne dopu�ta unos bolesti koje imaju iste simptome
     */
    private static void provjeriBolestiIstihSimptoma(Integer element, List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest) {
        Integer ponavljanje = 0;

        for (int i = 0; i < suma_Odabira_Simptoma_Za_Svaku_Bolest.size(); i++)
            if (element == suma_Odabira_Simptoma_Za_Svaku_Bolest.get(i))
                ponavljanje++;

        if (ponavljanje >= 1)
            throw new BolestIstihSimptoma("Pogre�an unos, ve� ste unijeli bolest ili virus s istim simptomima. Molimo ponovite unos.");
    }


    public static <T extends ImenovaniEntitet> Boolean provjeri_Ista_Imena(Set<T> fiskniNiz, String primjerak) {
        Boolean ponovi = false;

        whilePetlja:
        {
            Iterator<T> iter1 = fiskniNiz.iterator();
            while (iter1.hasNext()) {
                String naziv = iter1.next().getNaziv();
                if (primjerak.compareToIgnoreCase(naziv) == 0) {
                    System.out.println("    Unesite drugi naziv, isti naziv ve� postoji\n");
                    ponovi = true;
                    break whilePetlja;
                }
            }
        }

        return ponovi;
    }


    public static void dodaj_Zarazene_Po_Bolesti_U_Mapu(Set<Bolest> bolesti, List<Osoba> osobe, Map<Bolest, List<Osoba>> mapa) {
        for (Bolest pomocna : bolesti) {
            List<Osoba> pomocniNizOsoba = new ArrayList<>();
            for (int i = 0; i < osobe.size(); i++)
                if (pomocna.getNaziv().equals(osobe.get(i).getZarazenBolescu().getNaziv()) == true)
                    pomocniNizOsoba.add(osobe.get(i));

            if (pomocniNizOsoba.size() >= 1)
                mapa.put(pomocna, pomocniNizOsoba);
        }
    }


    public static void ispis_Mape_Zarazenih_Po_Bolesti(Map<Bolest, List<Osoba>> mapa) {
        for (Bolest key : mapa.keySet()) {
            if (key instanceof Virus)
                System.out.print("  Od virusa " + key.getNaziv() + " boluju: ");
            else
                System.out.print("  Od bolesti " + key.getNaziv() + " boluju: ");

            for (int i = 0; i < mapa.get(key).size(); i++) {
                if (i > 0)
                    System.out.print(", ");
                System.out.print(mapa.get(key).get(i).getIme() + " " + mapa.get(key).get(i).getPrezime());
            }
            System.out.println();
        }
    }


    public static void mojaMetodaSortiranjaVirusa(List<Virus> sortiranjeVirusa) {
        for (int i = 0; i < sortiranjeVirusa.size(); i++) {
            String naziv1 = sortiranjeVirusa.get(i).getNaziv();
            for (int j = 0; j < sortiranjeVirusa.size(); j++) {
                String naziv2 = sortiranjeVirusa.get(j).getNaziv();

                if (naziv2.compareToIgnoreCase(naziv1) <= -1) {
                    Virus tmp = sortiranjeVirusa.get(i);

                    sortiranjeVirusa.set(i, sortiranjeVirusa.get(j));
                    sortiranjeVirusa.set(j, tmp);
                }
            }
        }
    }


    //KRAJ CIJELE KLASE: GLAVNA
}
