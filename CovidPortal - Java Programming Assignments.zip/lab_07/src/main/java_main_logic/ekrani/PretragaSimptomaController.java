package main.java_main_logic.ekrani;

        import main.java_main_logic.model.Simptom;
        import javafx.collections.FXCollections;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.fxml.Initializable;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.control.TableColumn;
        import javafx.scene.control.TableView;
        import javafx.scene.control.TextField;
        import javafx.scene.control.cell.PropertyValueFactory;
        import main.java_main_logic.GLAVNO.Main;
        import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
        import org.slf4j.Logger;
        import org.slf4j.LoggerFactory;


        import java.io.IOException;
        import java.net.URL;
        import java.util.ArrayList;
        import java.util.List;
        import java.util.ResourceBundle;
        import java.util.stream.Collectors;

public class PretragaSimptomaController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba {

    List<Simptom> listaSvihSimptoma = new ArrayList<>();

    public static final Logger logger = LoggerFactory.getLogger(PretragaSimptomaController.class);

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Simptom> tablicaSimptoma;

    @FXML
    private TableColumn<Simptom, String> stupacNaziva;
    @FXML
    private TableColumn<Simptom, String> stupacVrijednosti;




    @FXML
    public void odiNatrag() throws IOException
    {


        Parent pretragaZupanijaFrame = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Covidportal");

        logger.info("Korisnik je zatvorio ekran o Simptomima");
    }



    @FXML
    public void pretrazi() throws IOException
    {
        tablicaSimptoma.setItems(FXCollections.observableList(listaSvihSimptoma));

        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaSimptoma.setItems(FXCollections.observableList(
                    listaSvihSimptoma.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Main.getMainStage().setTitle("Simptomi");
        logger.info("Korisnik je otvorio ekran o Simptomima");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Simptom, String>("naziv"));
        stupacVrijednosti.setCellValueFactory(new PropertyValueFactory<Simptom, String>("vrijednost"));

        listaSvihSimptoma = liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba.sviSimptomi;
        tablicaSimptoma.setItems(FXCollections.observableList(listaSvihSimptoma));

    }
}
