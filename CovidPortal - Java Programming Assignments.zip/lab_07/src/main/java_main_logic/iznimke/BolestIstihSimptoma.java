package main.java_main_logic.iznimke;

/**
 *Služi za kreiranje neoznačene iznimke u klasi Glavna.
 */
public class BolestIstihSimptoma extends RuntimeException
{
    public BolestIstihSimptoma(String message)
    {
        super(message);
    }

    public BolestIstihSimptoma(Throwable cause)
    {
        super(cause);
    }

    public BolestIstihSimptoma(String message, Throwable cause)
    {
        super(message, cause);
    }
}
