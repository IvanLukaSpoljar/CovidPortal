package hr.java.covidportal.model;

public class Simptom extends ImenovaniEntitet {
    private String vrijednost;

    //KOSNTRUKTOR
    public Simptom(String naziv, String vrijednost) {
        super(naziv);
        this.vrijednost = vrijednost;
    }


    //NAZIV
    public String getNaziv() {
        return super.getNaziv();
    }

    public void setNaziv(String naziv) {
        super.setNaziv(naziv);
    }

    //VRIJEDNOST
    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }
}
