package main.java_main_logic.kontroleri_ekrana.novi_zapis;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.Main;

import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.iznimke.Upozorenje;
import main.java_main_logic.model.Simptom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class DodavanjeNovogSimptomaController implements Initializable, ListeZupanijaSimptomaBolestiVirusaOsoba, PovijestKretanjaPoEkranima {

    public static final Logger logger = LoggerFactory.getLogger(DodavanjeNovogSimptomaController.class);
    public static String putanjaDoTrenutnogFXMLa = "layout/novi_zapis/dodavanjeNovogSimptoma.fxml";
    private String ucestalostKonacna = new String();


    @FXML
    private Button naprijedGumb = new Button();


    @FXML
    private TextField dohvatNaziva = new TextField();
    @FXML
    private CheckBox ucestalost1 = new CheckBox();
    @FXML
    private CheckBox ucestalost2 = new CheckBox();
    @FXML
    private CheckBox ucestalost3 = new CheckBox();

    @FXML
    public void prviOznacenCheckBox ()
    {
        if(ucestalost1.isSelected())
        {
            ucestalost2.setSelected(false);
            ucestalost3.setSelected(false);

            ucestalostKonacna = ucestalost1.getText();
        }
    }

    @FXML
    public void drugiOznacenCheckBox ()
    {
        if(ucestalost2.isSelected())
        {
            ucestalost1.setSelected(false);
            ucestalost3.setSelected(false);

            ucestalostKonacna = ucestalost2.getText();
        }
    }

    @FXML
    public void treciOznacenCheckBox ()
    {
        if(ucestalost3.isSelected())
        {
            ucestalost1.setSelected(false);
            ucestalost2.setSelected(false);

            ucestalostKonacna = ucestalost3.getText();
        }
    }



    @FXML
    public void spremiNoviSimptom() throws IOException
    {
        Long id = (long)1;
        if(sviSimptomi.size() > 0)
            id = sviSimptomi.get(sviSimptomi.size() - 1).getId() + 1;


        try{
            provjeriPopunjenost(dohvatNaziva, ucestalost1, ucestalost2, ucestalost3);

            String naziv = dohvatNaziva.getText();

            //AppendPodatakaSimptoma(id, naziv, ucestalostKonacna);
            BazaPodataka.spremiJedanSimptom(new Simptom(id, naziv, ucestalostKonacna));
            isprazniSvaPolja(dohvatNaziva, ucestalost1, ucestalost2, ucestalost3);

        }
        catch (Upozorenje | SQLException ex)
        {

            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setTitle("Nepopunjena polja ili previ�e odabranih ChecBoxova");
            upozorenje.setContentText(ex.getMessage());
            upozorenje.showAndWait();

            isprazniSvaPolja(dohvatNaziva, ucestalost1, ucestalost2, ucestalost3);
        }
    }

    private void provjeriPopunjenost(TextField prvi, CheckBox drugi, CheckBox treci, CheckBox cetvrti)
    {
        if((drugi.isSelected() == false && treci.isSelected() == false && cetvrti.isSelected() == false) || prvi.getText().isEmpty() == true)
            throw new Upozorenje("Popunite polja");
    }







    private void isprazniSvaPolja(TextField prvi, CheckBox drugi, CheckBox treci, CheckBox cetvrti)
    {
        prvi.setText("");
        drugi.setSelected(false);
        treci.setSelected(false);
        cetvrti.setSelected(false);
    }


    @FXML
    public void odiNatrag() throws IOException
    {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran dodavanja Simptoma");
    }
    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Dodavanje novog simptoma");
        logger.info("Korisnik je otvorio ekran dodavanja novog simptoma");

      dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
      vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);

   /*   ucestalost1.setText(sviSimptomi.get(0).getVrijednost());
      ucestalost2.setText(sviSimptomi.get(1).getVrijednost());
      ucestalost3.setText(sviSimptomi.get(2).getVrijednost());*/
    }
}
