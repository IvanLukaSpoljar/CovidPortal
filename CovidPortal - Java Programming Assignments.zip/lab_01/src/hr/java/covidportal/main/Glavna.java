package hr.java.covidportal.main;

import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Osoba;
import hr.java.covidportal.model.Simptom;
import hr.java.covidportal.model.Zupanija;

import java.math.BigDecimal;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Glavna {
    private static final Integer KONSTANTA = 3;

    //KONSTANTE ZA BROJ ELEMENATA U NIZOVIMA (UJEDNO I PETLJAMA)
    private static final Integer BROJ_SIMPTOMA = KONSTANTA;
    public static final Integer BROJ_BOLESTI = KONSTANTA;
    public static final Integer BROJ_OSOBA = KONSTANTA;


    public static void main(String[] args) {
        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA

        Simptom[] simptomi = new Simptom[BROJ_SIMPTOMA];
        Bolest[] bolesti = new Bolest[BROJ_BOLESTI];
        Osoba[] osobe = new Osoba[BROJ_OSOBA];

        Integer limitZupanija = 0;

        System.out.print("\nUnesite koliko Županija želite unjeti: ");
        limitZupanija = unos.nextInt();
        unos.nextLine(); // ČIŠĆENJE BUFFERA

        Integer BROJ_ZUPANIJA = limitZupanija;
        Zupanija[] zupanije = new Zupanija[BROJ_ZUPANIJA];


        //<-------------ZUPANIJE---------------->
        System.out.println("\nUnesite podatke o " + BROJ_ZUPANIJA + " županije: ");
        for (int i = 0; i < BROJ_ZUPANIJA; i++)
            zupanije[i] = unosZupanije(unos, i);

        /*System.out.println("\nISPIS IMENA I BROJA STANOVNIKA PO ŽUPANIJAMA");
        for(int i = 0; i < BROJ_ZUPANIJA; i++)
            System.out.println("    " + (i + 1) + ". Županija je: [" + zupanije[i].getNaziv() + "] --> Broj stanovnika je: " + zupanije[i].getBrojStanovnika());*/


        //<-------------SIMPTOMI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_SIMPTOMA + " simptoma: ");
        for (int i = 0; i < BROJ_SIMPTOMA; i++)
            simptomi[i] = unosSimptoma(unos, i);

        /*System.out.println("\nISPIS SIMPTOMA I VRIJEDNOSTI");
        for(int i = 0; i < BROJ_SIMPTOMA; i++)
            System.out.println("    " + (i + 1) + ". Simptom je: [" + simptomi[i].getNaziv() + "] --> Vrijendost je: " + simptomi[i].getVrijednost());*/


        //<-------------BOLESTI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_BOLESTI + " bolesti: ");
        for (int i = 0; i < BROJ_BOLESTI; i++)
            bolesti[i] = unosBolesti(unos, simptomi, i);

        /*System.out.println("\nISPIS BOLESTI I NJIHOVIH VRIJEDNOSTI");
        for(int i = 0; i < BROJ_BOLESTI; i++)
        {
            System.out.println("    " + (i + 1) + ". Bolest je: " + bolesti[i].getNaziv());
            for(int j = 0; j < bolesti[i].getSimptomi().length; j++)
                System.out.println("        -> Naziv simptoma je: " + bolesti[i].getSimptomi()[j].getNaziv() + "\n        -> Učestalost simptoma je: " + bolesti[i].getSimptomi()[j].getVrijednost() + "\n");
        }*/


        //<-------------OSOBE---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_OSOBA + " osobe: ");
        for (int i = 0; i < BROJ_OSOBA; i++)
            unosOsoba(unos, zupanije, bolesti, osobe, i, BROJ_ZUPANIJA);


        //<-------------ISPIS SVIH OSOBA I PODATAKA O NJIMA---------------->
        System.out.println("\n*********************POPIS OSOBA*********************\n");
        for (int i = 0; i < osobe.length; i++)
            ispisOsoba(osobe, i);


        //RAČUNANJE PROSJEKA STAROSTI OSOBA PO ŽUPANIJAMA
        System.out.println("\n*********************PROSIJEK STAROSTI OSOBA PO ŽUPANIJI*********************\n");
        for (int i = 0; i < zupanije.length; i++) // ŽUPANIJE
        {
            System.out.print("    " + (i + 1) + ". " + zupanije[i].getNaziv() + " županija ima prosjek starosti: ");
            int zbroj = 0;
            int brojOsoba = 0;

            for (int j = 0; j < osobe.length; j++)//OSOBE
            {
                if (zupanije[i].getNaziv().equals(osobe[j].getZupanija().getNaziv())) {
                    zbroj = zbroj + osobe[j].getStarost();
                    brojOsoba++;
                }
            }

            if (brojOsoba == 0) {
                System.out.println("Županija nema osoba");
            } else {
                BigDecimal prosjek = new BigDecimal(zbroj / brojOsoba);
                System.out.println(prosjek);
            }
        }


        //KRAJ CIJELE MAIN FUNKCIJE
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA
    private static void ispisOsoba(Osoba[] osobe, int i) {
        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe[i].getIme() + " " + osobe[i].getPrezime());
        System.out.println("    Starost: " + osobe[i].getStarost());
        System.out.println("    Županija prebivališta: " + osobe[i].getZupanija().getNaziv());
        System.out.println("    Zaražen bolešću: " + osobe[i].getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");

        //osobe[i] JE TRENUTNA OSOBA KOJA MOŽE SADRŽAVATI NIZ ZARŽENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe[i].getKontaktiraneOsobe()[0] != null) //PROVJERVA DA LI NULTI ELEMENT U NIZU ZARAŽENIH OSOBA UOPĆE POSTOJI
        {
            for (int j = 0; j < osobe[i].getKontaktiraneOsobe().length; j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe[i].getKontaktiraneOsobe()[j].getIme() + " " + osobe[i].getKontaktiraneOsobe()[j].getPrezime());
            }
        } else //AKO NIZ ZARAŽENIH OSOBA NE POSTOJI
        {
            System.out.print("Nema kontaktiranih osoba.");
        }
        System.out.println("\n");
    }


    //METODA ZA UNOS OSOBA
    private static void unosOsoba(Scanner unos, Zupanija[] zupanije, Bolest[] bolesti, Osoba[] osobe, int i, Integer BROJ_ZUPANIJA) {
        String imeOsobe;
        String prezimeOsobe;

        Integer starostOsobe = 0;
        Integer odabirZupanije = 0;
        Integer odabirBolesti = 0;


        System.out.println((i + 1) + ". Osoba:");

        //UNOS IMENA
        System.out.print("    Unesite ime osobe: ");
        imeOsobe = unos.nextLine();

        //UNOS PREZIMENA
        System.out.print("    Unesite prezime osobe: ");
        prezimeOsobe = unos.nextLine();

        //UNOS STAROSTI
        System.out.print("    Unesite starost osobe: ");
        starostOsobe = unos.nextInt();
        unos.nextLine(); //ČIŠĆENJE BUFFERA


        //UNOS PREBIVALIŠNE ŽUPANIJE OSOBE
        do {
            System.out.println("\n    Unesite županiju prebivališta osobe: ");

            for (int j = 0; j < zupanije.length; j++)
                System.out.println("    " + (j + 1) + ". " + zupanije[j].getNaziv());

            System.out.print("    Odabir: ");

            odabirZupanije = unos.nextInt();

            if (odabirZupanije < 1 || odabirZupanije > BROJ_ZUPANIJA)
                System.out.println("\n    Krivi unos, unesite ponovno!");
        }
        while (odabirZupanije < 1 || odabirZupanije > BROJ_ZUPANIJA);
        unos.nextLine(); //ČIŠĆENJE BUFFERA


        //UNOS BOLESTI OSOBE
        do {
            System.out.println("\n    Unesite bolest osobe: ");
            for (int j = 0; j < bolesti.length; j++)
                System.out.println("    " + (j + 1) + ". " + bolesti[j].getNaziv());
            System.out.print("    Odabir: ");
            odabirBolesti = unos.nextInt();

            if (odabirBolesti < 1 || odabirBolesti > BROJ_BOLESTI)
                System.out.println("\n    Krivi unos, unesite ponovno!");
            else
                System.out.println();
        }
        while (odabirBolesti < 1 || odabirBolesti > BROJ_BOLESTI);
        unos.nextLine(); //ČIŠĆENJE BUFFERA


        //KONTAKT SA ZARAŽENOM OSOBOM
        kontaktiranjeSaZarazenimOsobama(unos, zupanije, bolesti, osobe, i, imeOsobe, prezimeOsobe, starostOsobe, odabirZupanije, odabirBolesti);
    }


    //METODA ZA UNOŠENJE KONTAKATA SA ZARAŽENIM OSOBAMA
    private static void kontaktiranjeSaZarazenimOsobama(Scanner unos, Zupanija[] zupanije, Bolest[] bolesti, Osoba[] osobe, int i, String imeOsobe, String prezimeOsobe, Integer starostOsobe, Integer odabirZupanije, Integer odabirBolesti) {
        Integer brojKontaktiranihOsoba = 0;
        Integer broj = 0;

        Boolean ponovi = true;
        Boolean istinitostBrojaNule = true;


        //OD 2. OSOBE (INDEKS 1) PA NADALJE DOPUSTI UNOS BROJA OSOBA KOJE SU BILE U KONTAKTU S TOM OSOBOM
        if (i > 0) {
            do {
                System.out.print("\n    Unesite broj osoba koje su bile u kontaktu s tom osobom: ");
                brojKontaktiranihOsoba = unos.nextInt();

                if (brojKontaktiranihOsoba == 0)
                    istinitostBrojaNule = true;
                else
                    istinitostBrojaNule = false;

                if (brojKontaktiranihOsoba > i || brojKontaktiranihOsoba < 0) {
                    System.out.println("    Broj osoba koje su bile u kontaktu s tom osobom mora biti veći ili jednak " + 0 + " i manji od " + (i + 1));
                    ponovi = true;
                } else
                    ponovi = false;
            }
            while (ponovi);

            unos.nextLine();
            System.out.println();

        }


        //AKO SE IZVRŠIO PRETHODNI IF BLOK ONDA JE VARIJABLA ponovi = false
        //IAKO KORISNIK MOŽE ODABRATI 0 OSOBA, TAJ BROJ SE MORA PRETVORITI U 1 KAKO BI SE UOPĆE MOGAO INCIJALIZIRATI NIZ ZARAŽENIH OSOBA (OD JEDNOG NULL ELEMENTA)
        if (istinitostBrojaNule == true) {
            broj = brojKontaktiranihOsoba;
            brojKontaktiranihOsoba = 1;
        } else {
            broj = brojKontaktiranihOsoba;
        }


        //INICIJALIZACIJA NIZA U KOJEMU ĆE SE NALAZITI SVE OSOBE KOJE SU BILE U KONTAKTU SA TRENUTNOM OSOBOM
        Osoba[] kontaktiraneZarazeneOsobe = new Osoba[brojKontaktiranihOsoba];
        //TRENUTNA OSOBA IMA ARGUMENTE DEFINIRANE KONSTRUKTOROM
        osobe[i] = new Osoba(imeOsobe, prezimeOsobe, starostOsobe, zupanije[odabirZupanije - 1], bolesti[odabirBolesti - 1], kontaktiraneZarazeneOsobe);
        //VRAĆANJE ORGINALNE VRIJEDNOSTI BROJA KONTAKTIRANIH OSOBA
        brojKontaktiranihOsoba = broj;


        //OMOGUĆUJE UNOS PRETHODNIH ZARAŽENIH OSOBA, TIME ĆE SE STVORITI OBJEKTI U NIZU PRETHODNIH ZARAŽENIH OSOBA
        if (brojKontaktiranihOsoba > 0 && ponovi == false)
            umetanje_Popisa_Prijasnje_Zarazenih_Osoba_U_Niz(unos, zupanije, bolesti, osobe, i, brojKontaktiranihOsoba, kontaktiraneZarazeneOsobe);


        //DODAVANJE NIZA ZARAŽENIH OSOBA U TRENUTNU OSOBU, POSTOJI MOGUĆNOST DA NIZ ZARAŽENIH OSOBA BUDE NULL
        osobe[i].setKontaktiraneOsobe(kontaktiraneZarazeneOsobe);
    }


    private static void umetanje_Popisa_Prijasnje_Zarazenih_Osoba_U_Niz(Scanner unos, Zupanija[] zupanije, Bolest[] bolesti, Osoba[] osobe, int i, Integer brojKontaktiranihOsoba, Osoba[] kontaktiraneZarazeneOsobe) {
        Integer odabirKontaktiraneOsobe;

        Boolean ponovi;


        System.out.println("    Unesite osobe koje su bile u kontaktu s tom osobom:");
        for (int j = 0; j < brojKontaktiranihOsoba; j++) {
            do {
                System.out.println("    Odaberite " + (j + 1) + ". osobu:");
                for (int k = 0; k < i; k++) {
                    System.out.println("    " + (k + 1) + ". " + osobe[k].getIme() + " " + osobe[k].getPrezime());
                }
                System.out.print("    Odabir: ");
                odabirKontaktiraneOsobe = unos.nextInt();

                if (odabirKontaktiraneOsobe < 1 || odabirKontaktiraneOsobe > brojKontaktiranihOsoba) {
                    System.out.println("\n    Krivi unos, ponovite unos za " + (j + 1) + ". osobu!\n");
                    ponovi = true;
                } else {
                    ponovi = false;
                }
            }
            while (ponovi);

            kontaktiraneZarazeneOsobe[j] = new Osoba(osobe[odabirKontaktiraneOsobe - 1].getIme(), osobe[odabirKontaktiraneOsobe - 1].getPrezime(), osobe[odabirKontaktiraneOsobe - 1].getStarost(), zupanije[odabirKontaktiraneOsobe - 1], bolesti[odabirKontaktiraneOsobe - 1], null);
            System.out.println();
            unos.nextLine();
        }
    }


    //METODA ZA UNOS BOLESTI
    private static Bolest unosBolesti(Scanner unos, Simptom[] simptomi, int i) {
        Integer brojSimptoma;

        System.out.println((i + 1) + ". Bolest:");
        System.out.print("    Unesite naziv za bolest: ");
        String naziv = unos.nextLine();

        do {
            System.out.print("    Unesite broj simptoma: ");
            brojSimptoma = unos.nextInt();

            if (brojSimptoma < 1 || brojSimptoma > BROJ_SIMPTOMA)
                System.out.println("    Krivi unos, broj mora biti u intervalu od 1 do " + BROJ_SIMPTOMA);
        }
        while (brojSimptoma < 1 || brojSimptoma > BROJ_SIMPTOMA);
        unos.nextLine(); //ĆIŠČENJE BUFFERA


        Simptom[] kolikoSimptoma = new Simptom[brojSimptoma];
        Integer[] prijasnjiOdabir = new Integer[brojSimptoma];


        for (int j = 0; j < brojSimptoma; j++) {
            Integer odabirSimptoma;
            Boolean ponovi;

            do {
                Integer counter = 0;
                ponovi = false;

                System.out.println("\n    Odaberite " + (j + 1) + ". simptom: ");
                for (int k = 0; k < simptomi.length; k++)
                    System.out.println("    " + (k + 1) + ". " + simptomi[k].getNaziv() + " " + simptomi[k].getVrijednost());


                System.out.print("    Odabir: ");
                odabirSimptoma = unos.nextInt();
                unos.nextLine(); //ĆIŠČENJE BUFFERA
                prijasnjiOdabir[j] = odabirSimptoma;


                //PONAVLJAJU LI SE ODABRANI SIMPTOMI ZA ISTU BOLEST
                for (int k = 0; k < prijasnjiOdabir.length; k++) {
                    if (odabirSimptoma.equals(prijasnjiOdabir[k])) {
                        counter++;
                        if (counter == 2) {
                            ponovi = true;
                        }
                    }
                }


                if (ponovi) {
                    System.out.println("\n    Krivi unos, svi simptomi bolesti moraju biti međusobno različiti!");
                } else if (odabirSimptoma < 1 || odabirSimptoma > BROJ_SIMPTOMA) {
                    System.out.println("\n    Neispravan unos, molimo pokušajte ponovno!");
                    ponovi = true;
                } else {
                    kolikoSimptoma[j] = simptomi[odabirSimptoma - 1];
                    ponovi = false;
                }
            }
            while (ponovi);
        }

        //DODAVANJE VRIJEDNOSTI OBJEKTU TIPA BOLEST
        Bolest element = new Bolest(naziv, kolikoSimptoma);

        System.out.println();
        return element;
    }


    //METODA ZA UNOS SIMPTOMA
    private static Simptom unosSimptoma(Scanner unos, int i) {
        String naziv;
        String vrijednost;
        Boolean ponovi;

        System.out.println((i + 1) + ". Simptom:");
        System.out.print("    Unesite naziv simptoma: ");
        naziv = unos.nextLine();

        do {
            System.out.print("    Unesite vrijednost simptoma (RIJETKO, SREDNJE ILI ČESTO): ");
            vrijednost = unos.nextLine();

            ponovi = true;

            if (vrijednost.equals("RIJETKO") || vrijednost.equals("SREDNJE") || vrijednost.equals("ČESTO"))
                ponovi = false;
            else
                System.out.println("\n    Krivi unos, točno unesite navedene vrijednosti: RIJETKO, SREDNJE ili ČESTO");
        }
        while (ponovi);


        Simptom simptom = new Simptom(naziv, vrijednost);

        System.out.println();
        return simptom;
    }


    //METODA ZA UNOS ŽUPANIJA
    private static Zupanija unosZupanije(Scanner unos, int i) {
        String nazivZupanije;
        Integer brojStanovnika;
        String sifraZupanije;
        Boolean ponovi = true;

        System.out.print((i + 1) + ". Županija:");

        //NAZIV ŽUPANIJE
        System.out.print("\n    Unesite naziv županije: ");
        nazivZupanije = unos.nextLine();

        //ŠIFRA ŽUPANIJE
        System.out.print("    Unesite šifru županije: ");
        do {
            sifraZupanije = unos.nextLine();

            String regex = "^[0-9]{3}$";
            Pattern pattern = Pattern.compile(regex);

            Matcher matcher = pattern.matcher(sifraZupanije);
            if (matcher.matches() == true) {
                ponovi = false;
            } else {
                ponovi = true;
                System.out.print("    Ponovno unesite šifru županije: ");
            }
        } while (ponovi);


        //BROJ STANOVNIKA
        System.out.print("    Unesite broj stanovnika: ");
        brojStanovnika = unos.nextInt();
        unos.nextLine(); //ČIŠĆENJE BUFFERA

        Zupanija zupanija = new Zupanija(nazivZupanije, brojStanovnika, sifraZupanije);

        System.out.println();
        return zupanija;
    }


    //KRAJ CIJELE KLASE: GLAVNA
}
