package hr.java.covidportal.genericsi;

import hr.java.covidportal.model.Simptom;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class nova<T extends Simptom> {
    private List<T> simptomi = new ArrayList<>();

    public nova(List<T> a) {
        simptomi = a.stream()
                .filter(s -> s instanceof Simptom)
                .collect(Collectors.toList());
    }


    public List<T> get() {
        return simptomi;
    }

    public void add(List<T> simptomi) {
        this.simptomi = simptomi;
    }

    @Override
    public String toString() {
        String poruka = new String();
        for (int i = 0; i < simptomi.size(); i++) {
            if (i == simptomi.size() || i == simptomi.size() - 1)
                poruka = poruka + simptomi.get(i).getNaziv();
            else
                poruka = poruka + simptomi.get(i).getNaziv() + " ";
        }
        return poruka;
    }
}
