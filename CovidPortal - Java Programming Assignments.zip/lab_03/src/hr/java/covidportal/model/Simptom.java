package hr.java.covidportal.model;
/**
 * Služi za kreiranje objekta simptom u klasi Glavna.
 */
public class Simptom extends ImenovaniEntitet {
    private String vrijednost;

    //KOSNTRUKTOR

    /**
     * Prima naziv i vrijednost
     * @param naziv naziv simptoma
     * @param vrijednost učestalost simptoma
     */
    public Simptom(String naziv, String vrijednost) {
        super(naziv);
        this.vrijednost = vrijednost;
    }


    //NAZIV
    public String getNaziv() {
        return super.getNaziv();
    }

    public void setNaziv(String naziv) {
        super.setNaziv(naziv);
    }

    //VRIJEDNOST
    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }
}
