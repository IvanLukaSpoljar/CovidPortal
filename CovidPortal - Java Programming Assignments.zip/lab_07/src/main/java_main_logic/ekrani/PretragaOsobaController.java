package main.java_main_logic.ekrani;

import main.java_main_logic.model.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaOsobaController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba {

    List<Osoba> listaSvihOsoba = new ArrayList<>();

    public static final  Logger logger = LoggerFactory.getLogger(PretragaOsobaController.class);

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;


    @FXML
    private TableView<Osoba> tablicaOsoba;
    @FXML
    private TableColumn<Osoba, String> stupacImena;
    @FXML
    private TableColumn<Osoba, String> stupacPrezimena;
    @FXML
    private TableColumn<Osoba, Integer> stupacStarosti;
    @FXML
    private TableColumn<Osoba, Zupanija> stupacZupanije;
    @FXML
    private TableColumn<Osoba, Bolest> stupacBolesti;
    @FXML
    private TableColumn<Osoba, List<Osoba>> stupacKontaktiranih;




    @FXML
    public void odiNatrag() throws IOException
    {
        Parent pretragaZupanijaFrame = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Covidportal");

        logger.info("Korisnik je zatvorio ekran o Osobama");
    }

    @FXML
    public void pretrazi() throws IOException
    {
        tablicaOsoba.setItems(FXCollections.observableList(listaSvihOsoba));

        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaOsoba.setItems(FXCollections.observableList(
                    listaSvihOsoba.stream()
                            .filter(z -> z.getIme().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Main.getMainStage().setTitle("Osobe");
        logger.info("Korisnik je otvorio ekran o Osobama");

        stupacImena.setCellValueFactory(new PropertyValueFactory<Osoba, String>("ime"));
        stupacPrezimena.setCellValueFactory(new PropertyValueFactory<Osoba, String >("prezime"));
        stupacStarosti.setCellValueFactory(new PropertyValueFactory<Osoba, Integer>("starost"));
        stupacZupanije.setCellValueFactory(new PropertyValueFactory<Osoba, Zupanija>("zupanija"));
        stupacBolesti.setCellValueFactory(new PropertyValueFactory<Osoba, Bolest>("zarazenBolescu"));
        stupacKontaktiranih.setCellValueFactory(new PropertyValueFactory<Osoba, List<Osoba>>("kontaktiraneOsobe"));


        listaSvihOsoba = liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba.sveOsobe;
        tablicaOsoba.setItems(FXCollections.observableList(listaSvihOsoba));
    }
}
