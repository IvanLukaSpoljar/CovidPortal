package hr.java.covidportal.model;

import java.util.Set;

/**
 * Slu�i za kreiranje objekta bolest u klasi Glavna.
 */
public class Bolest extends ImenovaniEntitet {
    private Set<Simptom> simptomi;
    private String opis;

    //KONSTRUKTOR

    /**
     * Prima naziv i niz objekata simptoma kao parametre
     *
     * @param naziv ime bolesti
     * @param simptomi simptomi bolesti
     */
    public Bolest(String naziv, Set<Simptom> simptomi, String opis) {
        super(naziv);
        this.simptomi = simptomi;
        this.opis = opis;
    }

    public Bolest(){}

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }
//NAZIV - GETTER I SETTER SE NALAZI U IMENOVANOM ENTITETU

    //SIMPTOMI
    public Set<Simptom> getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(Set<Simptom> simptomi) {
        this.simptomi = simptomi;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bolest bolest = (Bolest) o;

        return simptomi != null ? simptomi.equals(bolest.simptomi) : bolest.simptomi == null;
    }

    @Override
    public int hashCode() {
        return simptomi != null ? simptomi.hashCode() : 0;
    }

    @Override
    public String toString()
    {
        return "Naziv bolesti: " + getNaziv() + " Opis bolesti: " + getOpis();
    }
}
