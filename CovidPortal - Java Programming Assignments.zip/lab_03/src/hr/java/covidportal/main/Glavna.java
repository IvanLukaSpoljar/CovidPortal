package hr.java.covidportal.main;

import hr.java.covidportal.iznimke.*;
import hr.java.covidportal.model.*;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Slu�i za testiranje logginga tijekom izvo�enja programa.
 *
 */
public class Glavna {
    public static final Logger logger = LoggerFactory.getLogger(Glavna.class);
    private static final Integer KONSTANTA = 3;

    //KONSTANTE ZA BROJ ELEMENATA U NIZOVIMA (UJEDNO I PETLJAMA)
    private static final Integer BROJ_ZUPANIJA = KONSTANTA;
    private static final Integer BROJ_SIMPTOMA = KONSTANTA;
    public static final Integer BROJ_BOLESTI = 4;
    public static final Integer BROJ_OSOBA = KONSTANTA;

    /**
     * Slu�i za pokretanje programa koji �e od korisnika tra�iti da svojim unosom definira vrijednosti pojedinih
     * varijabli, te nakon toga da unese zara�ene osobe kod kojih �e se vidjeti jesu li u me�uvremenu zara�eni
     * nekom drugom bole��u i s kime su sve kontaktirali.
     *
     * @param args argumenti komandne linije
     */
    public static void main(String[] args) {

        logger.info("PO�ETAK PROGRAMA");

        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        Zupanija[] zupanije = new Zupanija[BROJ_ZUPANIJA];
        Simptom[] simptomi = new Simptom[BROJ_SIMPTOMA];
        Bolest[] bolesti = new Bolest[BROJ_BOLESTI];
        Osoba[] osobe = new Osoba[BROJ_OSOBA];

        //POMO�NE VARIJABLE
        Integer[] suma_Odabira_Simptoma_Za_Svaku_Bolest = new Integer[BROJ_BOLESTI];
        Arrays.fill(suma_Odabira_Simptoma_Za_Svaku_Bolest, 0);


        //<-------------�UPANIJE---------------->
        System.out.println("\nUnesite podatke o " + BROJ_ZUPANIJA + " �upanije: ");
        for (int i = 0; i < BROJ_ZUPANIJA; i++)
            zupanije[i] = unosZupanije(unos, i);

        /*System.out.println("\nISPIS IMENA I BROJA STANOVNIKA PO �UPANIJAMA");
        for(int i = 0; i < BROJ_ZUPANIJA; i++)
            System.out.println("    " + (i + 1) + ". �upanija je: [" + zupanije[i].getNaziv() + "] --> Broj stanovnika je: " + zupanije[i].getBrojStanovnika());*/


        //<-------------SIMPTOMI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_SIMPTOMA + " simptoma: ");
        for (int i = 0; i < BROJ_SIMPTOMA; i++)
            simptomi[i] = unosSimptoma(unos, i);

        /*System.out.println("\nISPIS SIMPTOMA I VRIJEDNOSTI");
        for(int i = 0; i < BROJ_SIMPTOMA; i++)
            System.out.println("    " + (i + 1) + ". Simptom je: [" + simptomi[i].getNaziv() + "] --> Vrijendost je: " + simptomi[i].getVrijednost());*/


        //<-------------BOLESTI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_BOLESTI + " bolesti ili virusa: ");
        for (int i = 0; i < BROJ_BOLESTI; i++)
            bolesti[i] = unosBolesti(unos, simptomi, i, suma_Odabira_Simptoma_Za_Svaku_Bolest);

        /*System.out.println("\nISPIS BOLESTI I NJIHOVIH VRIJEDNOSTI");
        for(int i = 0; i < BROJ_BOLESTI; i++)
        {
            if(bolesti[i] instanceof Virus )
            {
                System.out.println("    " + (i + 1) + ". Virus je: " + bolesti[i].getNaziv());
                for(int j = 0; j < bolesti[i].getSimptomi().length; j++)
                    System.out.println("        -> Naziv simptoma je: " + bolesti[i].getSimptomi()[j].getNaziv() + "\n        -> U�estalost simptoma je: " + bolesti[i].getSimptomi()[j].getVrijednost() + "\n");
            }
            else
            {
                System.out.println("    " + (i + 1) + ". Bolest je: " + bolesti[i].getNaziv());
                for(int j = 0; j < bolesti[i].getSimptomi().length; j++)
                    System.out.println("        -> Naziv simptoma je: " + bolesti[i].getSimptomi()[j].getNaziv() + "\n        -> U�estalost simptoma je: " + bolesti[i].getSimptomi()[j].getVrijednost() + "\n");
            }
        }*/


        //<-------------OSOBE---------------->
        //2. Zadatak
        System.out.println("\n\nUnesite podatke o " + BROJ_OSOBA + " osobe: ");
        for (int i = 0; i < BROJ_OSOBA; i++)
        {

            Boolean ponovi = true;
            do {
                try {
                    osobe[i] = unosOsoba(unos, zupanije, bolesti, osobe, i);
                    if(i > 0)
                        provjeraImenaIPrezimenaOsobe(osobe, osobe[i], i + 1);

                    ponovi = false;
                } catch (DuplaOsobaException ex2) {
                    logger.error(ex2.getMessage());
                    ponovi = true;
                }
            }while(ponovi == true);

        }

        //<-------------ISPIS SVIH OSOBA I PODATAKA O NJIMA---------------->
        System.out.println("\n*************************** POPIS OSOBA ***************************\n");
        for (int i = 0; i < osobe.length; i++)
            ispisOsoba(osobe, i);

        logger.info("ZAVR�ETAK PROGRAMA");
        //KRAJ CIJELE MAIN FUNKCIJE
    }


    /**
     * Provjrava ponavljanje iste osobe
     *
     * @param osobe niz osoba
     * @param trenutnaOsoba trenutna osoba
     * @param duljina duljina niz osoba
     */

    private static void provjeraImenaIPrezimenaOsobe (Osoba[] osobe, Osoba trenutnaOsoba, Integer duljina)
    {
        String ime = trenutnaOsoba.getIme();
        String prezime = trenutnaOsoba.getPrezime();
        Integer counter = 0;

        for(int i = 0; i < duljina; i++)
        {
            String tmpIme = osobe[i].getIme();
            String tmpPrezime = osobe[i].getPrezime();

            if(tmpIme.equals(ime)  == true && tmpPrezime.equals(prezime) == true)
            {
                counter++;
            }
        }

        if(counter > 1)
            throw new DuplaOsobaException("Unjeli ste istu osobu, unesite opet.");
    }



    //METODA ZA UNOS �UPANIJA
    /**
     * Tra�i od korisnika da unese naziv �upanije, te zatim broj stanovnika te �upanije.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i broji �upanije
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unosZupanije(Scanner unos, int i) {
        String nazivZupanije;
        Integer brojStanovnika = 0;
        Boolean flagIznimka = false;

        System.out.print((i + 1) + ". �upanija:");
        System.out.print("\n    Unesite naziv �upanije: ");
        nazivZupanije = unos.nextLine();


        //PROVJERA IZNIMKE ZA UNOS BROJA
        do {
            System.out.print("    Unesite broj stanovnika: ");
            try {
                brojStanovnika = unos.nextInt();
                provjera_Negativnosti_Broja_Stanovnika(brojStanovnika);

                logger.info("Broj je ispravno une�en, broj stanovnika je: " + brojStanovnika);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        Zupanija zupanija = new Zupanija(nazivZupanije, brojStanovnika);

        System.out.println();
        return zupanija;
    }


    /**
     * Provjerava da li je broj stanovnika negativan broj.
     *
     * @param brojStanovnika broj stanovnika �upanije
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjera_Negativnosti_Broja_Stanovnika(Integer brojStanovnika) {
        if (brojStanovnika < 0)
            throw new OgranicenjeBroja("Pogre�ka, broj mora biti jednak ili ve�i od 0, molimo ponovite unos!");
    }


    //METODA ZA UNOS SIMPTOMA
    /**
     * Tra�i od korisnika da unese naziv simptoma, te zatim u�estalost tog simptoma.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param i broji simptome
     * @return vra�a simptom kao objekt
     */
    private static Simptom unosSimptoma(Scanner unos, int i) {
        String naziv;
        String vrijednost;
        Boolean ponovi;

        System.out.println((i + 1) + ". Simptom:");
        System.out.print("    Unesite naziv simptoma: ");
        naziv = unos.nextLine();

        do {
            System.out.print("    Unesite vrijednost simptoma (RIJETKO, SREDNJE ILI �ESTO): ");
            vrijednost = unos.nextLine();

            ponovi = true;

            if (vrijednost.equals("RIJETKO") || vrijednost.equals("SREDNJE") || vrijednost.equals("�ESTO"))
                ponovi = false;
            else
                System.out.println("\n    Krivi unos, to�no unesite navedene vrijednosti: RIJETKO, SREDNJE ili �ESTO");
        }
        while (ponovi);
        Simptom simptom = new Simptom(naziv, vrijednost);

        System.out.println();
        return simptom;
    }


    //METODA ZA UNOS BOLESTI
    /**
     * Tra�i od korisnika da odabere vrstu bolesti, zatim njen naziv, broj simptoma te bolesti i da dodjeli
     * simptome bolesti.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param simptomi objekt koji se proslije�uje, slu�i za dodjeljivanje odre�enog simptoma bolesti
     * @param i broji bolesti
     * @param suma_Odabira_Simptoma_Za_Svaku_Bolest suma odabira simptoma za svaku bolest
     * @return vra�a bolest kao objekt
     */
    private static Bolest unosBolesti(Scanner unos, Simptom[] simptomi, int i, Integer[] suma_Odabira_Simptoma_Za_Svaku_Bolest) {
        String nazivBolesti;

        Integer zbrojOdabiraSimptoma = 0;
        Integer brojSimptoma = 0;
        Integer odabirVrsteBolesti = 0;
        Integer brojacIstihSimptomaUBolesti = 0;
        Integer odabirSimptoma = 0;

        Boolean odabranVirus = false;
        Boolean odabranaBolest = false;
        Boolean flagIznimka = false;
        Boolean ponoviOdNazivaBolesti = false;
        Boolean ponovi = false;

        Simptom[] simptomiBolesti = new Simptom[0];

        //UNOS BOLESTI ILI VIRUSA
        System.out.println((i + 1) + ". Vrsta zaraze:");
        System.out.println("    Unosite ili bolest ili virus?");
        System.out.println("    1) Bolest");
        System.out.println("    2) Virus");

        do {
            try {
                System.out.print("    Odaberite vrstu bolesti: ");
                odabirVrsteBolesti = unos.nextInt();
                provjeri_Valjanost_Odabira_Vrste_Bolesti(odabirVrsteBolesti);

                if (odabirVrsteBolesti == 1)
                    odabranaBolest = true;
                else if (odabirVrsteBolesti == 2)
                    odabranVirus = true;

                logger.info("Broj je ispravno une�en, vrsta bolesti je pod brojem: " + odabirVrsteBolesti);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        do {
            ponoviOdNazivaBolesti = false;

            //UNOS NAZIVA BOLESTI ILI VIRUSA
            System.out.print("\n    Unesite nazivBolesti bolesti ili virusa: ");
            nazivBolesti = unos.nextLine();

            //PROVJERA IZNIMKE ZA UNOS BROJA
            do {
                try {
                    System.out.print("    Unesite broj simptoma: ");
                    brojSimptoma = unos.nextInt();
                    provjeri_Valjanost_Broja_Simptoma_Za_Bolest(brojSimptoma);

                    logger.info("Broj je ispravno une�en, ukupni broj simptoma za trenutnu bolest je: " + brojSimptoma);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

            simptomiBolesti = Arrays.copyOf(simptomiBolesti, brojSimptoma);

            Integer[] provjera_Duplih_Simptoma_U_Bolesti = new Integer[brojSimptoma];
            Arrays.fill(provjera_Duplih_Simptoma_U_Bolesti, 0);

            zbrojOdabiraSimptoma = 0;
            for (int j = 0; j < brojSimptoma; j++) {
                //ODABERI SIMPTOM POMO�U BROJA
                do {
                    System.out.println("\n    Odaberite " + (j + 1) + ". simptom: ");
                    for (int k = 0; k < simptomi.length; k++)
                        System.out.println("    " + (k + 1) + ". " + simptomi[k].getNaziv() + " " + simptomi[k].getVrijednost());

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    do {
                        try {
                            System.out.print("    Odabir simptoma: ");
                            odabirSimptoma = unos.nextInt();
                            provjera_Odabira_Simptoma_Za_Trenutnu_Bolest(odabirSimptoma);

                            logger.info("Broj je ispravno une�en, simptom je pod brojem: " + odabirSimptoma);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (OgranicenjeBroja iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);

                    //PONAVLJA LI SE ISTI SIMPTOM ZA ISTU BOLEST, NEMOGU�E JE DA BOLEST IMA 2 ILI VI�E ISTA SIMPTOMA
                    provjera_Duplih_Simptoma_U_Bolesti[j] = odabirSimptoma;
                    brojacIstihSimptomaUBolesti = 0;
                    for (int k = 0; k < provjera_Duplih_Simptoma_U_Bolesti.length; k++) {
                        if (odabirSimptoma.equals(provjera_Duplih_Simptoma_U_Bolesti[k])) {
                            brojacIstihSimptomaUBolesti++;
                            if (brojacIstihSimptomaUBolesti == 2) {
                                ponovi = true;
                            }
                        }
                    }

                    //UKOLIKO DO�E DO ISTIH SIMPTOMA UNUTAR ISTE BOLESTI
                    if (ponovi == true)
                        System.out.println("\n    Svi simptomi trenutne zaraze moraju biti me�usobno razli�iti, simptom " + simptomi[odabirSimptoma - 1].getNaziv() + " je ve� odabran.\n    Molimo odaberite novi simptom.");
                }
                while (ponovi == true);

                zbrojOdabiraSimptoma = zbrojOdabiraSimptoma + odabirSimptoma;
                simptomiBolesti[j] = simptomi[odabirSimptoma - 1];
            }
            suma_Odabira_Simptoma_Za_Svaku_Bolest[i] = zbrojOdabiraSimptoma;

            //PROVJERAVA JEL POSTOJE BOLESTI SA ISTIM SIMPTOMIMA
            try {
                //USPORE�UJE SE SUMA ODABIRA SIMPTOMA TRENUTNE BOLESTI SA SUMOM ODABIRA SIMPTOMA ZA SVAKU BOLEST DO SADA UNE�ENU
                provjeriBolestiIstihSimptoma(suma_Odabira_Simptoma_Za_Svaku_Bolest[i], suma_Odabira_Simptoma_Za_Svaku_Bolest);
                ponoviOdNazivaBolesti = false;

            } catch (BolestIstihSimptoma iznimkaIstihSimptoma) {
                System.out.println("    " + iznimkaIstihSimptoma.getMessage() + "\n");
                logger.error(iznimkaIstihSimptoma.getMessage(), iznimkaIstihSimptoma);
                ponoviOdNazivaBolesti = true;
            }

        } while (ponoviOdNazivaBolesti == true);


        //BOLEST ILI VIRUS ?
        Bolest element = null;
        if (odabranaBolest)
            element = new Bolest(nazivBolesti, simptomiBolesti);
        else if (odabranVirus)
            element = new Virus(nazivBolesti, simptomiBolesti);

        System.out.println();
        return element;
    }


    /**
     * Provjerava je li korisnik odabrao ispravan simptom.
     *
     * @param odabirSimptoma broj pod kojim se simptom nalazi
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjera_Odabira_Simptoma_Za_Trenutnu_Bolest(Integer odabirSimptoma) {
        if (odabirSimptoma < 1 || odabirSimptoma > BROJ_SIMPTOMA)
            throw new OgranicenjeBroja("Krivi unos, broj mora biti u intervalu od 1 do " + BROJ_SIMPTOMA + ".");
    }

    /**
     * Provjerava je li korisnik odabrao ispravan ukupan broj simptoma za bolest.
     *
     * @param brojSimptoma koliko bolest ima simptoma
     */
    private static void provjeri_Valjanost_Broja_Simptoma_Za_Bolest(Integer brojSimptoma) {
        if (brojSimptoma < 1 || brojSimptoma > BROJ_SIMPTOMA)
            throw new OgranicenjeBroja("Krivi unos, broj mora biti u intervalu od 1 do " + BROJ_SIMPTOMA);
    }

    /**
     * Provjerava koju vrstu bolesti je korisnik odabrao.
     *
     * @param odabirVrsteBolesti broj pod kojim se vrsta bolesti nalazi
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Vrste_Bolesti(Integer odabirVrsteBolesti) {
        if (odabirVrsteBolesti < 1 || odabirVrsteBolesti > 2)
            throw new OgranicenjeBroja("Krivi odabir vrste bolesti, molimo odaberite broj 1 ili 2");
    }


    //METODA ZA UNOS OSOBA
    /**
     * Tra�i unos osobe, odnosno njezinh podataka.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param zupanije niz svih �upanija koje korisnik na po�etku programa unio
     * @param bolesti niz svih bolesti koje je korisnik unio tijekom programa
     * @param osobe niz osoba koji �e pohraniti ovu osobu
     * @param i broji osobe
     * @return vra�a osobu kao objekt
     */
    private static Osoba unosOsoba(Scanner unos, Zupanija[] zupanije, Bolest[] bolesti, Osoba[] osobe, int i) {
        String imeOsobe = "";
        String prezimeOsobe;
        Integer starostOsobe = 0;
        Boolean flagIznimka = true;


        System.out.println((i + 1) + ". Osoba:");
        //UNOS IMENA OSOBE
        // 1.ZADATAK
        Boolean opet = true;
        do {
            try {
                System.out.print("    Unesite ime osobe: ");
                imeOsobe = unos.nextLine();
                provjeriImeOsobe(imeOsobe);
                opet = false;
            } catch (NeispravanoImeException ex1) {
                logger.error(ex1.getMessage());
                opet = true;
            }
        }while(opet);



        //UNOS PREZIMENA OSOBE
        System.out.print("    Unesite prezime osobe: ");
        prezimeOsobe = unos.nextLine();
        //UNOS BROJA GODINA OSOBE I PROVJERA IZNIMKE
        do {
            try {
                System.out.print("    Unesite starost osobe: ");
                starostOsobe = unos.nextInt();
                provjeri_Broj_Godina_Osobe(starostOsobe);

                logger.info("Broj je ispravno une�en, starost osobe je: " + starostOsobe);

                flagIznimka = false;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (InputMismatchException iznimkaBroj) {
                iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                System.out.println("\n    " + iznimkaBroj.getMessage());
                logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            } catch (OgranicenjeBroja iznimkaOgranicenja) {
                System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                flagIznimka = true;
                unos.nextLine(); //�I��ENJE BUFFERA
            }
        } while (flagIznimka == true);


        //FINALNO INICIJALIZIRANJE TRENUTNE OSOBE SA SVIM PARAMETRIMA
        return new Osoba.Builder(imeOsobe)
                .surname(prezimeOsobe)
                .age(starostOsobe)
                .county(unos_Zupanije_Osobe(unos, zupanije)) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                .personInfection(unos_Bolesti_Osobe(unos, bolesti)) //UNOS BOLESTI OSOBE
                .contactedPersons(kontaktiranje_Sa_Zarazenim_Osobama(unos, osobe, i)) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                .makeItDone();
    }

    /**
     * Provjerava broj godina osobe.
     *
     * @param starostOsobe broj godina
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Broj_Godina_Osobe(Integer starostOsobe) {
        if (starostOsobe < 1)
            throw new OgranicenjeBroja("Pogre�ka, broj mora biti ve�i od 0, molimo ponovite unos!");
    }


    //PROVJERA IMENA OSOBE
    /**
     * Provjerava duljinu imena osobe
     *
     * @param ime ime osobe
     */
    private static void provjeriImeOsobe(String ime) {
        String regex = "^.{1,20}$";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(ime);
        if (matcher.matches() == false) // <-- matcher.matches() vre�a ture ili false
            throw new NeispravanoImeException("Ponovno unesite ime osobe.");
    }


    //METODA ZA UNOS PREBIVALI�NE �UPANIJE SVAKE OSOBE
    /**
     * Dodjeljivanje �upanije osobi.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param zupanije niz �upanija
     * @return vra�a �upaniju kao objekt
     */
    private static Zupanija unos_Zupanije_Osobe(Scanner unos, Zupanija[] zupanije) {
        Integer odabirZupanije = 0;

            System.out.println("\n    Unesite �upaniju prebivali�ta osobe: ");
            for (int j = 0; j < zupanije.length; j++)
                System.out.println("    " + (j + 1) + ". " + zupanije[j].getNaziv());

            //PROVJERA IZNIMKE ZA UNOS BROJA
            Boolean flagIznimka = true;
            do {
                try {
                    System.out.print("    Odabir: ");
                    odabirZupanije = unos.nextInt();
                    provjeri_Odabir_Zupanije_Kod_Osobe(odabirZupanije);

                    logger.info("Broj je ispravno une�en, broj odabrane �upanije je: " + odabirZupanije);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

        return zupanije[odabirZupanije - 1];
    }

    /**
     * Provjerava valjanost odabira �upanije kod osobe.
     *
     * @param odabirZupanije broj pod kojim se nalazi �upanija
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Odabir_Zupanije_Kod_Osobe(Integer odabirZupanije) {
        if (odabirZupanije < 1 || odabirZupanije > BROJ_ZUPANIJA)
            throw new OgranicenjeBroja("Krivi unos, odabrite �upaniju osobe koja se nalazi na popisu (interval od 1 do " + BROJ_ZUPANIJA + ").");
    }


    //METODA ZA UNO�ENJE BOLESTI SVAKE OSOBE
    /**
     * Dodjeljivanje bolesti osobi.
     *
     * @param unos varijabla za unos preko tipkovnice
     * @param bolesti niz bolesti
     * @return vra�a bolest kao objekt (ime, niz simptoma)
     */
    private static Bolest unos_Bolesti_Osobe(Scanner unos, Bolest[] bolesti) {
        Integer odabirBolesti = 0;

            System.out.println("\n    Unesite bolest ili virus osobe: ");
            for (int j = 0; j < bolesti.length; j++)
                System.out.println("    " + (j + 1) + ". " + bolesti[j].getNaziv());

            //PROVJERA IZNIMKE ZA UNOS BROJA
            Boolean flagIznimka = true;
            do {
                try {
                    System.out.print("    Odabir: ");
                    odabirBolesti = unos.nextInt();
                    provjeri_Odabir_Bolesti_Kod_Osobe(odabirBolesti);

                    logger.info("Broj je ispravno une�en, odabrana bolest je pod brojem: " + odabirBolesti);

                    flagIznimka = false;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (InputMismatchException iznimkaBroj) {
                    iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                    System.out.println("\n    " + iznimkaBroj.getMessage());
                    logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                } catch (OgranicenjeBroja iznimkaOgranicenja) {
                    System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                    logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                    flagIznimka = true;
                    unos.nextLine(); //�I��ENJE BUFFERA
                }
            } while (flagIznimka == true);

        return bolesti[odabirBolesti - 1];
    }


    /**
     * Provjerava valjanost odabira bolesti kod osobe.
     *
     * @param odabirBolesti broj pod kojim se nalazi bolest
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Odabir_Bolesti_Kod_Osobe(Integer odabirBolesti) {
        if (odabirBolesti < 1 || odabirBolesti > BROJ_BOLESTI)
            throw new OgranicenjeBroja("Krivi unos, odabrite bolest ili virus koji se nalazi na popisu (interval od 1 do " + BROJ_BOLESTI + ").");
        else
            System.out.println();
    }


    //METODA ZA UNO�ENJE KONTAKATA SA ZARA�ENIM OSOBAMA
    /**
     * Provjerava s kime je trenutna osoba bila u kontaktu.
     *
     * @param unos  varijabla za unos preko tipkovnice
     * @param osobe niz osoba
     * @param i broja� osoba
     * @return vra�a niz kontaktiranih osoba
     */
    private static Osoba[] kontaktiranje_Sa_Zarazenim_Osobama(Scanner unos, Osoba[] osobe, int i) {
        Integer brojKontaktiranihOsoba = 0;
        Boolean ponovi = true;

        //OD 2. OSOBE (INDEKS 1) PA NADALJE DOPUSTI UNOS BROJA OSOBA KOJE SU BILE U KONTAKTU S TOM OSOBOM
        if (i > 0) {
            do {
                //PROVJERA IZNIMKE ZA UNOS BROJA
                Boolean flagIznimka = true;
                do {
                    try {
                        System.out.print("    Unesite broj osoba koje su bile u kontaktu s tom osobom: ");
                        brojKontaktiranihOsoba = unos.nextInt();
                        provjeri_Valjanost_Broja_Kontaktiranih_Osoba(i, brojKontaktiranihOsoba);

                        logger.info("Broj je ispravno une�en, ukupan broj kontaktiranih osoba je: " + brojKontaktiranihOsoba);

                        flagIznimka = false;
                        ponovi = false;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (InputMismatchException iznimkaBroj) {
                        iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                        System.out.println("\n    " + iznimkaBroj.getMessage());
                        logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    } catch (OgranicenjeBroja iznimkaOgranicenja) {
                        System.out.println("\n    " + iznimkaOgranicenja.getMessage());
                        logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                        flagIznimka = true;
                        ponovi = true;
                        unos.nextLine(); //�I��ENJE BUFFERA
                    }
                } while (flagIznimka == true);
            }
            while (ponovi);
            System.out.println();
        }

        //OMOGU�UJE UNOS PRETHODNIH ZARA�ENIH OSOBA, TIME �E SE STVORITI OBJEKTI U NIZU PRETHODNIH ZARA�ENIH OSOBA
        if (brojKontaktiranihOsoba > 0) {
            Osoba[] kontaktiraneZarazeneOsobe = new Osoba[brojKontaktiranihOsoba];
            Integer odabirKontaktiraneOsobe = 0;
            Integer[] nizOdabranihOsoba = new Integer[1];

            System.out.println("    Unesite osobe koje su bile u kontaktu s tom osobom:");
            for (int j = 0; j < brojKontaktiranihOsoba; j++) {
                do {
                    System.out.println("    Odaberite " + (j + 1) + ". osobu:");
                    for (int k = 0; k < i; k++) {
                        System.out.println("    " + (k + 1) + ". " + osobe[k].getIme() + " " + osobe[k].getPrezime());
                    }

                    //PROVJERA IZNIMKE ZA UNOS BROJA
                    Boolean flagIznimka = true;
                    do {
                        try {
                            System.out.print("    Odabir: ");
                            odabirKontaktiraneOsobe = unos.nextInt();
                            provjeri_Valjanost_Odabira_Kontaktirane_Osobe(i, odabirKontaktiraneOsobe, j);

                            logger.info("Broj je ispravno une�en, odabir kontaktirane osobe je pod brojem: " + odabirKontaktiraneOsobe);

                            flagIznimka = false;
                            ponovi = false;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (InputMismatchException iznimkaBroj) {
                            iznimkaBroj = new InputMismatchException("Pogre�ka u formatu podataka, trebate unjeti cijeli broj. molimo ponovite unos!");

                            System.out.println("\n    " + iznimkaBroj.getMessage());
                            logger.error(iznimkaBroj.getMessage(), iznimkaBroj);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        } catch (OgranicenjeBroja iznimkaOgranicenja) {
                            System.out.println("\n    " + iznimkaOgranicenja.getMessage() + "\n");
                            logger.error(iznimkaOgranicenja.getMessage(), iznimkaOgranicenja);

                            flagIznimka = true;
                            ponovi = true;
                            unos.nextLine(); //�I��ENJE BUFFERA
                        }
                    } while (flagIznimka == true);


                    if (ponovi == false) {
                        //POSTOJE LI DUPLIKATI U KONTAKTIRANIM OSOBAMA
                        try {
                            nizOdabranihOsoba[j] = odabirKontaktiraneOsobe;
                            provjeraDuplikataKontaktiranihOsoba(nizOdabranihOsoba);
                            logger.info("Nema duplikata me�u kontaktiranim osobama");
                            ponovi = false;

                        } catch (DuplikatKontaktiraneOsobe iznimkaDupleKontaktiraneOsobe) {
                            System.out.println("    " + iznimkaDupleKontaktiraneOsobe.getMessage() + "\n");
                            logger.error(iznimkaDupleKontaktiraneOsobe.getMessage(), iznimkaDupleKontaktiraneOsobe);
                            ponovi = true;
                        }
                    }
                }
                while (ponovi);

                kontaktiraneZarazeneOsobe[j] = osobe[odabirKontaktiraneOsobe - 1];
                nizOdabranihOsoba = Arrays.copyOf(nizOdabranihOsoba, nizOdabranihOsoba.length + 1);
                System.out.println();
            }
            return kontaktiraneZarazeneOsobe;
        } else {
            return null;
        }
    }


    /**
     * Provjerava valjanost odabira kontaktirane osobe.
     *
     * @param i max broj osoba s kojima je osoba mogla biti u kontaktu
     * @param odabirKontaktiraneOsobe broj pod kojim se osoba nalazi
     * @param j index kontaktirane osobe u nizu kontaktiranih osoba
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Odabira_Kontaktirane_Osobe(int i, Integer odabirKontaktiraneOsobe, int j) {
        if (odabirKontaktiraneOsobe < 1 || odabirKontaktiraneOsobe > i)
            throw new OgranicenjeBroja("Krivi unos, odabrite kontaktiranu osobu koja se nalazi na popisu (interval od 1 do " + i + "). Ponovite unos za " + (j + 1) + ". osobu!");
    }


    /**
     * Provjerava valjanost za ukupan broj s kojima je osoba mogla kontaktirati
     *
     * @param i index trenutne osobe, samo osobe koje dolaze prije trenutne osobe mogu biti kontaktirane
     * @param brojKontaktiranihOsoba broj kontaktiranih osoba
     * @throws OgranicenjeBroja neispravan unos
     */
    private static void provjeri_Valjanost_Broja_Kontaktiranih_Osoba(int i, Integer brojKontaktiranihOsoba) {
        if (brojKontaktiranihOsoba > i || brojKontaktiranihOsoba < 0)
            throw new OgranicenjeBroja("Neispravan unos broja kontaktiranih osoba, mo�ete odabrani maksimalno " + i + ", a minimalno 0 osoba.");
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA

    /**
     * Ispisuje podatke o osobama.
     *
     * @param osobe niz osoba
     * @param i index osobe u nizu
     */
    private static void ispisOsoba(Osoba[] osobe, int i) {
        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe[i].getIme() + " " + osobe[i].getPrezime());
        System.out.println("    Starost: " + osobe[i].getStarost());
        System.out.println("    �upanija prebivali�ta: " + osobe[i].getZupanija().getNaziv());
        System.out.println("    Zara�en bole��u: " + osobe[i].getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");
        //osobe[i] JE TRENUTNA OSOBA KOJA MO�E SADR�AVATI NIZ ZAR�ENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe[i].getKontaktiraneOsobe() != null) //PROVJERVA DA LI NIZ ZARA�ENIH OSOBA UOP�E POSTOJI
        {
            for (int j = 0; j < osobe[i].getKontaktiraneOsobe().length; j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe[i].getKontaktiraneOsobe()[j].getIme() + " " + osobe[i].getKontaktiraneOsobe()[j].getPrezime());
            }
        } else //AKO NIZ ZARA�ENIH OSOBA NE POSTOJI
        {
            System.out.print("Nema kontaktiranih osoba.");
        }
        System.out.println("\n");
    }

    /**
     * Provjerava ako se ponavljaju iste kontaktirane osobe
     *
     * @param niz niz odabira kontaktiranih osoba
     * @throws DuplikatKontaktiraneOsobe govori da je do�lo do duplikata
     */
    //METODA ZA PROVJERU DUPLIKATA KONTAKTIRANIH ZARA�ENIH OSOBA I BACANJE IZNIMKE
    private static void provjeraDuplikataKontaktiranihOsoba(Integer[] niz) throws DuplikatKontaktiraneOsobe {
        int counter = 0;
        for (int i = 0; i < niz.length; i++) {
            if (niz[niz.length - 1] == niz[i]) {
                counter++;
                if (counter == 2) {
                    throw new DuplikatKontaktiraneOsobe("Odabrana osoba se ve� nalazi me�u kontaktiranim osobama. Molimo Vas da odaberete neku drugu osobu.");
                }
            }
        }
    }


    //METODA ZA PROVJERAVANJE ISTIH SIMPTOMA KOD BOLESTI
    /**
     * Provjerava ponavljaju li se isti simptomi
     *
     * @param element suma odabira simptoma za jednu bolest
     * @param suma_Odabira_Simptoma_Za_Svaku_Bolest niz suma odabira simptoma za svaku bolest
     * @throws BolestIstihSimptoma ne dopu�ta unos bolesti koje imaju iste simptome
     */
    private static void provjeriBolestiIstihSimptoma(Integer element, Integer[] suma_Odabira_Simptoma_Za_Svaku_Bolest) {
        Integer ponavljanje = 0;

        for (int i = 0; i < suma_Odabira_Simptoma_Za_Svaku_Bolest.length; i++)
            if (element == suma_Odabira_Simptoma_Za_Svaku_Bolest[i])
                ponavljanje++;

        if (ponavljanje >= 2)
            throw new BolestIstihSimptoma("Pogre�an unos, ve� ste unijeli bolest ili virus s istim simptomima. Molimo ponovite unos.");
    }


    //KRAJ CIJELE KLASE: GLAVNA


}
