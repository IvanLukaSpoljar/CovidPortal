package hr.java.covidportal.iznimke;
/**
 *Služi za kreiranje neoznačene vlastite iznimke u klasi Glavna.
 */
public class OgranicenjeBroja extends RuntimeException
{
    public OgranicenjeBroja(String message)
    {
        super(message);
    }

    public OgranicenjeBroja(Throwable cause)
    {
        super(cause);
    }

    public OgranicenjeBroja(String message, Throwable cause)
    {
        super(message, cause);
    }
}
