package main.java_main_logic.ekrani;


import ch.qos.logback.core.util.Loader;
import javafx.scene.control.TableRow;
import javafx.stage.Stage;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
import main.java_main_logic.model.Simptom;
import main.java_main_logic.model.Virus;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaVirusaController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba, prikazVirusaController {

    List<Virus> listaSvihVirusa = new ArrayList<>();
    public static final Logger logger = LoggerFactory.getLogger(PretragaVirusaController.class);

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Virus> tablicaVirusa;

    @FXML
    private TableColumn<Virus, String> stupacNaziva;

    @FXML
    private TableColumn<Virus, Set<Simptom>> stupacSimptoma;

    //1. ZADATAK
    @FXML
    private TableColumn<Virus, String> stupacOpisa;
    @FXML
    private TextField rijecOpisa;




    @FXML
    public void odiNatrag() throws IOException
    {
        Parent pretragaZupanijaFrame = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Covidportal");

        logger.info("Korisnik je zatvorio ekran o Virusima");

    }


    @FXML
    public void pretrazi() throws IOException
    {
        tablicaVirusa.setItems(FXCollections.observableList(listaSvihVirusa));


        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaVirusa.setItems(FXCollections.observableList(
                    listaSvihVirusa.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }


        //1. ZADATAK
        if(rijecOpisa.getText().isEmpty() == false)
        {
            tablicaVirusa.setItems(FXCollections.observableList(
                    listaSvihVirusa.stream()
                            .filter(z -> z.getOpis().toLowerCase().contains(rijecOpisa.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }



    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Virusi");
        logger.info("Korisnik je otvorio ekran o Virusima");


        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Virus, String>("naziv"));
        stupacSimptoma.setCellValueFactory(new PropertyValueFactory<Virus, Set<Simptom>>("simptomi"));
        //1. ZADATAK
        stupacOpisa.setCellValueFactory(new PropertyValueFactory<Virus, String>("opis"));


        listaSvihVirusa = liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba.sviVirusi;
        tablicaVirusa.setItems(FXCollections.observableList(listaSvihVirusa));


        //2. Zadatak
        /*
        tablicaVirusa.setRowFactory(x ->
        {
            TableRow<Virus> row = new TableRow<>();

            row.setOnMouseClicked(event ->
            {
                if(event.getClickCount() == 2 && (row.isEmpty() == false))
                {
                    Virus jedanVirus = row.getItem();
                    otvoriNoviProzor(jedanVirus);
                }
            });


        return row;
        });
        }*/


        /*
        public void otvoriNoviProzor(Virus jedanVirus){

        try {
            FXMLLoader ucitavanje = new FXMLLoader(getClass().getResource("layout/prikazVirusa.fxml"));
            Scene scena = new Scene(ucitavanje.load(), 600, 600);
            Stage stg = new Stage();
            stg.setScene(scena);
            stg.show();

            prikazVirusaController controller = ucitavanje.getController();
            controller.prikaz(jedanVirus);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }*/
    }

}

