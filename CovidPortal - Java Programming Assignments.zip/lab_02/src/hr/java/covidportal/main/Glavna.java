/*
Napomene: 
Datoteka koju stavljate na grader ne mora imati isti naziv, ali mora biti "zip" datoteka.
Datoteku je potrebno uploadati najkasnije do 29.10.2020. u 18:00 - naknadne predaje se ne uvažavaju.
Sljedeća vježba se ne nastavlja na ovaj zadatak, već na pripremu!
Za svako rješenje zadatka mole se studenti da ga naznače kao komentar u kodu s dvije kose crte (npr: // 1. zadatak) kako bi mi bilo lakše pregledavati vježbe. Hvala!

1.      Proširiti zadatak za pripremu na način da se omogući neograničen broj unosa županija. Unos treba prestati kada korisnik ne unese prvi traženi podatak županije. (3 boda)

2.      Polje županija je potrebno sortirati prvo po nazivu, pa po broju stanovnika (znači, ako su nazivi jednaki, sortira se po broju stanovnika). Slobodno koristite Comparator ili Lambdu ako Vam je tako lakše. (2 boda)

3.      Ispisati sortiranu listu. (1 bod)
*/

package hr.java.covidportal.main;

import hr.java.covidportal.model.Zupanija;
import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Osoba;
import hr.java.covidportal.model.Virus;
import hr.java.covidportal.model.Simptom;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


public class Glavna {
    private static final Integer KONSTANTA = 3;

    //KONSTANTE ZA BROJ ELEMENATA U NIZOVIMA (UJEDNO I PETLJAMA)
    private static final Integer BROJ_SIMPTOMA = KONSTANTA;
    public static final Integer BROJ_BOLESTI = 4;
    public static final Integer BROJ_OSOBA = KONSTANTA;


    public static void main(String[] args) {
        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        Zupanija[] zupanije = new Zupanija[1];
        Simptom[] simptomi = new Simptom[BROJ_SIMPTOMA];
        Bolest[] bolesti = new Bolest[BROJ_BOLESTI];
        Osoba[] osobe = new Osoba[BROJ_OSOBA];



        //<-------------ŽUPANIJE---------------->
        System.out.println("\nUnesite podatke o N županija: ");

        //1.ZADATAK
        int counterZupanija = 0;
        boolean nastavi;
        do{
            nastavi = true;
            String nazivZupanije;
            Integer brojStanovnika;

            label:
            {
                System.out.print((counterZupanija + 1) + ". Županija:");
                System.out.print("\n    Unesite naziv županije: ");
                nazivZupanije = unos.nextLine();

                if (nazivZupanije == "") {
                    nastavi = false;
                    break label;
                }

                System.out.print("    Unesite broj stanovnika: ");
                brojStanovnika = unos.nextInt();
                unos.nextLine(); //ČIŠĆENJE BUFFERA

                zupanije[counterZupanija] = new Zupanija(nazivZupanije, brojStanovnika);

                System.out.println();
                zupanije = Arrays.copyOf(zupanije, zupanije.length +1);
                counterZupanija++;
            }
        }while(nastavi);
        int BROJ_ZUPANIJA = counterZupanija;





        /*System.out.println("\nISPIS IMENA I BROJA STANOVNIKA PO ŽUPANIJAMA");
        for(int i = 0; i < BROJ_ZUPANIJA; i++)
            System.out.println("    " + (i + 1) + ". Županija je: [" + zupanije[i].getNaziv() + "] --> Broj stanovnika je: " + zupanije[i].getBrojStanovnika());*/



        //<-------------SIMPTOMI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_SIMPTOMA + " simptoma: ");
        for (int i = 0; i < BROJ_SIMPTOMA; i++)
            simptomi[i] = unosSimptoma(unos, i);

        /*System.out.println("\nISPIS SIMPTOMA I VRIJEDNOSTI");
        for(int i = 0; i < BROJ_SIMPTOMA; i++)
            System.out.println("    " + (i + 1) + ". Simptom je: [" + simptomi[i].getNaziv() + "] --> Vrijendost je: " + simptomi[i].getVrijednost());*/


        //<-------------BOLESTI---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_BOLESTI + " bolesti ili virusa: ");
        for (int i = 0; i < BROJ_BOLESTI; i++)
            bolesti[i] = unosBolesti(unos, simptomi, i);

        /*System.out.println("\nISPIS BOLESTI I NJIHOVIH VRIJEDNOSTI");
        for(int i = 0; i < BROJ_BOLESTI; i++)
        {
            if(bolesti[i] instanceof Virus )
            {
                System.out.println("    " + (i + 1) + ". Virus je: " + bolesti[i].getNaziv());
                for(int j = 0; j < bolesti[i].getSimptomi().length; j++)
                    System.out.println("        -> Naziv simptoma je: " + bolesti[i].getSimptomi()[j].getNaziv() + "\n        -> Učestalost simptoma je: " + bolesti[i].getSimptomi()[j].getVrijednost() + "\n");
            }
            else
            {
                System.out.println("    " + (i + 1) + ". Bolest je: " + bolesti[i].getNaziv());
                for(int j = 0; j < bolesti[i].getSimptomi().length; j++)
                    System.out.println("        -> Naziv simptoma je: " + bolesti[i].getSimptomi()[j].getNaziv() + "\n        -> Učestalost simptoma je: " + bolesti[i].getSimptomi()[j].getVrijednost() + "\n");
            }
        }*/


        //<-------------OSOBE---------------->
        System.out.println("\n\nUnesite podatke o " + BROJ_OSOBA + " osobe: ");
        for (int i = 0; i < BROJ_OSOBA; i++)
           osobe[i] = unosOsoba(unos, zupanije, bolesti, osobe, i, BROJ_ZUPANIJA);


        //<-------------ISPIS SVIH OSOBA I PODATAKA O NJIMA---------------->
        System.out.println("\n************************POPIS OSOBA************************\n");
        for (int i = 0; i < osobe.length; i++)
            ispisOsoba(osobe, i);

        //KRAJ CIJELE MAIN FUNKCIJE
    }





    private static Zupanija[] extendArraySize(Zupanija [] array){
        Zupanija [] temp = array.clone();
        array = new Zupanija[array.length + 1];
        System.arraycopy(temp, 0, array, 0, temp.length);
        return array;
    }





    //METODA ZA UNOS SIMPTOMA
    private static Simptom unosSimptoma(Scanner unos, int i) {
        String naziv;
        String vrijednost;
        Boolean ponovi;

        System.out.println((i + 1) + ". Simptom:");
        System.out.print("    Unesite naziv simptoma: ");
        naziv = unos.nextLine();

        do {
            System.out.print("    Unesite vrijednost simptoma (RIJETKO, SREDNJE ILI ČESTO): ");
            vrijednost = unos.nextLine();

            ponovi = true;

            if (vrijednost.equals("RIJETKO") || vrijednost.equals("SREDNJE") || vrijednost.equals("ČESTO"))
                ponovi = false;
            else
                System.out.println("\n    Krivi unos, točno unesite navedene vrijednosti: RIJETKO, SREDNJE ili ČESTO");
        }
        while (ponovi);
        Simptom simptom = new Simptom(naziv, vrijednost);

        System.out.println();
        return simptom;
    }


    //METODA ZA UNOS BOLESTI
    private static Bolest unosBolesti(Scanner unos, Simptom[] simptomi, int i) {
        Integer brojSimptoma;
        Integer odabirVrsteBolesti;
        Boolean odabranVirus = false;
        Boolean odabranaBolest = false;

        //UNOS BOLESTI ILI VIRUSA
        System.out.println((i + 1) + ". Vrsta zaraze:");
        do {
            System.out.println("    Unosite ili bolest ili virus?");
            System.out.println("    1) Bolest");
            System.out.println("    2) Virus");
            System.out.print("    Vaš odabir pod brojem: ");
            odabirVrsteBolesti = unos.nextInt();

            if (odabirVrsteBolesti < 1 || odabirVrsteBolesti > 2)
                System.out.println("\n    Krivi odabir, molim odaberite broj 1 ili 2");
            else if (odabirVrsteBolesti == 1)
                odabranaBolest = true;
            else if (odabirVrsteBolesti == 2)
                odabranVirus = true;

        } while (odabirVrsteBolesti < 1 || odabirVrsteBolesti > 2);
        unos.nextLine(); //ČIŠĆENJE BUFFERA

        //UNOS NAZIVA BOLESTI ILI VIRUSA
        System.out.print("\n    Unesite naziv bolesti ili virusa: ");
        String naziv = unos.nextLine();

        do {
            System.out.print("    Unesite broj simptoma: ");
            brojSimptoma = unos.nextInt();

            if (brojSimptoma < 1 || brojSimptoma > BROJ_SIMPTOMA)
                System.out.println("    Krivi unos, broj mora biti u intervalu od 1 do " + BROJ_SIMPTOMA);
        }
        while (brojSimptoma < 1 || brojSimptoma > BROJ_SIMPTOMA);
        unos.nextLine(); //ĆIŠČENJE BUFFERA

        Simptom[] kolikoSimptoma = new Simptom[brojSimptoma];
        Integer[] prijasnjiOdabir = new Integer[brojSimptoma];

        //DODJELJIVANJE SIMPTOMA ZA BOLEST ILI VIRUS
        for (int j = 0; j < brojSimptoma; j++) {
            Integer odabirSimptoma;
            Boolean ponovi;

            //ODABERI SIMPTOM POMOĆU BROJA
            do {
                Integer counter = 0;
                ponovi = false;

                System.out.println("\n    Odaberite " + (j + 1) + ". simptom: ");
                for (int k = 0; k < simptomi.length; k++)
                    System.out.println("    " + (k + 1) + ". " + simptomi[k].getNaziv() + " " + simptomi[k].getVrijednost());

                System.out.print("    Odabir: ");
                odabirSimptoma = unos.nextInt();
                unos.nextLine(); //ĆIŠČENJE BUFFERA
                prijasnjiOdabir[j] = odabirSimptoma;

                //PONAVLJAJU LI SE ODABRANI SIMPTOMI ZA ISTU BOLEST, NEMOGUĆE JE DA BOLEST IMA 2 ILI VIŠE ISTA SIMPTOMA
                for (int k = 0; k < prijasnjiOdabir.length; k++) {
                    if (odabirSimptoma.equals(prijasnjiOdabir[k])) {
                        counter++;
                        if (counter == 2) {
                            ponovi = true;
                        }
                    }
                }

                if (ponovi) {
                    System.out.println("\n    Krivi unos, svi simptomi zaraze moraju biti međusobno različiti!");
                } else if (odabirSimptoma < 1 || odabirSimptoma > BROJ_SIMPTOMA) {
                    System.out.println("\n    Neispravan unos, molimo pokušajte ponovno!");
                    ponovi = true;
                } else {
                    kolikoSimptoma[j] = simptomi[odabirSimptoma - 1];
                    ponovi = false;
                }
            }
            while (ponovi);
        }

        //BOLEST ILI VIRUS ?
        Bolest element = null;
        if (odabranaBolest)
            element = new Bolest(naziv, kolikoSimptoma);
        else if (odabranVirus)
            element = new Virus(naziv, kolikoSimptoma);

        System.out.println();
        return element;
    }


    //METODA ZA UNOS OSOBA
    private static Osoba unosOsoba(Scanner unos, Zupanija[] zupanije, Bolest[] bolesti, Osoba[] osobe, int i, int BROJ_ZUPANIJA) {
        String imeOsobe;
        String prezimeOsobe;
        Integer starostOsobe;

        System.out.println((i + 1) + ". Osoba:");

        //UNOS IMENA
        System.out.print("    Unesite ime osobe: ");
        imeOsobe = unos.nextLine();

        //UNOS PREZIMENA
        System.out.print("    Unesite prezime osobe: ");
        prezimeOsobe = unos.nextLine();

        //UNOS STAROSTI
        System.out.print("    Unesite starost osobe: ");
        starostOsobe = unos.nextInt();
        unos.nextLine(); //ČIŠĆENJE BUFFERA


        //FINALNO INICIJALIZIRANJE TRENUTNE GLAVNE OSOBE SA SVIM PARAMETRIMA
        return new Osoba.Builder(imeOsobe)
                .surname(prezimeOsobe)
                .age(starostOsobe)
                .county(unos_Zupanije_Osobe(unos, zupanije, BROJ_ZUPANIJA)) //UNOS PREBIVALIŠNE ŽUPANIJE OSOBE
                .personInfection(unos_Bolesti_Osobe(unos, bolesti)) //UNOS BOLESTI OSOBE
                .contactedPersons(kontaktiranje_Sa_Zarazenim_Osobama(unos, osobe, i)) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MOŽE BITI NULL
                .makeItDone();
    }


    //METODA ZA UNOS PREBIVALIŠNE ŽUPANIJE SVAKE OSOBE
    private static Zupanija unos_Zupanije_Osobe(Scanner unos, Zupanija[] zupanije, int BROJ_ZUPANIJA) {
        Integer odabirZupanije;

        do {
            System.out.println("\n    Unesite županiju prebivališta osobe: ");
            for (int j = 0; j < zupanije.length; j++)
                System.out.println("    " + (j + 1) + ". " + zupanije[j].getNaziv());
            System.out.print("    Odabir: ");

            odabirZupanije = unos.nextInt();

            if (odabirZupanije < 1 || odabirZupanije > BROJ_ZUPANIJA)
                System.out.println("\n    Krivi unos, unesite ponovno!");
        }
        while (odabirZupanije < 1 || odabirZupanije > BROJ_ZUPANIJA);
        unos.nextLine(); //ČIŠĆENJE BUFFERA

        return zupanije[odabirZupanije - 1];
    }


    //METODA ZA UNOŠENJE BOLESTI SVAKE OSOBE
    private static Bolest unos_Bolesti_Osobe(Scanner unos, Bolest[] bolesti) {
        Integer odabirBolesti;

        do {
            System.out.println("\n    Unesite bolest ili virus osobe: ");
            for (int j = 0; j < bolesti.length; j++)
                System.out.println("    " + (j + 1) + ". " + bolesti[j].getNaziv());
            System.out.print("    Odabir: ");
            odabirBolesti = unos.nextInt();

            if (odabirBolesti < 1 || odabirBolesti > BROJ_BOLESTI)
                System.out.println("\n    Krivi unos, unesite ponovno!");
            else
                System.out.println();
        }
        while (odabirBolesti < 1 || odabirBolesti > BROJ_BOLESTI);
        unos.nextLine(); //ČIŠĆENJE BUFFERA

        return bolesti[odabirBolesti - 1];
    }


    //METODA ZA UNOŠENJE KONTAKATA SA ZARAŽENIM OSOBAMA
    private static Osoba[] kontaktiranje_Sa_Zarazenim_Osobama(Scanner unos, Osoba[] osobe, int i) {
        Integer brojKontaktiranihOsoba = 0;
        Boolean ponovi = true;

        //OD 2. OSOBE (INDEKS 1) PA NADALJE DOPUSTI UNOS BROJA OSOBA KOJE SU BILE U KONTAKTU S TOM OSOBOM
        if (i > 0) {
            do {
                System.out.print("\n    Unesite broj osoba koje su bile u kontaktu s tom osobom: ");
                brojKontaktiranihOsoba = unos.nextInt();

                if (brojKontaktiranihOsoba > i || brojKontaktiranihOsoba < 0) {
                    System.out.println("    Broj osoba koje su bile u kontaktu s tom osobom mora biti veći ili jednak " + 0 + " i manji od " + (i + 1));
                    ponovi = true;
                } else
                    ponovi = false;
            }
            while (ponovi);

            System.out.println();
            unos.nextLine();
        }

        //OMOGUĆUJE UNOS PRETHODNIH ZARAŽENIH OSOBA, TIME ĆE SE STVORITI OBJEKTI U NIZU PRETHODNIH ZARAŽENIH OSOBA
        if (brojKontaktiranihOsoba > 0) {
            Osoba[] kontaktiraneZarazeneOsobe = new Osoba[brojKontaktiranihOsoba];
            Integer odabirKontaktiraneOsobe;

            System.out.println("    Unesite osobe koje su bile u kontaktu s tom osobom:");
            for (int j = 0; j < brojKontaktiranihOsoba; j++) {
                do {
                    System.out.println("    Odaberite " + (j + 1) + ". osobu:");
                    for (int k = 0; k < i; k++) {
                        System.out.println("    " + (k + 1) + ". " + osobe[k].getIme() + " " + osobe[k].getPrezime());
                    }
                    System.out.print("    Odabir: ");
                    odabirKontaktiraneOsobe = unos.nextInt();

                    if (odabirKontaktiraneOsobe < 1 || odabirKontaktiraneOsobe > i) {
                        System.out.println("\n    Krivi unos, ponovite unos za " + (j + 1) + ". osobu!\n");
                        ponovi = true;
                    } else {
                        ponovi = false;
                    }
                }
                while (ponovi);
                unos.nextLine();
                kontaktiraneZarazeneOsobe[j] = osobe[odabirKontaktiraneOsobe - 1];

                System.out.println();
            }
            return kontaktiraneZarazeneOsobe;
        } else {
            return null;
        }
    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA
    private static void ispisOsoba(Osoba[] osobe, int i) {
        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe[i].getIme() + " " + osobe[i].getPrezime());
        System.out.println("    Starost: " + osobe[i].getStarost());
        System.out.println("    Županija prebivališta: " + osobe[i].getZupanija().getNaziv());
        System.out.println("    Zaražen bolešću: " + osobe[i].getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");
        //osobe[i] JE TRENUTNA OSOBA KOJA MOŽE SADRŽAVATI NIZ ZARŽENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe[i].getKontaktiraneOsobe() != null) //PROVJERVA DA LI NIZ ZARAŽENIH OSOBA UOPĆE POSTOJI
        {
            for (int j = 0; j < osobe[i].getKontaktiraneOsobe().length; j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe[i].getKontaktiraneOsobe()[j].getIme() + " " + osobe[i].getKontaktiraneOsobe()[j].getPrezime());
            }
        } else //AKO NIZ ZARAŽENIH OSOBA NE POSTOJI
        {
            System.out.print("Nema kontaktiranih osoba.");
        }
        System.out.println("\n");
    }
    //KRAJ CIJELE KLASE: GLAVNA
}