package main.java_main_logic.kontroleri_ekrana.pretraga;


import javafx.scene.control.Button;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.model.Simptom;
import main.java_main_logic.model.Virus;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaVirusaController implements Initializable, PovijestKretanjaPoEkranima {

    List<Virus> listaSvihVirusa = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaVirusa.fxml";
    public static final Logger logger = LoggerFactory.getLogger(PretragaVirusaController.class);


    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Virus> tablicaVirusa;
    @FXML
    private TableColumn<Virus, String> stupacNaziva;
    @FXML
    private TableColumn<Virus, Set<Simptom>> stupacSimptoma;
    //1.ZADATAK
    @FXML
    private TableColumn<Virus, String> opisVirusa;




    @FXML
    public void odiNatrag() throws IOException
    {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o Virusima");
    }
    @FXML
    public void odiNaprijed() throws IOException {
       slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }
    @FXML
    public void pretrazi() throws IOException
    {
        tablicaVirusa.setItems(FXCollections.observableList(listaSvihVirusa));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaVirusa.setItems(FXCollections.observableList(
                    listaSvihVirusa.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        Main.getMainStage().setTitle("Virusi");
        logger.info("Korisnik je otvorio ekran o Virusima");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Virus, String>("naziv"));
        stupacSimptoma.setCellValueFactory(new PropertyValueFactory<Virus, Set<Simptom>>("simptomi"));
        opisVirusa.setCellValueFactory(new PropertyValueFactory<Virus, String>("opis"));

        listaSvihVirusa = ListeZupanijaSimptomaBolestiVirusaOsoba.sviVirusi;
        tablicaVirusa.setItems(FXCollections.observableList(listaSvihVirusa));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}

