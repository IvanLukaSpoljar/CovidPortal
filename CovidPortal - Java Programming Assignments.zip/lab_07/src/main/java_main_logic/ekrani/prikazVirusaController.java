package main.java_main_logic.ekrani;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
import main.java_main_logic.model.Simptom;
import main.java_main_logic.model.Virus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public interface prikazVirusaController {

    @FXML
    Label idVirusa = null;

    @FXML
    Label nazivVirusa = null;

    @FXML
    Label naziviSimptoma = null;

    @FXML
    Label opisTekst = null;



    public default void prikaz(Virus jedanVirus)
    {

        this.idVirusa.setText(Long.toString(jedanVirus.getId()));
        this.nazivVirusa.setText(jedanVirus.getNaziv());


    }

}

