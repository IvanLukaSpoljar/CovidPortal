package hr.java.covidportal.main;

import hr.java.covidportal.genericsi.KlinikaZaInfektivneBolesti;
import hr.java.covidportal.model.*;


import hr.java.covidportal.pomocno.Varijable_Simptoma_i_Bolesti;
import hr.java.covidportal.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Slu�i za testiranje logginga tijekom izvo�enja programa.
 */
public class Glavna {

    public static final Logger logger = LoggerFactory.getLogger(Glavna.class);

    /**
     * Slu�i za pokretanje programa koji �e od korisnika tra�iti da svojim unosom definira vrijednosti pojedinih
     * varijabli, te nakon toga da unese zara�ene osobe kod kojih �e se vidjeti jesu li u me�uvremenu zara�eni
     * nekom drugom bole��u i s kime su sve kontaktirali.
     *
     * @param args argumenti komandne linije
     */
    public static void main(String[] args) throws IOException {

        logger.info("PO�ETAK PROGRAMA");

        Scanner unos = new Scanner(System.in);

        //INICIJALIZIRANJE GLAVNIH NIZOVA
        List<Zupanija> zupanije = new ArrayList<>();
        List<Simptom> simptomi = new ArrayList<>();
        List<Bolest> bolesti = new ArrayList<>();
        List<Osoba> osobe = new ArrayList<>();

        //MAPA
        Map<Bolest, List<Osoba>> mapaZarazenihPoBolesti = new HashMap<>();


        //POMO�NE VARIJABLE
        Varijable_Simptoma_i_Bolesti dohvatVarijabli = new Varijable_Simptoma_i_Bolesti();
        Boolean flagIznimka = true;


        //2.ZADATAK - ispis
        String imeTekstualDat = "tekstualni_outputi/zad2_izlazi.txt";
        Path txt_file_putanja = Path.of(imeTekstualDat);
        File jelPostoji = new File(imeTekstualDat);
        if(jelPostoji.exists())
        {
            try {
                String tekst = Files.readString(txt_file_putanja);
                System.out.println("Pro�itana txt datoteka:");
                System.out.println(tekst);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }



        //<-------------�UPANIJE---------------->
        System.out.println("\n#################################################### UNOS �UPANIJA ####################################################");
        File zupanijeFileTxt = new File("dat/zupanije.txt");
        try (FileReader fileReader = new FileReader(zupanijeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke zupanija je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv iz datoteke zupanija je: " + naziv);

                procitanaLinija = reader.readLine();
                Integer brStanovnika = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itani Broj Stanovnika iz datoteke zupanija je: " + brStanovnika);

                procitanaLinija = reader.readLine();
                Integer brZarazenih = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itani Broj Zara�enih Stanovnika iz datoteke zupanija je: " + brZarazenih);

                zupanije.add(new Zupanija(id, naziv, brStanovnika, brZarazenih));
                procitanaLinija = reader.readLine();
            }

            logger.info("Podatci o �upanijama su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();

            ex = new IOException("Neuspjelo u�itavanje podataka o �upanijama.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }



        //SERIJALIZACIJA -> STAVLJANJE PODATAKA U BINARNU DATOTEKU
        try (ObjectOutputStream serijalizator = new ObjectOutputStream(new FileOutputStream("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat"))) {

            List<String> listaRecenica = zupanije.stream()
                    .filter(z -> z.getPostotakZarazenost() > 2)
                    .map(recenica -> new String(recenica.getNaziv() + " �upanija ima " + recenica.getPostotakZarazenost() + "% zara�enih."))
                    .collect(Collectors.toList());

                serijalizator.writeObject(listaRecenica);
        } catch (IOException ex) {
            ex.printStackTrace();
        }


        //1.ZADATAK
        String imeDat = "binarni_outputi/zad1_izlazi.dat";
        //Deserijalizacija
        File postojanje = new File(imeDat);
        if(postojanje.exists())
        {
            List<Zupanija> procitaneZup = null;
            try {
                ObjectInputStream in = new ObjectInputStream(new FileInputStream(imeDat));

                procitaneZup = (List<Zupanija>) in.readObject();
                in.close();
            } catch (IOException ex) {
                System.err.println(ex);

            } catch (ClassNotFoundException ex) {
                System.err.println(ex);
            }

            System.out.println("Ispis zupanija: ");

            procitaneZup.stream()
                    .forEach(System.out::println);
        }
        //Serijalizacija
        try (ObjectOutputStream serijalizator = new ObjectOutputStream(new FileOutputStream("binarni_outputi/zad1_izlazi.dat"))) {

            List<Zupanija> listaZup = zupanije.stream()
                    .filter(z -> z.getNaziv().toLowerCase().startsWith("o") && z.getNaziv().contains("r"))
                    .collect(Collectors.toList());

            serijalizator.writeObject(listaZup);
        } catch (IOException ex) {
            ex.printStackTrace();
        }



        //2.ZADATAK
        Integer sumaDuljine = zupanije.stream()
                .mapToInt(z -> z.getNaziv().length())
                .sum();

        Double prosjekDuljine = (double)sumaDuljine / (double)zupanije.stream().count();

        String najkraciNazivZup = zupanije.stream()
                .min(Comparator.comparingInt(z -> z.getNaziv().length()))
                .map(z -> z.getNaziv())
                .get();

        String najduljiNazivZup = zupanije.stream()
                .max(Comparator.comparingInt(z -> z.getNaziv().length()))
                .map(z -> z.getNaziv())
                .get();

        try(PrintWriter out = new PrintWriter(new FileWriter(new File(imeTekstualDat))))
        {
            out.println("Duljina je: " + sumaDuljine);
            out.println("Prosijek je: " + prosjekDuljine);
            out.println("Najkraci naziv: " + najkraciNazivZup);
            out.println("Najdulji naziv je: " + najduljiNazivZup);
        }catch(IOException ex)
        {
            ex.printStackTrace();
        }






        //KOPIRANJE BINARNE DATOTEKE U DRUGU BINARNU DATOTEKU (moja vje�ba)
        /*File infile = new File("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat");
        File outfile = new File("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti_KOPIJA.dat");

        try(FileInputStream fin = new FileInputStream(infile); FileOutputStream fout = new FileOutputStream(outfile))
        {
            byte[] buffer = new byte[1024];
            int bytesRead = fin.read(buffer);

            while(bytesRead != -1)
            {
                fout.write(buffer, 0 ,bytesRead);
                bytesRead = fin.read(buffer);
            }

        }catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }*/
        //KOPIRANJE BINARNE DATOTEKE U DRUGU BINARNU DATOTEKU (moja vje�ba)
        //copyFile(infile, new File("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti_KOPIJA_2.dat"));


        /*//KOLIKO LINIJA IMA BINARNA DATOTEKA(moja vje�ba)
        Integer brojLinijaBinarneDatoteke = 0;
        try {
            InputStream in = new FileInputStream("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat");

            int broj = in.read();

            while (broj != -1)
            {
                if((char) broj == '.')
                {
                    brojLinijaBinarneDatoteke++;
                }
                broj = in.read();
            }
            in.close();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        brojLinijaBinarneDatoteke /= 2;*/



        //DOHVA�ANJE PODATAKA IZ BINARNE DATOTEKE (moja vje�ba)
        List<String> procitani = null;
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("binarni_outputi/zupanije_sa_odredjenim_postotkom_zarazenosti.dat"));

            procitani = (List<String>) in.readObject();
            in.close();
        } catch (IOException ex) {
            System.err.println(ex);

        } catch (ClassNotFoundException ex) {
            System.err.println(ex);
        }


        //STAVLJANJE DOHVA�ENIH PODATAKA U NOVI TEKSTUALNI FILE (moja vje�ba)
        try(PrintWriter out = new PrintWriter(new FileWriter(new File("tekstualni_outputi/tekstualni_rezultati.txt"))))
        {
            for(int i = 0; i < procitani.size(); i++)
            {
                String noviTmp = procitani.get(i).replace(", ", "");
                out.println(noviTmp);
            }
        }catch(IOException ex)
        {
            ex.printStackTrace();
        }




        //<-------------SIMPTOMI---------------->
        System.out.println("\n#################################################### UNOS SIMPTOMA ####################################################");
        File simptomiFileTxt = new File("dat/simptomi.txt");
        try (FileReader fileReader = new FileReader(simptomiFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv simptoma iz datoteke je: " + naziv);

                String vrijednost = procitanaLinija = reader.readLine();
                System.out.println("Pro�itana vrijednost simptoma iz datoteke je: " + vrijednost);

                simptomi.add(new Simptom(id, naziv, vrijednost));
                procitanaLinija = reader.readLine();
            }
            logger.info("Podatci o simptomima su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o simptomima.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }


        //<-------------ZARAZE---------------->
        Integer idPovecaj = 0;
        System.out.println("\n#################################################### UNOS BOLESTI #####################################################");
        ucitavanjeZaraza(bolesti, idPovecaj, simptomiFileTxt, simptomi, "dat/bolesti.txt");
        idPovecaj = bolesti.size();
        System.out.println("\n#################################################### UNOS VIRUSA ######################################################");
        ucitavanjeZaraza(bolesti, idPovecaj, simptomiFileTxt, simptomi, "dat/virusi.txt");


        for (Bolest element : bolesti)
            if (element instanceof Virus)
                dohvatVarijabli.getPomocni_Niz_Svih_Virusa().add((Virus) element);


        //<-------------OSOBE---------------->
        System.out.println("\n#################################################### UNOS OSOBA #######################################################");
        File osobeFileTxt = new File("dat/osobe.txt");
        try (FileReader fileReader = new FileReader(osobeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            String imeDatoteke = "osobe.txt";
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke " + imeDatoteke + " je: " + id);

                String imeOsobe = procitanaLinija = reader.readLine();
                System.out.println("Pro�itano ime osobe iz datoteke " + imeDatoteke + " je: " + imeOsobe);

                String prezimeOsobe = procitanaLinija = reader.readLine();
                System.out.println("Pro�itano prezime osobe iz datoteke " + imeDatoteke + " je: " + prezimeOsobe);

                procitanaLinija = reader.readLine();
                Integer starostOsobe = Integer.parseInt(procitanaLinija);
                System.out.println("Pro�itana starost osobe iz datoteke " + imeDatoteke + " je: " + starostOsobe);

                //�UPANIJA
                procitanaLinija = reader.readLine();
                Integer odabirZupanijeOsobe = Integer.parseInt(procitanaLinija);
                Zupanija zapamtiZupaniju = zupanije.get(odabirZupanijeOsobe - 1);
                System.out.println("Pro�itana prebivali�na �upanija osobe iz datoteke " + imeDatoteke + " je: " + odabirZupanijeOsobe + ". " + zapamtiZupaniju.getNaziv());

                //ZARA�ENOST
                procitanaLinija = reader.readLine();
                Integer odabirZarazeOsobe = Integer.parseInt(procitanaLinija);
                Bolest zapamtiZarazu = bolesti.get(odabirZarazeOsobe - 1);
                System.out.println("Odabir zaraze osobe iz datoteke " + imeDatoteke + " je: " + odabirZarazeOsobe + ". " + zapamtiZarazu.getNaziv());

                List<Osoba> listaSvihKontaktiranihOsoba = new ArrayList<>();

                if (osobe.size() > 0) {
                    //KOLIKO UKUPNO KONTAKTIRANIH OSOBA
                    procitanaLinija = reader.readLine();
                    Integer brojKontaktiranih = Integer.parseInt(procitanaLinija);

                    System.out.println("Broj osoba s kojima je osoba kontaktirala iz datoteke " + imeDatoteke + " je: " + brojKontaktiranih);

                    //KOJE SU TO KONTAKTIANE OSOBE
                    procitanaLinija = reader.readLine();
                    String[] replaceString = procitanaLinija.split(",");

                    for (int i = 0; i < brojKontaktiranih; i++) {
                        Integer odabirKontaktianeOsobe = Integer.parseInt(replaceString[i]);
                        Osoba zapamtiOsobu = osobe.get(odabirKontaktianeOsobe - 1);
                        listaSvihKontaktiranihOsoba.add(zapamtiOsobu);
                        System.out.println("Pro�itana kontaktirana osoba iz datoteke " + imeDatoteke + " je: " + odabirKontaktianeOsobe + ". " + zapamtiOsobu.getIme() + " " + zapamtiOsobu.getPrezime());
                    }
                }

                osobe.add(
                        new Osoba.Builder(id)
                                .name(imeOsobe)
                                .surname(prezimeOsobe)
                                .age(starostOsobe)
                                .county(zapamtiZupaniju) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                                .personInfection(zapamtiZarazu) //UNOS BOLESTI OSOBE
                                .contactedPersons(listaSvihKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                                .makeItDone()
                );

                procitanaLinija = reader.readLine();
                System.out.println();
            }
            logger.info("Podatci o osobama su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            ex = new IOException("Neuspjelo u�itavanje podataka o osobama.");
            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }


        KlinikaZaInfektivneBolesti podatciKlinikeInfektivnihBolesti = new KlinikaZaInfektivneBolesti(osobe, dohvatVarijabli.getPomocni_Niz_Svih_Virusa());


        //ISPIS
        System.out.println("\n**************************************************** POPIS OSOBA ****************************************************\n");
        for (int indexOsobe = 0; indexOsobe < osobe.size(); indexOsobe++)
            ispisOsoba(osobe, indexOsobe);

        //ISPIS
        System.out.println("\n*********************************** ISPIS SVIH ZARA�ENIH OSOBA ODRE�ENOM BOLESTI ************************************\n");
        dodaj_Zarazene_Po_Bolesti_U_Mapu(bolesti, osobe, mapaZarazenihPoBolesti);
        ispis_Mape_Zarazenih_Po_Bolesti(mapaZarazenihPoBolesti);

        //ISPIS
        System.out.println("\n*********************************** �UPANIJA SA NAJVE�IM POSTOTKOM ZARA�ENOSTI **************************************\n");
        List<Zupanija> pomocnaListaZupanija = new ArrayList<Zupanija>(zupanije);
        Collections.sort(pomocnaListaZupanija, new CovidSorter<Zupanija>());
        System.out.println("  Najvi�e zara�enih osoba ima u �upaniji " + pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getNaziv() + ": " + (int) pomocnaListaZupanija.get(pomocnaListaZupanija.size() - 1).getPostotakZarazenost() + "%.");

        //ISPIS
        System.out.println("\n******************************** IMENA VIRUSA SORTIRANIH SILAZNIM ABECEDNIM REDOM ***********************************\n");
        /*List<Virus> paralelnistream = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startparallelLambda = Instant.now();
        paralelnistream = paralelnistream.parallelStream()
                .sorted((v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv()))
                .collect(Collectors.toList());
        Instant endParallelLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom preko ParallelStream-a po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < paralelnistream.size(); i++)
            System.out.println("  " + (i + 1) + ". " + paralelnistream.get(i).getNaziv());

        System.out.println();
        System.out.println();*/

        List<Virus> sortiranjeVirusaLambdom = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant startLambda = Instant.now();
        sortiranjeVirusaLambdom = sortiranjeVirusaLambdom.stream()
                .sorted(new CovidSorter<Virus>()) /*(v1, v2) -> v2.getNaziv().compareTo(v1.getNaziv())*/
                .collect(Collectors.toList());
        Instant endLambda = Instant.now();
        System.out.println("  Virusi sortirani lambdom po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusaLambdom.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusaLambdom.get(i).getNaziv());

        // System.out.println();
        //  System.out.println();

        List<Virus> sortiranjeVirusa = new ArrayList<>(podatciKlinikeInfektivnihBolesti.dohvatiViruse());
        Instant start = Instant.now();
        //mojaMetodaSortiranjaVirusa(sortiranjeVirusa);
        //Collections.sort(sortiranjeVirusa, new CovidSorter<Virus>());
        sortiranjeVirusa.sort(new CovidSorter<Virus>());
        Instant end = Instant.now();
        /*System.out.println("  Virusi sortirani pomo�u moje funkcije za sortiranje po nazivu suprotno od poretka abecede: ");
        for (int i = 0; i < sortiranjeVirusa.size(); i++)
            System.out.println("  " + (i + 1) + ". " + sortiranjeVirusa.get(i).getNaziv());*/


        //System.out.printf("\n\n  Sotiranje objekata paralenim streamom traje: %d milisekundi.", Duration.between(startparallelLambda, endParallelLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata kori�tenjem lambdi traje: %d milisekundi.", Duration.between(startLambda, endLambda).toMillis());
        System.out.printf("\n  Sortiranje objekata bez kori�tenja lambde traje: %d milisekundi.\n", Duration.between(start, end).toMillis());


        //ISPIS
        System.out.println("\n******************************************* PRETRAGA PO DIJELU STRINGA **********************************************\n");
        /*Boolean ponovi;
        do {
            System.out.print("  Unesite string za pretragu po prezimenu: ");
            vrijednostPretrazivanja = unos.nextLine();

            String regex = "^[- 0-9A-Za-z]*$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(vrijednostPretrazivanja);

            if (matcher.matches() == true)
            {
                ponovi = false;
            } else {
                ponovi = true;
                System.out.println();
                System.out.println("  Krivo unesena vrijednost, probajte opet.");
            }
        }while(ponovi);*/

        System.out.print("  Unesite string za pretragu po prezimenu: ");
        String vrijednostPretrazivanja = unos.nextLine();
        Optional<List<Osoba>> rezultatiPretrazivanjaPoPrezimenu = Optional.ofNullable(
                osobe.stream()
                        .filter(osoba -> osoba.getPrezime().toLowerCase().contains(vrijednostPretrazivanja.toLowerCase()))
                        .sorted((osoba1, osoba2) -> osoba1.getPrezime().compareTo(osoba2.getPrezime()))
                        .collect(Collectors.toList())
        );


        if (vrijednostPretrazivanja.isEmpty()) {
            System.out.println("\n  Nema pretrage.");
        } else {
            if (rezultatiPretrazivanjaPoPrezimenu.get().isEmpty()) {
                System.out.println("\n  Nema takve osobe koja u prezimenu sadr�i une�ena slova.");
            } else {
                System.out.println("\n  Osobe �ije prezime sadr�i �" + vrijednostPretrazivanja + "� su sljede�e:  ");
                for (int i = 0; i < rezultatiPretrazivanjaPoPrezimenu.get().size(); i++) {
                    System.out.println("  " + (i + 1) + ". " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getIme() + " " + rezultatiPretrazivanjaPoPrezimenu.get().get(i).getPrezime());
                }
            }
        }

        //ISPIS
        System.out.println("\n*********************************** ISPIS BROJA SIMPTOMA ZA SVAKU VRSTU ZARAZE **************************************\n");
        List<String> ispisBrojaSimptomaZaBolest = bolesti.stream()
                .map(recenica -> new String(recenica.getNaziv() + " ima " + recenica.getSimptomi().size() + " simptoma."))
                .collect(Collectors.toList());
        for (int i = 0; i < ispisBrojaSimptomaZaBolest.size(); i++)
            System.out.println("  " + (i + 1) + ". " + ispisBrojaSimptomaZaBolest.get(i));


        logger.info("ZAVR�ETAK PROGRAMA");
        //KRAJ CIJELE MAIN FUNKCIJE
    }


    //FUNKCIJA ZA KOPIRANJE DATOTEKA
    public static void copyFile(File from, File to) throws IOException {
        Files.copy(from.toPath(), to.toPath());
    }


    public static void ucitavanjeZaraza(List<Bolest> bolesti, Integer idPovecaj, File simptomiFileTxt, List<Simptom> listaSvihSimptoma, String zarazePathname) {
        File zarazeFileTxt = new File(zarazePathname);

        try (FileReader fileReader = new FileReader(zarazeFileTxt); BufferedReader reader = new BufferedReader(fileReader)) {
            String procitanaLinija = reader.readLine();
            while (procitanaLinija != null) {
                Long id = Long.parseLong(procitanaLinija);
                System.out.println("Pro�itani Id iz datoteke je: " + id);

                String naziv = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani naziv bolesti iz datoteke je: " + naziv);

                String vrijednost = procitanaLinija = reader.readLine();
                System.out.println("Pro�itani simptomi bolesti iz datoteke je: " + vrijednost);


                String[] replaceString = vrijednost.split(",");
                Set<Simptom> dodavanjeSimptomaBolesti = new HashSet<>();


                for (int i = 0; i < replaceString.length; i++) {
                    int id_Broj_Simptoma = Integer.parseInt(replaceString[i]);

                    for (int j = 0; j < listaSvihSimptoma.size(); j++) {
                        if (id_Broj_Simptoma == listaSvihSimptoma.get(j).getId()) {
                            dodavanjeSimptomaBolesti.add(listaSvihSimptoma.get(j));
                        }
                    }
                }

                if (zarazePathname.equals("dat/bolesti.txt"))
                    bolesti.add(new Bolest(id + idPovecaj, naziv, dodavanjeSimptomaBolesti));
                else if (zarazePathname.equals("dat/virusi.txt"))
                    bolesti.add(new Virus(id + idPovecaj, naziv, dodavanjeSimptomaBolesti));

                procitanaLinija = reader.readLine();
            }
            if (zarazePathname.equals("dat/bolesti.txt"))
                logger.info("Podatci o bolestima su uspje�no u�itani.");
            else if (zarazePathname.equals("dat/virusi.txt"))
                logger.info("Podatci o virusima su uspje�no u�itani.");
        } catch (IOException ex) {
            ex.printStackTrace();
            if (zarazePathname.equals("dat/bolesti.txt")) {
                ex = new IOException("Neuspjelo u�itavanje podataka o bolestima.");
            } else if (zarazePathname.equals("dat/virusi.txt")) {
                ex = new IOException("Neuspjelo u�itavanje podataka o virusima.");
            } else {
                ex = new IOException("Neuspjelo u�itavanje podataka o zarazama.");
            }

            System.out.println("\n    " + ex.getMessage());
            logger.error(ex.getMessage(), ex);
        }

    }


    //METODA ZA ISPIS SVIH PODATAKA O OSOBAMA

    /**
     * Ispisuje podatke o osobama.
     *
     * @param osobe niz osoba
     * @param i     index osobe u nizu
     */
    private static void ispisOsoba(List<Osoba> osobe, Integer i) {

        System.out.println("  " + (i + 1) + ". Osoba:");
        System.out.println("    Ime i prezime: " + osobe.get(i).getIme() + " " + osobe.get(i).getPrezime());
        System.out.println("    Starost: " + osobe.get(i).getStarost());
        System.out.println("    �upanija prebivali�ta: " + osobe.get(i).getZupanija().getNaziv());
        System.out.println("    Zara�en bole��u: " + osobe.get(i).getZarazenBolescu().getNaziv());

        System.out.print("    Kontaktirane osobe: ");

        //osobe[i] JE TRENUTNA OSOBA KOJA MO�E SADR�AVATI NIZ ZAR�ENIH OSOBA SA KOJIMA JE BILA U KONTAKTU
        if (osobe.get(i).getKontaktiraneOsobe().isEmpty()) //AKO JE NIZ ZARA�ENIH OSOBA PRAZAN
        {
            System.out.print("Nema kontaktiranih osoba.");
        } else //AKO NIZ ZARA�ENIH OSOBA NIJE PRAZAN
        {
            for (int j = 0; j < osobe.get(i).getKontaktiraneOsobe().size(); j++) {
                if (j > 0) {
                    System.out.print(", ");
                }
                System.out.print(osobe.get(i).getKontaktiraneOsobe().get(j).getIme() + " " + osobe.get(i).getKontaktiraneOsobe().get(j).getPrezime());
            }
        }

        System.out.println("\n");
    }


    public static <T extends ImenovaniEntitet> Boolean provjeri_Ista_Imena(Set<T> fiskniNiz, String primjerak) {
        Boolean ponovi = false;

        whilePetlja:
        {
            Iterator<T> iter1 = fiskniNiz.iterator();
            while (iter1.hasNext()) {
                String naziv = iter1.next().getNaziv();
                if (primjerak.compareToIgnoreCase(naziv) == 0) {
                    System.out.println("    Unesite drugi naziv, isti naziv ve� postoji\n");
                    ponovi = true;
                    break whilePetlja;
                }
            }
        }

        return ponovi;
    }


    public static void dodaj_Zarazene_Po_Bolesti_U_Mapu(List<Bolest> bolesti, List<Osoba> osobe, Map<Bolest, List<Osoba>> mapa) {
        for (Bolest pomocna : bolesti) {
            List<Osoba> pomocniNizOsoba = new ArrayList<>();
            for (int i = 0; i < osobe.size(); i++)
                if (pomocna.getNaziv().equals(osobe.get(i).getZarazenBolescu().getNaziv()) == true)
                    pomocniNizOsoba.add(osobe.get(i));

            if (pomocniNizOsoba.size() >= 1)
                mapa.put(pomocna, pomocniNizOsoba);
        }
    }


    public static void ispis_Mape_Zarazenih_Po_Bolesti(Map<Bolest, List<Osoba>> mapa) {
        for (Bolest key : mapa.keySet()) {
            if (key instanceof Virus)
                System.out.print("  Od virusa " + key.getNaziv() + " boluju: ");
            else
                System.out.print("  Od bolesti " + key.getNaziv() + " boluju: ");

            for (int i = 0; i < mapa.get(key).size(); i++) {
                if (i > 0)
                    System.out.print(", ");
                System.out.print(mapa.get(key).get(i).getIme() + " " + mapa.get(key).get(i).getPrezime());
            }
            System.out.println();
        }
    }


    public static void mojaMetodaSortiranjaVirusa(List<Virus> sortiranjeVirusa) {
        for (int i = 0; i < sortiranjeVirusa.size(); i++) {
            String naziv1 = sortiranjeVirusa.get(i).getNaziv();
            for (int j = 0; j < sortiranjeVirusa.size(); j++) {
                String naziv2 = sortiranjeVirusa.get(j).getNaziv();

                if (naziv2.compareToIgnoreCase(naziv1) <= -1) {
                    Virus tmp = sortiranjeVirusa.get(i);

                    sortiranjeVirusa.set(i, sortiranjeVirusa.get(j));
                    sortiranjeVirusa.set(j, tmp);
                }
            }
        }
    }


    //KRAJ CIJELE KLASE: GLAVNA
}
