package main.java_main_logic.extra_help;

import main.java_main_logic.model.Virus;

import java.util.ArrayList;
import java.util.List;

/*NAPRAVLJENO RADI JEDNOSTAVNIJEG PROSLJE�IVANJA VARIJABLA KAO PARAMETARA U METODAMA U KLASI GLAVNA */
/*POMO�NE VARIJABLE ZA DOBIVANJE KONA�NIH NIZOVA SIMPTOMA I BOLESTI*/
public class PomocneVarijableZaraza
{
    private List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest = new ArrayList<>();
    private List<Virus> pomocni_Niz_Svih_Virusa = new ArrayList<>();


    private Integer ukupanBrojSimptoma = 0;

    private Integer ukupanBrojBolesti = -1;
    private Integer ukupanBrojVirusa = -1;
    private Integer ukupanBrojZaraza = 0;

    private Integer brojacVirusa = 0;
    private Integer brojacBolesti = 0;

    public PomocneVarijableZaraza(){}


    public List<Virus> getPomocni_Niz_Svih_Virusa() {
        return pomocni_Niz_Svih_Virusa;
    }

    public void setPomocni_Niz_Svih_Virusa(List<Virus> pomocni_Niz_Svih_Virusa) {
        this.pomocni_Niz_Svih_Virusa = pomocni_Niz_Svih_Virusa;
    }

    public List<Integer> getSuma_Odabira_Simptoma_Za_Svaku_Bolest() {
        return suma_Odabira_Simptoma_Za_Svaku_Bolest;
    }

    public void setSuma_Odabira_Simptoma_Za_Svaku_Bolest(List<Integer> suma_Odabira_Simptoma_Za_Svaku_Bolest) {
        this.suma_Odabira_Simptoma_Za_Svaku_Bolest = suma_Odabira_Simptoma_Za_Svaku_Bolest;
    }

    public Integer getUkupanBrojBolesti() {
        return ukupanBrojBolesti;
    }

    public void setUkupanBrojBolesti(Integer ukupanBrojBolesti) {
        this.ukupanBrojBolesti = ukupanBrojBolesti;
    }

    public Integer getUkupanBrojVirusa() {
        return ukupanBrojVirusa;
    }

    public void setUkupanBrojVirusa(Integer ukupanBrojVirusa) {
        this.ukupanBrojVirusa = ukupanBrojVirusa;
    }

    public Integer getUkupanBrojZaraza()
    {
        Integer zaraze = ukupanBrojBolesti + ukupanBrojVirusa;
        return zaraze;
    }

    public Integer getUkupanBrojSimptoma() {
        return ukupanBrojSimptoma;
    }

    public void setUkupanBrojSimptoma(Integer ukupanBrojSimptoma) {
        this.ukupanBrojSimptoma = ukupanBrojSimptoma;
    }

    public Integer getBrojacVirusa() {
        return brojacVirusa;
    }

    public void setBrojacVirusa(Integer brojacVirusa) {
        this.brojacVirusa = brojacVirusa;
    }

    public Integer getBrojacBolesti() {
        return brojacBolesti;
    }

    public void setBrojacBolesti(Integer brojacBolesti) {
        this.brojacBolesti = brojacBolesti;
    }
}
