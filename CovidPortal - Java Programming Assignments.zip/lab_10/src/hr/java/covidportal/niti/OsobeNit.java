package hr.java.covidportal.niti;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.model.Osoba;
import main.java_main_logic.model.Zupanija;
import org.w3c.dom.Text;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class OsobeNit implements Runnable {



public TextField brojLjudi = new TextField();

    public OsobeNit(TextField a) {
        brojLjudi = a;
    }






    @Override
    public void run() {

        while (true) {

            try {
                ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuOsobaizBaze(BazaPodataka.dohvatiSveOsobe());
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (IOException exception) {
                exception.printStackTrace();
            }



            brojLjudi.setText(String.valueOf(ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe.size()));
            ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();



            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }
    }
}
