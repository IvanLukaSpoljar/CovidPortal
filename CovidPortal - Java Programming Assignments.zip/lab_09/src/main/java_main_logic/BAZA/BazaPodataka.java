package main.java_main_logic.BAZA;

import main.java_main_logic.model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BazaPodataka {


    //OTVARANJE BAZE PODATAKA
    private static Connection spajanjeNaBazu() throws SQLException {
        Connection veza = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/covid", "student", "student");
        return veza;
    }


    //ZATVARANJE BAZE PODATAKA
    private static void zatvoriBazu(Connection veza) throws SQLException {
        veza.close();
    }


    //--------------------------------------------SIMPTOMI-------------------------------------------------
    //DOHVATI SVE SIMPTOME IZ BAZE
    public static List<Simptom> dohvatiSveSimptomeIzBaze() throws SQLException {
        List<Simptom> listaSimptomaIzBaze = new ArrayList<>();

        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM SIMPTOM");

        while (rs.next()) {
            long idSimptomaIzBaze = rs.getLong("ID");
            String nazivSimptomaIzBaze = rs.getString("NAZIV");
            String vrijednostSimptomaIzBaze = rs.getString("VRIJEDNOST");

            listaSimptomaIzBaze.add(new Simptom(idSimptomaIzBaze, nazivSimptomaIzBaze, vrijednostSimptomaIzBaze));
        }

        zatvoriBazu(veza);
        return listaSimptomaIzBaze;
    }

    //DOHVATI SAMO JEDAN SIMPTOM IZ BAZE
    public static Simptom dohvatiJedanSimptomIzBaze(Long idSimptoma) throws SQLException {

        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM SIMPTOM WHERE ID = " + idSimptoma);

        rs.next();
        long idSimptomaIzBaze = rs.getLong("ID");
        String nazivSimptomaIzBaze = rs.getString("NAZIV");
        String vrijednostSimptomaIzBaze = rs.getString("VRIJEDNOST");

        zatvoriBazu(veza);

        return new Simptom(idSimptomaIzBaze, nazivSimptomaIzBaze, vrijednostSimptomaIzBaze);
    }

    //SPREMANJE JEDNOG NOVOG SIMPTOMA
    public static void spremiJedanSimptom(Simptom simptomZaSprmanje) throws SQLException {
        Connection veza = spajanjeNaBazu();

        PreparedStatement spremiSimptom = veza.prepareStatement("INSERT INTO SIMPTOM(NAZIV, VRIJEDNOST) VALUES (?, ?)");

        spremiSimptom.setString(1, simptomZaSprmanje.getNaziv());
        spremiSimptom.setString(2, simptomZaSprmanje.getVrijednost());
        spremiSimptom.executeUpdate();

        zatvoriBazu(veza);
    }


    //------------------------------------------------------BOLESTI---------------------------------------------------

    public static List<Long> dohvatiSimptomeBolesti(Long idBolesti) throws SQLException {
        Connection veza = spajanjeNaBazu();
        List<Long> listaIdSimptoma = new ArrayList<>();

        String query = "SELECT * FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + idBolesti;
        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()) {
            long idSimptoma = rs.getLong("SIMPTOM_ID");
            listaIdSimptoma.add(idSimptoma);
        }

        zatvoriBazu(veza);

        return listaIdSimptoma;

    }

    //DOHVATI SVE BOLESTI IZ BAZE
    public static List<Bolest> dohvatiSveBolestiIzBaze() throws SQLException {
        List<Bolest> listaBolestiIzBaze = new ArrayList<>();

        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM BOLEST");


        while (rs.next()) {
            long idBolestiIzBaze = rs.getLong("ID");
            String nazivBolestiIzBaze = rs.getString("NAZIV");
            Boolean istinosniTipZaraze = rs.getBoolean("VIRUS");

            List<Long> listaIdSimptoma = new ArrayList<>();
            listaIdSimptoma = dohvatiSimptomeBolesti(idBolestiIzBaze);
            List<Simptom> simptomiBolesti = new ArrayList<>();

            for (Long l : listaIdSimptoma) {
                Simptom noviSimptom = dohvatiJedanSimptomIzBaze(l);
                simptomiBolesti.add(noviSimptom);
            }

            if (istinosniTipZaraze == true) {
                Virus virus = new Virus(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBolesti);
                listaBolestiIzBaze.add(virus);
            } else {
                Bolest bolest = new Bolest(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBolesti);
                listaBolestiIzBaze.add(bolest);
            }
        }


        if (!veza.isClosed()) {
            zatvoriBazu(veza);
        }

        return listaBolestiIzBaze;
    }


    //DOHVAT JEDNE BOLESTI
    private static Bolest dohvatJedneZaraze(long idZaraze) throws SQLException {


        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM BOLEST WHERE ID = " + idZaraze);


        rs.next();
        List<Simptom> simptomiBaze = new ArrayList<>();

        long idBolestiIzBaze = rs.getLong("ID");
        String nazivBolestiIzBaze = rs.getString("NAZIV");
        Boolean istinosniTipZaraze = rs.getBoolean("VIRUS");


        ResultSet rs1 = stmt.executeQuery("SELECT SIMPTOM_ID FROM BOLEST_SIMPTOM WHERE BOLEST_ID = " + idBolestiIzBaze);


        while (rs1.next()) {
            long indexSimptoma = rs1.getLong("SIMPTOM_ID");
/*
                ResultSet rs2 =  stmt.executeQuery("SELECT * FROM SIMTPOM WHERE ID = " + index);
                rs2.next();

                long tmp_id = rs2.getLong("ID");
                String tmp_naziv = rs2.getString("NAZIV");
                String tmp_vrijednost = rs2.getString("VRIJEDNOST");*/

            simptomiBaze.add(dohvatiJedanSimptomIzBaze(indexSimptoma));
        }

        zatvoriBazu(veza);
        if (istinosniTipZaraze == true) {
            return new Virus(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBaze);
        } else {
            return new Bolest(idBolestiIzBaze, nazivBolestiIzBaze, simptomiBaze);
        }
    }

    //SPREMANJE JEDNE ZARAZE
    public static void spremiJednuZarazu(Bolest zarazaZaSpremanje) throws SQLException {
        Connection veza = spajanjeNaBazu();

        System.out.println("Bolest je: " + zarazaZaSpremanje);

        PreparedStatement spremiBolest = veza.prepareStatement("INSERT INTO BOLEST(NAZIV, VIRUS) VALUES (?, ?)");
        Boolean istinitost = false;
        //SPREMANJE U TBLICU BOLEST
        spremiBolest.setString(1, zarazaZaSpremanje.getNaziv());
        if (zarazaZaSpremanje instanceof Virus) {
            istinitost = true;
        }
        spremiBolest.setBoolean(2, istinitost);
        spremiBolest.executeUpdate();


        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT ID FROM BOLEST ORDER BY 1 DESC LIMIT 1");
        rs.next();
        long indexZaraze = rs.getLong("ID");


        PreparedStatement spremiInfo = veza.prepareStatement("INSERT INTO BOLEST_SIMPTOM(BOLEST_ID, SIMPTOM_ID) VALUES (?, ?)");
        //SPREMANJE U TABLICU BOLEST_SIMPTOM
        for (Simptom x : zarazaZaSpremanje.getSimptomi()) {
            long trenutniIndexSimptoma = x.getId();

            spremiInfo.setLong(1, indexZaraze);
            spremiInfo.setLong(2, trenutniIndexSimptoma);
            spremiInfo.executeUpdate();
        }


        zatvoriBazu(veza);
    }


    //----------------------------------------�UPANIJE -----------------------------------------------
    //DOHVATI SVE BOLESTI IZ BAZE
    public static List<Zupanija> dohvatiSveZupanije() throws SQLException {
        List<Zupanija> listaZupanijeIzBaze = new ArrayList<>();

        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM ZUPANIJA");


        while (rs.next()) {
            long idZupanijeIzBaze = rs.getLong("ID");
            String nazivZupanijeIzBaze = rs.getString("NAZIV");
            Integer brojStanovnikaizBaze = rs.getInt("BROJ_STANOVNIKA");
            Integer brojZarazenihizBaze = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");

            listaZupanijeIzBaze.add(new Zupanija(idZupanijeIzBaze, nazivZupanijeIzBaze, brojStanovnikaizBaze, brojZarazenihizBaze));
        }

        zatvoriBazu(veza);
        return listaZupanijeIzBaze;
    }

    //DOHVAT JEDNE �UPANIJE
    public static Zupanija dohvatiJednuZupaniju(Long idZupanije) throws SQLException {

        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM ZUPANIJA WHERE ID = " + idZupanije);
        rs.next();
        long idZupanijeIzBaze = rs.getLong("ID");
        String nazivZupanijeIzBaze = rs.getString("NAZIV");
        Integer brojStanovnikaizBaze = rs.getInt("BROJ_STANOVNIKA");
        Integer brojZarazenihizBaze = rs.getInt("BROJ_ZARAZENIH_STANOVNIKA");

        zatvoriBazu(veza);

        return new Zupanija(idZupanijeIzBaze, nazivZupanijeIzBaze, brojStanovnikaizBaze, brojZarazenihizBaze);
    }

    //SPREMANJE JEDNE �UPANIJE
    public static void spremiJednuZupaniju(Zupanija zupanijaZaSprmanje) throws SQLException {
        Connection veza = spajanjeNaBazu();

        PreparedStatement spremiZupaniju = veza.prepareStatement("INSERT INTO ZUPANIJA(NAZIV, BROJ_STANOVNIKA, BROJ_ZARAZENIH_STANOVNIKA) VALUES (?, ?, ?)");

        spremiZupaniju.setString(1, zupanijaZaSprmanje.getNaziv());
        spremiZupaniju.setInt(2, zupanijaZaSprmanje.getBrojStanovnika());
        spremiZupaniju.setInt(3, zupanijaZaSprmanje.getBrojZarazenih());
        spremiZupaniju.executeUpdate();

        zatvoriBazu(veza);
    }


    //---------------------------------------------------OSOBE------------------------------------------------------
    //DOHVATI SVIH OSOBA IZ BAZE
    public static List<Osoba> dohvatiSveOsobe() throws SQLException {
        List<Osoba> listaOsobaIzBaze = new ArrayList<>();


        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM OSOBA");


        while (rs.next()) {

            List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();

            long idOsobeIzBaze = rs.getLong("ID");
            String imeOsobe = rs.getString("IME");
            String prezime = rs.getString("PREZIME");
            Date datum = (Date) rs.getDate("DATUM_RODJENJA");


            long zupanijaId = rs.getLong("ZUPANIJA_ID");
            long bolestiId = rs.getLong("BOLEST_ID");

            //�UPANJIJA
            Zupanija jednaKonacnaZupanija = dohvatiJednuZupaniju(zupanijaId);

            //BOLESTI
            Bolest jednaKonacnaZaraza = dohvatJedneZaraze(bolestiId);

            List<Long> indexiKontaktiranihOsoba = new ArrayList<>();


            //KONTAKTIRANE OSOBE
            List<Long> listaIdKontOsoba = new ArrayList<>();
            listaIdKontOsoba = dohvatiKontaktiraneOsobeId(idOsobeIzBaze);

            for (Long l : listaIdKontOsoba) {
                Osoba novaKonOsoba = dohvatiJednuOsobu(l);
                listaKontaktiranihOsoba.add(novaKonOsoba);


            }


            Osoba tmp = new Osoba.Builder(idOsobeIzBaze)
                    .name(imeOsobe)
                    .surname(prezime)
                    .age(datum)
                    .county(jednaKonacnaZupanija) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                    .personInfection(jednaKonacnaZaraza) //UNOS BOLESTI OSOBE
                    .contactedPersons(listaKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                    .makeItDone();


            listaOsobaIzBaze.add(tmp);


        }
        zatvoriBazu(veza);
        return listaOsobaIzBaze;
    }

    public static List<Long> dohvatiKontaktiraneOsobeId(Long idOsobeIzBaze) throws SQLException {
        Connection veza = spajanjeNaBazu();
        List<Long> listaIdKontaktiranih = new ArrayList<>();

        Statement stmt2 = veza.createStatement();
        ResultSet rs = stmt2.executeQuery("SELECT KONTAKTIRANA_OSOBA_ID  FROM KONTAKTIRANE_OSOBE WHERE OSOBA_ID = " + idOsobeIzBaze);

        while (rs.next()) {
            long idKontaktOsobe = rs.getLong("KONTAKTIRANA_OSOBA_ID");
            listaIdKontaktiranih.add(idKontaktOsobe);


        }
        zatvoriBazu(veza);
        return listaIdKontaktiranih;
    }


    //DOHVATI JEDNU OSOBU
    private static Osoba dohvatiJednuOsobu(Long idOsobe) throws SQLException {

        List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();
        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM OSOBA WHERE ID = " + idOsobe);
        rs.next();

        long idOsobeIzBaze = rs.getLong("ID");
        String imeOsobe = rs.getString("IME");
        String prezime = rs.getString("PREZIME");
        Date datum = (Date) rs.getDate("DATUM_RODJENJA");


        long zupanijaId = rs.getLong("ZUPANIJA_ID");
        long bolestiId = rs.getLong("BOLEST_ID");

        //�UPANJIJA
        Zupanija jednaKonacnaZupanija = dohvatiJednuZupaniju(zupanijaId);

        //BOLESTI
        Bolest jednaKonacnaZaraza = dohvatJedneZaraze(bolestiId);

        List<Long> indexiKontaktiranihOsoba = new ArrayList<>();


        //KONTAKTIRANE OSOBE
        List<Long> listaIdKontOsoba = new ArrayList<>();
        listaIdKontOsoba = dohvatiKontaktiraneOsobeId(idOsobeIzBaze);

        for (long x : listaIdKontOsoba) {

        }
        dod(listaKontaktiranihOsoba);


        Osoba pom = (
                new Osoba.Builder(idOsobeIzBaze)
                        .name(imeOsobe)
                        .surname(prezime)
                        .age(datum)
                        .county(jednaKonacnaZupanija) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                        .personInfection(jednaKonacnaZaraza) //UNOS BOLESTI OSOBE
                        .contactedPersons(listaKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                        .makeItDone()
        );

        return pom;
    }


    private static void dod(List<Osoba> listaKontaktiranihOsoba) {

    }


    private static Osoba dohvatiSamoJednuVecKontaktiranuOsobu(Long idOsobe) throws SQLException {

        List<Osoba> listaKontaktiranihOsoba = new ArrayList<>();
        Connection veza = spajanjeNaBazu();

        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM OSOBA WHERE ID = " + idOsobe);
        rs.next();

        long idOsobeIzBaze = rs.getLong("ID");
        String imeOsobe = rs.getString("IME");
        String prezime = rs.getString("PREZIME");
        Date datum = (Date) rs.getDate("DATUM_RODJENJA");


        long zupanijaId = rs.getLong("ZUPANIJA_ID");
        long bolestiId = rs.getLong("BOLEST_ID");

        //�UPANJIJA
        Zupanija jednaKonacnaZupanija = dohvatiJednuZupaniju(zupanijaId);

        //BOLESTI
        Bolest jednaKonacnaZaraza = dohvatJedneZaraze(bolestiId);


        List<Long> indexiKontaktiranihOsoba = new ArrayList<>();
        long trenutniIndexKontaktiraneOsobe = 0;


        zatvoriBazu(veza);

        Osoba jednaOsobaIzBaze = (
                new Osoba.Builder(idOsobeIzBaze)
                        .name(imeOsobe)
                        .surname(prezime)
                        .age(datum)
                        .county(jednaKonacnaZupanija) //UNOS PREBIVALI�NE �UPANIJE OSOBE
                        .personInfection(jednaKonacnaZaraza) //UNOS BOLESTI OSOBE
                        .contactedPersons(listaKontaktiranihOsoba) //DODAVANJE NIZA KONTAKTIRANIH OSOBA TOJ OSOBI, NIZ KONTAKTIRANIH OSOBA MO�E BITI NULL
                        .makeItDone()
        );

        return jednaOsobaIzBaze;
    }


    //SPREMI NOVU OSOBU U BAZU
    private static void spremiJednuOosbu(Osoba osobaZaSpremanje) throws SQLException {
        Connection veza = spajanjeNaBazu();


        PreparedStatement spremiOsobu = veza.prepareStatement("INSERT INTO OSOBA(IME, PREZIME, DATUM_RODJENJA, ZUPANIJA_ID, BOLEST_ID) VALUES (?, ?, ?, ? ?)");
        //SPREMANJE OSOBE U TABLICU
        spremiOsobu.setString(1, osobaZaSpremanje.getIme());
        spremiOsobu.setString(2, osobaZaSpremanje.getPrezime());
        spremiOsobu.setDate(3, osobaZaSpremanje.getStarost());
        spremiOsobu.setLong(4, osobaZaSpremanje.getZupanija().getId());
        spremiOsobu.setLong(5, osobaZaSpremanje.getZarazenBolescu().getId());
        spremiOsobu.executeUpdate();


        Statement stmt = veza.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT ID FROM OSOBA ORDER BY 1 DESC LIMIT 1");
        rs.next();
        long indexOsobe = rs.getLong("ID");


        //SPREMANJE U KONTAKTIRANE OSOBE TABLICU
        PreparedStatement spremiKontaktiranuOsobu = veza.prepareStatement("INSERT INTO KONTAKTIRANE_OSOBE VALUES (?, ?)");
        //SPREMANJE U TABLICU BOLEST_SIMPTOM
        for (Osoba x : osobaZaSpremanje.getKontaktiraneOsobe()) {
            long trenutniIndexKontOsobe = x.getId();

            spremiKontaktiranuOsobu.setLong(1, indexOsobe);
            spremiKontaktiranuOsobu.setLong(2, trenutniIndexKontOsobe);
            spremiKontaktiranuOsobu.executeUpdate();
        }


        zatvoriBazu(veza);
    }


}
