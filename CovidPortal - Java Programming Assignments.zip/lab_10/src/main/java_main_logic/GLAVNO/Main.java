package main.java_main_logic.GLAVNO;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.sporedno.Glavna;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;


import java.io.*;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

public class Main extends Application implements ListeZupanijaSimptomaBolestiVirusaOsoba {

    private static Stage mainStage;
    public static Stage getMainStage()
    {
        return mainStage;
    }


    @Override
    public void start(Stage primaryStage) throws Exception{
        logger.info("Korisnik je otvorio ekran Glavnog izbornika");
        mainStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        primaryStage.setTitle("Covidportal");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        logger.info("Korisnik je zatvorio ekran Glavnog izbornika");
    }


    public static void main(String[] args) throws IOException, SQLException {
        logger.info("PO�ETAK PROGRAMA");
        // Glavna.main(args);

       /* //U�ITAVANJE PODATAKA IZ BAZE
        ListeZupanijaSimptomaBolestiVirusaOsoba.ucitajSvePodatkeIzBaze();*/
        
        launch(args);
        logger.info("KRAJ PROGRAMA");
    }
}
