package hr.java.covidportal.model;

public class Osoba {
    private String ime;
    private String prezime;
    private Integer starost;

    private Zupanija zupanija;
    private Bolest zarazenBolescu;
    private Osoba[] kontaktiraneOsobe;

    //KONSTRUKTOR
    public Osoba(String ime, String prezime, Integer starost, Zupanija zupanija, Bolest zarazenBolescu, Osoba[] kontaktiraneOsobe) {
        this.ime = ime;
        this.prezime = prezime;
        this.starost = starost;
        this.zupanija = zupanija;
        this.zarazenBolescu = zarazenBolescu;
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }

    //KONSTRUKTOR KOJI SE KORISTI U KLASI BUILDER U DIJELU MAKEITDONE
    private Osoba() {
    }


    public static class Builder {
        private String ime;
        private String prezime;
        private Integer starost;

        private Zupanija zupanija;
        private Bolest zarazenBolescu;
        private Osoba[] kontaktiraneOsobe;

        public Builder(String ime) {
            this.ime = ime;
        }

        public Builder surname(String prezime) {
            this.prezime = prezime;
            return this;
        }

        public Builder age(Integer starost) {
            this.starost = starost;
            return this;
        }

        public Builder county(Zupanija zupanija) {
            this.zupanija = zupanija;
            return this;
        }

        public Builder personInfection(Bolest zarazenBolescu) {
            this.zarazenBolescu = zarazenBolescu;
            return this;
        }

        public Builder contactedPersons(Osoba[] kontaktiraneOsobe) {
            this.kontaktiraneOsobe = kontaktiraneOsobe;
            return this;
        }

        public Osoba makeItDone() {
            //PODATCI UPISANI U BILDER SE ŠALJU U OSOBU
            Osoba pomocna = new Osoba();
            pomocna.ime = this.ime;
            pomocna.prezime = this.prezime;
            pomocna.starost = this.starost;
            pomocna.zupanija = this.zupanija;
            pomocna.zarazenBolescu = this.zarazenBolescu;
            pomocna.kontaktiraneOsobe = this.kontaktiraneOsobe;

            //BOLEST INSTANCA OD VIRUSA ? JE LI RIJEČ O BOLESTI ILI VIRUSU ?
            if(this.kontaktiraneOsobe != null) {
                if (this.zarazenBolescu instanceof Virus virus) {
                    for (int i = 0; i < kontaktiraneOsobe.length; i++) {
                        virus.prelazakZarazeNaOsobu(this.kontaktiraneOsobe[i]);
                    }
                }
                /*      //U SLUČAJU KADA BI BOLEST MOGLA PRIJEĆI NA KONTAKTIRANE OSOBE I PONIŠTITI VIRUS
                else {
                    for (int i = 0; i < kontaktiraneOsobe.length; i++) {
                        this.kontaktiraneOsobe[i].setZarazenBolescu(this.zarazenBolescu);
                    }
                }*/
            }

            return pomocna;
        }
    }

    //GETTERI I SETTERI KLASE OSOBA
    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Integer getStarost() {
        return starost;
    }

    public void setStarost(Integer starost) {
        this.starost = starost;
    }

    public Zupanija getZupanija() {
        return zupanija;
    }

    public void setZupanija(Zupanija zupanija) {
        this.zupanija = zupanija;
    }

    public Bolest getZarazenBolescu() {
        return zarazenBolescu;
    }

    public void setZarazenBolescu(Bolest zarazenBolescu) {
        this.zarazenBolescu = zarazenBolescu;
    }

    public Osoba[] getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }

    public void setKontaktiraneOsobe(Osoba[] kontaktiraneOsobe) {
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }
}

