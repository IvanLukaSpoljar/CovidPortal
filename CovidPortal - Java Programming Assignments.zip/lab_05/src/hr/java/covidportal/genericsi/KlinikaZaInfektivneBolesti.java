package hr.java.covidportal.genericsi;

import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Osoba;
import hr.java.covidportal.model.Virus;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class KlinikaZaInfektivneBolesti <T extends Virus, S extends Osoba> {
    private List<T> samoVirusi = new ArrayList<>();
    private List<S> samoVirusomZarazeneOsobe = new ArrayList<>();

    public KlinikaZaInfektivneBolesti(List<S> nizSvihOsobaUProgramu, List<T> virusi) {
        samoVirusomZarazeneOsobe = nizSvihOsobaUProgramu.stream()
                .filter(jednaOsoba ->
                {
                    if (jednaOsoba instanceof Osoba) {
                        if (((Osoba) jednaOsoba).getZarazenBolescu() instanceof Virus) {
                            return true;
                        }
                    }
                    return false;
                })
                .collect(Collectors.toList());

        /*samoVirusi = samoVirusomZarazeneOsobe.stream()
                .map(S -> (T)S.getZarazenBolescu())
                .distinct()
                .collect(Collectors.toList());*/
        samoVirusi = virusi;
    }

    public KlinikaZaInfektivneBolesti() {
    }



    public void dodajNoviVirus(Bolest jednaBolest) {
        if (jednaBolest instanceof Virus) {
            samoVirusi.add((T) jednaBolest);
        }
    }

    public List<T> dohvatiViruse()
    {
        return samoVirusi;
    }


    public void dodajNovuOsobu(S jednaOsoba)
    {
        samoVirusomZarazeneOsobe.add(jednaOsoba);

    }

    public List<S> dohvatiOsobeZarazeneVirusom()
    {
        return samoVirusomZarazeneOsobe;
    }

}
