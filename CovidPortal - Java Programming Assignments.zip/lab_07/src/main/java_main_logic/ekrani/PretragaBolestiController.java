package main.java_main_logic.ekrani;

import javafx.scene.image.Image;
import main.java_main_logic.model.Bolest;
import main.java_main_logic.model.Simptom;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaBolestiController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba {

    List<Bolest> listaSvihBolesti = new ArrayList<>();
    public static final Logger logger = LoggerFactory.getLogger(PretragaBolestiController.class);

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;

    @FXML
    private TableView<Bolest> tablicaBolesti;

    @FXML
    private TableColumn<Bolest, String> stupacNaziva;

    @FXML
    private TableColumn<Bolest, Set<Simptom>> stupacSimptoma;




    @FXML
    public void odiNatrag() throws IOException
    {


        Parent pretragaZupanijaFrame = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Covidportal");

        logger.info("Korisnik je zatvorio ekran o Bolestima");
    }


    @FXML
    public void pretrazi() throws IOException
    {
        tablicaBolesti.setItems(FXCollections.observableList(listaSvihBolesti));

        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaBolesti.setItems(FXCollections.observableList(
                    listaSvihBolesti.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Bolesti");
        logger.info("Korisnik je otvorio ekran o Bolestima");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Bolest, String>("naziv"));
        stupacSimptoma.setCellValueFactory(new PropertyValueFactory<Bolest, Set<Simptom>>("simptomi"));

        listaSvihBolesti = liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba.sveBolesti;
        tablicaBolesti.setItems(FXCollections.observableList(listaSvihBolesti));

    }
}

