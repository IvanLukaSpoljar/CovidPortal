package hr.java.covidportal.enums;

public enum EnumeracijaSimptoma
{
    RIJETKO("RIJETKO"),
    SREDNJE( "SREDNJE"),
    CESTO("�ESTO");


    private String opis;

    private EnumeracijaSimptoma(String opis)
    {
        this.opis = opis;
    }

    public String getOpis() {
        return opis;
    }
}
