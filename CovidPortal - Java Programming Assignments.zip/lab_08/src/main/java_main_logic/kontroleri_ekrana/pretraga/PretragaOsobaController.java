package main.java_main_logic.kontroleri_ekrana.pretraga;

import javafx.scene.control.Button;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.model.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import main.java_main_logic.GLAVNO.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class PretragaOsobaController implements Initializable, PovijestKretanjaPoEkranima {

    List<Osoba> listaSvihOsoba = new ArrayList<>();
    public static String putanjaDoTrenutnogFXMLa = "layout/pretraga/pretragaOsoba.fxml";
    public static final  Logger logger = LoggerFactory.getLogger(PretragaOsobaController.class);


    @FXML
    private Button naprijedGumb = new Button();

    @FXML
    private TextField kljucnaRijecZaPretrazivanje;


    @FXML
    private TableView<Osoba> tablicaOsoba;
    @FXML
    private TableColumn<Osoba, String> stupacImena;
    @FXML
    private TableColumn<Osoba, String> stupacPrezimena;
    @FXML
    private TableColumn<Osoba, Integer> stupacStarosti;
    @FXML
    private TableColumn<Osoba, Zupanija> stupacZupanije;
    @FXML
    private TableColumn<Osoba, Bolest> stupacBolesti;
    @FXML
    private TableColumn<Osoba, List<Osoba>> stupacKontaktiranih;




    @FXML
    public void odiNatrag() throws IOException
    {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran o Osobama");
    }

    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }

    @FXML
    public void pretrazi() throws IOException
    {
        tablicaOsoba.setItems(FXCollections.observableList(listaSvihOsoba));
        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaOsoba.setItems(FXCollections.observableList(
                    listaSvihOsoba.stream()
                            .filter(z -> z.getIme().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Main.getMainStage().setTitle("Osobe");
        logger.info("Korisnik je otvorio ekran o Osobama");

        stupacImena.setCellValueFactory(new PropertyValueFactory<Osoba, String>("ime"));
        stupacPrezimena.setCellValueFactory(new PropertyValueFactory<Osoba, String >("prezime"));
        stupacStarosti.setCellValueFactory(new PropertyValueFactory<Osoba, Integer>("starost"));
        stupacZupanije.setCellValueFactory(new PropertyValueFactory<Osoba, Zupanija>("zupanija"));
        stupacBolesti.setCellValueFactory(new PropertyValueFactory<Osoba, Bolest>("zarazenBolescu"));
        stupacKontaktiranih.setCellValueFactory(new PropertyValueFactory<Osoba, List<Osoba>>("kontaktiraneOsobe"));


        listaSvihOsoba = ListeZupanijaSimptomaBolestiVirusaOsoba.sveOsobe;
        tablicaOsoba.setItems(FXCollections.observableList(listaSvihOsoba));

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
