package main.java_main_logic.model;

import java.io.Serializable;

/**
 * Nadklasa
 */
public abstract class ImenovaniEntitet implements Serializable{
    private String naziv;
    private Long id;

    //KONSTRUKTOR

    /**
     * Prima naziv
     * @param naziv naziv
     */
    public ImenovaniEntitet(Long id, String naziv)
    {
        this.id = id;
        this.naziv = naziv;
    }
    public ImenovaniEntitet(){}

    //NAZIV
    public String getNaziv() {
        return naziv;
    }
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }


    //ID
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
}
