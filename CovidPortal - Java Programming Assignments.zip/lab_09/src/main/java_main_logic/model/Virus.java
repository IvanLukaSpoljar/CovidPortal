package main.java_main_logic.model;

import java.util.List;
import java.util.Set;

/**
 *Slu�i za kreiranje objekta bolest u klasi Glavna.
 */
public class Virus extends Bolest implements Zarazno {
    //KONSTRUKTOR
    public Virus(Long id, String naziv, List<Simptom> simptomi) {
        super(id, naziv, simptomi);
    }




    /**
     * Prenosi virus
     * @param osoba objekt klase Osoba
     */


    @Override
    public void prelazakZarazeNaOsobu(Osoba osoba) {
        osoba.setZarazenBolescu(this);
    }

    @Override
    public String toString()
    {
        return super.getNaziv();
    }
}
