package main.java_main_logic.kontroleri_ekrana.novi_zapis;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import main.java_main_logic.BAZA.BazaPodataka;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.ListeZupanijaSimptomaBolestiVirusaOsoba;
import main.java_main_logic.extra_help.PovijestKretanjaPoEkranima;
import main.java_main_logic.iznimke.Upozorenje;
import main.java_main_logic.model.Bolest;
import main.java_main_logic.model.Simptom;
import main.java_main_logic.model.Virus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DodavanjeNovogVirusaController implements Initializable, ListeZupanijaSimptomaBolestiVirusaOsoba, PovijestKretanjaPoEkranima {

    public static final Logger logger = LoggerFactory.getLogger(DodavanjeNovogVirusaController.class);
    public static String putanjaDoTrenutnogFXMLa = "layout/novi_zapis/dodavanjeNovogVirusa.fxml";


    @FXML
    private Button naprijedGumb = new Button();


    @FXML
    private TextField dohvatNaziva = new TextField();
    @FXML
    private TextField dohvatRbSimptoma = new TextField();


    @FXML
    private void spremiNoviVirus() throws IOException, SQLException {

        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuSimptomaIzBaze(BazaPodataka.dohvatiSveSimptomeIzBaze());
        ListeZupanijaSimptomaBolestiVirusaOsoba.dohvatiListuZarazaIzBaze(BazaPodataka.dohvatiSveZarazeIzBaze());

        try {
            provjeriPopunjenost(dohvatNaziva, dohvatRbSimptoma);
            provjeriValjanostOdabiraSimptoma(dohvatRbSimptoma.getText());
            int[] numbers = Arrays.stream(dohvatRbSimptoma.getText().split(",")).mapToInt(Integer::parseInt).toArray();
            List<Simptom> pomSimptomi = new ArrayList<>();
            for(int i = 0; i < numbers.length; i++)
            {
                int idBroj = numbers[i];
                for(int j= 0; j < sviSimptomi.size(); j++)
                {
                    if(sviSimptomi.get(j).getId() == idBroj){
                        pomSimptomi.add(sviSimptomi.get(j));
                    }
                }
            }
            BazaPodataka.spremiJednuZarazu(dohvatNaziva.getText(), pomSimptomi, true);


            isprazniSvaPolja(dohvatNaziva, dohvatRbSimptoma);

            Alert obavijest = new Alert(Alert.AlertType.INFORMATION);
            Stage prozor = (Stage) obavijest.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/fine.png"));
            obavijest.setTitle("Spremanje novog virusa");
            obavijest.setHeaderText("Obavijest");
            obavijest.setContentText("Uspje�no spremanje podataka o novom virusu");
            obavijest.showAndWait();


        } catch (Upozorenje | SQLException ex) {

            Alert upozorenje = new Alert(Alert.AlertType.ERROR);
            Stage prozor = (Stage) upozorenje.getDialogPane().getScene().getWindow();
            prozor.getIcons().add(new Image("icons/error.png"));
            upozorenje.setHeaderText("Gre�ka");
            upozorenje.setTitle("Nepopunjena polja ili krivo odabrani simptomi");
            upozorenje.setContentText(ex.getMessage());
            upozorenje.showAndWait();

            isprazniSvaPolja(dohvatNaziva, dohvatRbSimptoma);
        }

        ListeZupanijaSimptomaBolestiVirusaOsoba.ocistiSveListe();
    }




    private void provjeriValjanostOdabiraSimptoma(String simptomi) {
        Boolean nedozvoljenaVrijednost = false;
        String regex = "^[0-9,]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(simptomi);

        if (matcher.matches() == false)
            nedozvoljenaVrijednost = true;
        else {
            String[] stringoviBrojeva = simptomi.split(",");
            if(stringoviBrojeva.length == 0)
            {
                nedozvoljenaVrijednost = true;
            }
            for (int i = 0; i < stringoviBrojeva.length; i++)
                if (stringoviBrojeva[i].isEmpty() == true || stringoviBrojeva[i].isEmpty() || (long) Integer.parseInt(stringoviBrojeva[i]) < 1 || (long) Integer.parseInt(stringoviBrojeva[i]) > sviSimptomi.get(sviSimptomi.size() - 1).getId())
                    nedozvoljenaVrijednost = true;

        }

        if(nedozvoljenaVrijednost == true)
            throw new Upozorenje("Unjeli ste nedozvoljenu vrijednost u polje simptoma, mo�ete odabrati simptome u intervalu od " + 1 + " do " + sviSimptomi.get(sviSimptomi.size() - 1).getId() + "\nNe zaboravite odabire simptoma odvajati zarezom.");
    }




    private void provjeriPopunjenost(TextField naziv, TextField simptomi) {
        if (naziv.getText().isEmpty() == true || simptomi.getText().isEmpty() == true)
            throw new Upozorenje("Popunite polja");
    }



    private void isprazniSvaPolja(TextField naziv, TextField dohvatRbSimptoma) {
        naziv.setText("");
        dohvatRbSimptoma.setText("");
    }



    @FXML
    public void odiNatrag() throws IOException {
        prethodniEkran(putanjaDoTrenutnogFXMLa);
        logger.info("Korisnik je zatvorio ekran dodavanja virusa");
    }

    @FXML
    public void odiNaprijed() throws IOException {
        slijedeciEkran(putanjaDoTrenutnogFXMLa);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Main.getMainStage().setTitle("Dodavanje novog virusa");
        logger.info("Korisnik je otvorio ekran dodavanja novog virusa");

        dodavanjePutanjaKretanjaUListu(putanjaDoTrenutnogFXMLa);
        vidljivostGumba(naprijedGumb, putanjaDoTrenutnogFXMLa);
    }
}
