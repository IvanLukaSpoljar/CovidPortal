package hr.java.covidportal.model;

public class Bolest {
    private String naziv;
    private Simptom[] simptomi;

    //KONSTRUKTOR
    public Bolest(String naziv, Simptom[] simptomi) {
        this.naziv = naziv;
        this.simptomi = simptomi;
    }


    //NAZIV
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }


    //SIMPTOMI
    public Simptom[] getSimptomi() {
        return simptomi;
    }

    public void setSimptomi(Simptom[] simptomi) {
        this.simptomi = simptomi;
    }
}
