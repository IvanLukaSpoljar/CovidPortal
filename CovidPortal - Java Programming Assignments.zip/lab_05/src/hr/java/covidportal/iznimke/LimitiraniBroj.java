package hr.java.covidportal.iznimke;
/**
 *Služi za kreiranje neoznačene vlastite iznimke u klasi Glavna.
 */
public class LimitiraniBroj extends RuntimeException
{
    public LimitiraniBroj(){}

    public LimitiraniBroj(String message)
    {
        super(message);
    }

    public LimitiraniBroj(Throwable cause)
    {
        super(cause);
    }

    public LimitiraniBroj(String message, Throwable cause)
    {
        super(message, cause);
    }
}
