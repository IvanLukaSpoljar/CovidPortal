package main.java_main_logic.ekrani;

import javafx.scene.control.TextField;
import main.java_main_logic.GLAVNO.Main;
import main.java_main_logic.extra_help.liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba;
import main.java_main_logic.model.Zupanija;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import javafx.scene.control.cell.PropertyValueFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaZupanijaController implements Initializable, liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba {
    private static List<Zupanija> listaSvihZupanijeIzControllera = new ArrayList<>();
    public static final Logger logger = LoggerFactory.getLogger(PretragaZupanijaController.class);



    @FXML
    private TextField kljucnaRijecZaPretrazivanje = new TextField();


    @FXML
    private TableView<Zupanija> tablicaZupanija;

    @FXML
    private TableColumn<Zupanija, String> stupacNaziva;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaStanovnika;
    @FXML
    private TableColumn<Zupanija, Integer> stupacBrojaZarazenih;



    @FXML
    public void odiNatrag() throws IOException
    {
        Parent pretragaZupanijaFrame = FXMLLoader.load(getClass().getClassLoader().getResource("layout/pocetniEkran.fxml"));
        Scene pretragaZupanijaScene = new Scene(pretragaZupanijaFrame, 600, 400);
        Main.getMainStage().setScene(pretragaZupanijaScene);
        Main.getMainStage().setTitle("Covidportal");

        logger.info("Korisnik je zatvorio ekran o �upanijama");
    }


    @FXML
    public void pretrazi() throws IOException
    {
        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));

        if(kljucnaRijecZaPretrazivanje.getText().isEmpty() == false)
        {
            tablicaZupanija.setItems(FXCollections.observableList(
                    listaSvihZupanijeIzControllera.stream()
                            .filter(z -> z.getNaziv().toLowerCase().contains(kljucnaRijecZaPretrazivanje.getText().toLowerCase()))
                            .collect(Collectors.toList())
            ));
        }


    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Main.getMainStage().setTitle("�upanije");
        logger.info("Korisnik je otvorio ekran o �upanijama");

        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Zupanija, String>("naziv"));
        stupacBrojaStanovnika.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojStanovnika"));
        stupacBrojaZarazenih.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojZarazenih"));

        listaSvihZupanijeIzControllera = liste_Zupanija_Simptoma_Bolesti_Virusa_Osoba.sveZupanije;
        tablicaZupanija.setItems(FXCollections.observableList(listaSvihZupanijeIzControllera));
    }
}
